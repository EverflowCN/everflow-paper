# Everflow·彼时流年若水 — Core Audit 02

Date: 2026-08-09
Version: 1.0.0-core-audit.2

## Scope

Core Audit 02 intentionally freezes peripheral membership/security expansion and audits four product-core chains:

1. DOCX image extraction and anchor/placement preservation.
2. Ordinary PNG/JPG/PDF assets from QuestionRevision to Paper Workspace to real XeLaTeX.
3. Question editing UI backed by immutable QuestionRevision creation.
4. Paper hierarchy editing/reorder/move with real LaTeX headings and continuous PaperItem order.

It builds on Core Audit 01, whose paper-specific IDE, frozen revision snapshots, raw lowercase `bbox` import, last-good PDF, three-mode compilation, SyncTeX, restart persistence and source export are re-regressed in this version.

## Implemented core changes

### DOCX image blocks

`packages/document-importer/src/index.ts` now reads DOCX OpenXML relationships and `word/media/*` instead of leaving images as text markers. Extracted image blocks carry binary payload plus DrawingML metadata:

- inline / floating mode
- horizontal placement (`left/right/center/absolute`)
- vertical alignment
- `relativeFrom` information
- X/Y offsets in EMU
- width / height in EMU
- wrap type

A DOCX import commit materializes the binary as a private `AssetRecord` and replaces the temporary import block with a normal Question asset block.

A synthetic DOCX was also modified from `wp:inline` to `wp:anchor`; the importer correctly preserved `mode=floating`, `horizontal=right`, and mapped placement to `right`.

### Ordinary image assets

Paper workspace hydration now materializes image binary data to:

`everflow-assets/<asset-id>.<ext>`

Supported/tested in this audit:

- PNG
- JPEG/JPG
- PDF image asset

The adapter emits real `\\includegraphics`, rather than asset comments/placeholders. `right`, `left`, `above`, `below`, and `inline` receive placement-aware TeX wrappers.

### Question editing

The question detail UI now has a real edit modal for:

- structured mode / raw TeX mode
- topic
- stem
- options
- answer
- difficulty
- analysis
- revision summary

Save calls `PUT /api/questions/:id`; the API creates a new QuestionRevision instead of overwriting history. Existing supplemental formula/image/vector blocks are retained.

### Paper hierarchy

New API:

`PUT /api/papers/:id/structure`

Supported section types:

- questiongroup
- part
- chapter
- section
- subsection
- custom

The server normalizes section/item order, validates parent references, rejects cycles, increments Paper revision, and invalidates the cached workspace for regeneration.

New UI route:

`/app/papers/:id/structure`

It supports:

- section reordering by drag or up/down buttons
- moving questions between sections
- adding/editing sections
- parent-child hierarchy
- direct return to the Paper-specific IDE

The item badge now uses global `PaperItem.order`, so the UI does not imply numbering restarts at every section.

## Core Audit 02 E2E

Command:

`npm run core:audit2:e2e`

Verified:

- DOCX native image detection
- DOCX binary data retained
- inline anchor retained
- synthetic floating-right anchor retained
- DOCX commit creates real private image Asset
- PNG Asset creation and attachment
- JPG Asset creation and attachment
- PDF Asset creation and attachment
- structured question edit creates a new revision
- Paper part/section/subsection hierarchy persists
- questions move between sections
- cyclic section hierarchy is rejected
- generated managed source contains `\\part`, `\\section`, `\\subsection`
- generated source contains real `\\includegraphics`
- Paper workspace writes actual files under `everflow-assets/`
- real XeLaTeX compilation succeeds with PNG/JPG/PDF assets
- all three question source markers remain after hierarchy editing

Latest result:

`[DONE] Core Audit 02: DOCX anchor → image asset → revision UI backend → paper hierarchy → PNG/JPG/PDF XeLaTeX passed`

## Regression

Passed after Core Audit 02 changes:

- `npm test`
- `npm run p9:e2e`
  - Book: 3 pages
  - Exam: 1 page
  - Public: 5 pages
  - Generic user template: 1 page
- `npm run p10:e2e`
  - auth/isolation/persistence/quota/operations/restart
- `npm run p10.7:e2e`
  - document import / AI Gateway / question revisions / assets
- `npm run ide:e2e`
  - source → PDF SyncTeX
  - PDF → source → Question ID
  - failed compile keeps last-good PDF
- `npm run core:audit:e2e`
  - Core Audit 01 remains green
- `npm run core:audit2:e2e`

## Actual PDF result

The Core Audit 02 XeLaTeX PDF contains:

- a DOCX-derived image asset
- PNG/JPG image rendering
- PDF image rendering
- hierarchy headings
- normal question text/options/answer/analysis

The image assets are actual TeX inputs, not screenshots injected into the final PDF after compilation.

## Known core limitations — not marked complete

1. **Exact Word floating layout is not 1:1 yet.**
   DrawingML anchor metadata is preserved, and left/right placement is mapped to LaTeX layout, but arbitrary Word wrap polygons, absolute page offsets, and complex text wrapping are not faithfully reproduced pixel-for-pixel.

2. **Option-specific image placement needs a stronger model.**
   The domain has `optionKey`, but the current renderer does not yet fully insert an asset into one specific option node in every template. This should be a dedicated Core Audit item.

3. **OMML formula fidelity is still simplified.**
   The DOCX pipeline recognizes native formula blocks, but it is not yet a complete Word OMML → LaTeX converter for every construct.

4. **Complex Word tables remain simplified.**
   Basic tables reach LaTeX, but merged cells, exact borders, widths, nested content and floating table behavior are not yet publication-faithful.

5. **DOCX draft attachment remains heuristic for highly irregular documents.**
   Blocks are attached to the nearest detected question. Very irregular teaching notes with multiple images between ambiguous question boundaries still require manual confirmation.

These limitations are intentionally left visible rather than hidden behind a generic “compile success” result.

## UI quality gate

Chromium rendered the current actual `site.css` and UI DOM structures for:

- question editing modal (desktop)
- Paper hierarchy editor (desktop)
- Paper hierarchy editor (390 px mobile)

The hierarchy page remains usable on mobile and the global order badge remains continuous across sections.

