# Proprietary License

Copyright (c) 2026 Everflow·彼时流年若水. All rights reserved.

This repository and all source code, templates, assets, documentation, build scripts,
and related materials are proprietary and confidential unless a file explicitly states otherwise.

No permission is granted to copy, redistribute, sublicense, publish, sell, reverse engineer,
create derivative commercial services from, or publicly disclose any part of this repository
without prior written authorization from the copyright holder.

Third-party components retain their own licenses. Where a third-party file or directory contains
its own license notice, that notice governs that third-party component only.
