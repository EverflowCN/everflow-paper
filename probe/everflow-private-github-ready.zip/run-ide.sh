#!/usr/bin/env bash
set -euo pipefail
for cmd in node tsc latexmk xelatex synctex pdfinfo pdftoppm; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[missing] $cmd"
    exit 1
  fi
done
npm run ide
