# Everflow·彼时流年若水组卷平台 v0.1 - P0–P5 实施报告

## 本轮范围

本轮按已确认技术规格执行 P0–P5，不做最终网站 UI。

## 已完成

1. **P0 TeX Scanner**
   - 以环境栈识别小写 `bbox` / `breakablebbox`。
   - 忽略 `%` 注释、`\verb`、`verbatim`、`Verbatim`、`lstlisting`、`minted` 内伪结构。
   - 支持 `questiongroup / part / chapter / section / subsection` 上下文继承。
   - 记录 `offset / line / column` 源码位置。
   - 提取 `includegraphics / qimage / choiceimage / qsideimage / qtwoimages / choicewithimage` 资源引用。
   - 未闭合/环境不匹配以可恢复 Diagnostics 返回，不让整个文件直接报废。

2. **P1 Question / QuestionRevision**
   - 题目元数据与具体内容版本分离。
   - 支持 `structured / mixed / raw_tex`。

3. **P2 Taxonomy**
   - 大纲树与题目分离；预留大纲版本、主/次知识点、AI confidence。

4. **P3 Paper Builder**
   - `Paper / PaperSection / PaperItem` 独立。
   - `PaperItem` 固定引用 `QuestionRevision`。
   - 拖拽时只需要修改 section/order，不直接修改 TeX。

5. **P4 ZeroOne Adapter**
   - 已接入真实Everflow·彼时流年若水 v31.2 三合一模板。
   - 生成 `questions/generated-web-paper.tex` 与 `web-entry.tex`。
   - 保持用户要求的小写 `bbox`。
   - 生成 `source-map.json`，为后续 Question ↔ Source ↔ SyncTeX ↔ PDF 联动做准备。
   - 网页预览显式关闭 Exam 隐藏封面的奇偶占位页与默认 before-pre 自定义页，避免预览出现无意义空白页/说明页。

6. **P5 Compiler Worker Core**
   - 使用 `latexmk + XeLaTeX + SyncTeX + no-shell-escape`。
   - 支持 preview/export 两种严格度。
   - CompileCoordinator 会将落后 revision 的结果标为 stale。
   - 初版 project hash 工具已建立。

7. **数据库/API/部署骨架**
   - PostgreSQL Prisma schema。
   - `GET /health`。
   - `POST /api/imports/preview`。
   - Docker TeX Live 与生产隔离原则骨架。

## 自动测试结果

单元测试全部通过：

- 注释/verbatim/verb 内伪 bbox 不计入题数。
- bbox 内嵌环境可以正确闭合。
- section/subsection 上下文继承正常。
- 图片引用提取正常。
- 未闭合 bbox 返回 recoverable diagnostic。
- Paper Builder + ZeroOne Adapter 保持小写 bbox。
- CompileCoordinator 正确丢弃旧 revision。

## 真正 LaTeX 编译回归

使用当前系统安装的 `latexmk / XeLaTeX` 和真实Everflow·彼时流年若水 v31.2 模板进行了三模式编译：

- Book：成功。
- Exam：成功。
- Public：成功。

Exam P0–P5 Demo 在修正隐藏前置页逻辑后，真实输出只保留正文 A3 页，已进行 PDF 渲染视觉检查。

## API 冒烟测试

- `/health` 返回正常。
- `/api/imports/preview` 对 `examples/demo-source.tex` 返回 3 道题、3 个标题、0 个错误诊断。

## 下一阶段

P6–P8：

- Next.js Web Shell。
- 左侧 `[试卷][大纲][题库][文件]`。
- 中间 `[题目][源码][属性][差异]`。
- 右侧 PDF.js 真实 PDF。
- Monaco + SourceMap。
- SyncTeX 正向/反向定位。
- `源码 revision / PDF revision` 强制可视化。
