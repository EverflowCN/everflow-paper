import { productionReadiness } from '../apps/api/src/ops/readiness';
const r=productionReadiness();console.log(`Everflow production readiness: ${r.ok?'READY':'BLOCKED'}`);for(const c of r.checks)console.log(`${c.required?'[required]':'[optional]'} ${c.ok?'✓':'✗'} ${c.key}: ${c.detail}`);if(!r.ok){console.error(`Blocking checks: ${r.blocking.join(', ')}`);process.exitCode=2;}
