import { demoWorkspace } from "../apps/api/src/demo-workspace";
import { TemplateRegistry } from "../packages/template-registry/src";
const fs=require("fs"),path=require("path"),cp=require("child_process"),os=require("os");
function assert(ok:any,msg:string){if(!ok)throw new Error(`ASSERT: ${msg}`)}
console.log("[P9] template registry");
let s:any=demoWorkspace.reset();
assert(s.availableTemplates.some((t:any)=>t.id==="zeroone"&&t.version==="31.2"),"built-in zeroone template");
for(const mode of ["book","exam","public"]){
  console.log(`[P9] switch zeroone -> ${mode}`);
  s=demoWorkspace.switchTemplate("zeroone","31.2",mode);
  assert(s.template.mode===mode,`active mode ${mode}`);
  const c:any=demoWorkspace.compile();assert(c.status==="success",`${mode} compile: ${c.status}`);
  const info:any=demoWorkspace.pdfInfo();assert(info.pages>=1,`${mode} pages`);
  console.log(`[P9] ${mode}: ${info.pages} page(s), ${c.durationMs} ms`);
}

console.log("[P9] import user generic template ZIP");
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),"zeroone-p9-fixture-"));
try{
  fs.writeFileSync(path.join(tmp,"main.tex"),String.raw`\documentclass[UTF8]{ctexart}
\usepackage{amsmath}
\newenvironment{bbox}{\par\medskip\noindent}{\par\medskip}
\newenvironment{breakablebbox}{\par\medskip\noindent}{\par\medskip}
\newcommand{\qitem}{\par\noindent}
\newcommand{\fourchoices}[4]{\begin{enumerate}\item #1\item #2\item #3\item #4\end{enumerate}}
\newcommand{\questiongroup}[1]{\section*{#1}}
\begin{document}
\section*{用户模板演示}
% ZEROONE:QUESTIONS
\end{document}
`);
  const manifest={schemaVersion:1,id:"user-demo",name:"用户演示模板",version:"1.0.0",description:"P9 自动化测试模板",adapter:"generic",compiler:"xelatex",questionEnvironment:"bbox",modes:{default:{label:"Default",entrypoint:"main.tex",injectionMarker:"% ZEROONE:QUESTIONS"}}};
  fs.writeFileSync(path.join(tmp,"template.manifest.json"),JSON.stringify(manifest,null,2));
  const zip=path.join(os.tmpdir(),`zeroone-user-template-${Date.now()}.zip`);cp.spawnSync("zip",["-q","-r",zip,"main.tex","template.manifest.json"],{cwd:tmp});
  const reg=new TemplateRegistry(process.cwd(),"demo-user");const imported=reg.importZip(zip,"user-template.zip");assert(imported.manifest.id==="user-demo","import id");
  s=demoWorkspace.switchTemplate("user-demo","1.0.0","default");assert(s.template.adapter==="generic","generic adapter active");
  const c:any=demoWorkspace.compile();assert(c.status==="success",`generic compile failed`);console.log(`[P9] generic: ${demoWorkspace.pdfInfo().pages} page(s), ${c.durationMs} ms`);
  fs.rmSync(zip,{force:true});
}finally{fs.rmSync(tmp,{recursive:true,force:true});}
console.log("[DONE] P9 template lifecycle passed");
