export {};
const fs=require('fs'),path=require('path'),cp=require('child_process');
const root=process.cwd(),port=8814,base=`http://127.0.0.1:${port}`;
function assert(ok:any,msg:string){if(!ok)throw new Error(`ASSERT: ${msg}`)}
function sleep(ms:number){return new Promise(r=>setTimeout(r,ms));}
async function req(url:string,method='GET',body?:any,token?:string,cookie?:string){const r=await fetch(base+url,{method,headers:{'content-type':'application/json',...(token?{authorization:`Bearer ${token}`}:{}) ,...(cookie?{cookie}:{})},body:body===undefined?undefined:JSON.stringify(body)});const type=r.headers.get('content-type')||'',d=type.includes('json')?await r.json():await r.text();return{ok:r.ok,status:r.status,data:d,cookie:r.headers.get('set-cookie')||''};}
async function must(url:string,method='GET',body?:any,token?:string,cookie?:string){const r=await req(url,method,body,token,cookie);if(!r.ok)throw Object.assign(new Error(r.data?.error||`HTTP_${r.status}`),r);return r;}
async function health(){for(let i=0;i<100;i++){try{const r=await req('/health');if(r.ok)return r.data}catch{}await sleep(100)}throw new Error('SERVER_TIMEOUT')}
function start(){return cp.spawn(process.execPath,['dist/apps/api/src/server.js'],{cwd:root,env:{...process.env,PORT:String(port),DATABASE_URL:'',EVERFLOW_BOOTSTRAP_ADMIN_EMAIL:'ops@everflow.local',EVERFLOW_BOOTSTRAP_ADMIN_PASSWORD:'AdminPass123!',EVERFLOW_BOOTSTRAP_ADMIN_NAME:'Ops Admin',EVERFLOW_ADMIN_BASE:'internal-ops-rc4',EVERFLOW_ADMIN_GATE_SECRET:'GateSecretRC4!',EVERFLOW_COMPILE_SANDBOX:'host',EVERFLOW_MAIL_PROVIDER:'dev',EVERFLOW_ACCOUNT_TOKEN_SECRET:'rc4-account-token-secret-12345678901234567890',EVERFLOW_RECOVERY_CODE_PEPPER:'rc4-recovery-pepper-1234567890123456789012',EVERFLOW_TEST_BILLING_RECONCILE_STATUS:'paid'},stdio:['ignore','pipe','pipe']});}
async function run(){
 fs.rmSync(path.join(root,'.runtime'),{recursive:true,force:true});
 const srv=start();srv.stdout.on('data',(d:any)=>process.stdout.write(String(d)));srv.stderr.on('data',(d:any)=>process.stderr.write(String(d)));
 try{
  const h=await health();assert(String(h.version).startsWith('1.0.0-rc.'),'health version rc');
  console.log('[RC4] recovery codes are one-time and hash-backed');
  const reg=(await must('/api/auth/register','POST',{email:'rc4@example.com',password:'MemberPass123!',displayName:'RC4'})).data;const token=reg.token;
  const generated=(await must('/api/auth/recovery-codes/regenerate','POST',{},token)).data;assert(generated.codes.length===8&&generated.displayOnce,'8 recovery codes');
  let sec=(await must('/api/auth/security','GET',undefined,token)).data;assert(sec.recoveryCodes.remaining===8,'remaining 8');
  await must('/api/auth/recovery-codes/verify','POST',{code:generated.codes[0]},token);sec=(await must('/api/auth/security','GET',undefined,token)).data;assert(sec.recoveryCodes.remaining===7,'one-time code consumed');
  const reuse=await req('/api/auth/recovery-codes/verify','POST',{code:generated.codes[0]},token);assert(reuse.status===401,'reused recovery code rejected');
  const recoveryLogin=(await must('/api/auth/recovery-code/login','POST',{email:'rc4@example.com',code:generated.codes[1]})).data;assert(recoveryLogin.recoveryCodesRemaining===6&&recoveryLogin.token,'recovery code can restore login once');

  console.log('[RC4] mail bounce updates account delivery state');
  await must('/api/auth/email-verification/request','POST',{},token);const deliveryDir=path.join(root,'.runtime','mail-delivery');const files=fs.readdirSync(deliveryDir).filter((x:string)=>x.endsWith('.json'));assert(files.length>0,'mail delivery exists');const rec=JSON.parse(fs.readFileSync(path.join(deliveryDir,files.at(-1)),'utf8'));await must('/api/mail/webhooks/delivery','POST',{id:rec.id,type:'bounced',reason:'test hard bounce'});sec=(await must('/api/auth/security','GET',undefined,token)).data;assert(sec.account.emailDeliveryStatus==='bounced','bounce reflected in security state');

  console.log('[RC4] billing reconciliation can settle pending order idempotently');
  const checkout=(await must('/api/billing/checkout','POST',{period:'month',provider:'test'},token)).data;assert(checkout.order.status==='pending','pending order');const reconciled=(await must(`/api/billing/orders/${checkout.order.id}/reconcile`,'POST',{},token)).data;assert(reconciled.order.status==='paid','reconcile paid');const reconciled2=(await must(`/api/billing/orders/${checkout.order.id}/reconcile`,'POST',{},token)).data;assert(reconciled2.order.status==='paid','repeat reconcile safe');const membership=(await must('/api/membership','GET',undefined,token)).data;assert(membership.entitlements.plan==='pro','pro entitlement applied');

  console.log('[RC4] backup/restore drill records are hidden operations data');
  const ops=await must('/api/admin/auth/login','POST',{email:'ops@everflow.local',password:'AdminPass123!',gateSecret:'GateSecretRC4!'});const cookie=ops.cookie.split(';')[0];const before=(await must('/api/admin/backup-drills','GET',undefined,undefined,cookie)).data;assert(Array.isArray(before.plan.steps),'drill plan');const made=(await must('/api/admin/backup-drills','POST',{status:'passed',databaseRestored:true,objectsVerified:true,smokeTestsPassed:true,rpoMinutes:5,rtoMinutes:18,notes:'RC4 isolated restore rehearsal',reason:'RC4 E2E'},undefined,cookie)).data;assert(made.drill.status==='passed','drill recorded');

  console.log('[DONE] RC4 recovery / bounce / reconciliation / restore-drill passed');
 }finally{srv.kill('SIGTERM');}
}
run().catch((e:any)=>{console.error(e);process.exitCode=1});
