const assert=require('assert'),net=require('net'),http=require('http'),crypto=require('crypto'),fs=require('fs'),path=require('path');
import { runtimeProbes } from '../apps/api/src/ops/runtime-probes';
import { billingProvider } from '../apps/api/src/billing/provider';
import { mailProvider, resetMailProviderForTests, mailDeliveryStatus } from '../apps/api/src/mail/provider';
import { passkeyCapability } from '../apps/api/src/auth/passkeys';
async function listen(server:any){return await new Promise<number>(r=>server.listen(0,'127.0.0.1',()=>r(server.address().port)));}
async function main(){
  console.log('[RC3] Redis AUTH/SELECT/PING deep probe');
  let authed=false; const redis=net.createServer((s:any)=>{let buf='';s.on('data',(d:any)=>{buf+=d.toString(); if(buf.includes('AUTH')){authed=true;s.write('+OK\r\n');} if(buf.includes('SELECT'))s.write('+OK\r\n'); if(buf.includes('PING'))s.write('+PONG\r\n');});}); const rp=await listen(redis); process.env.REDIS_URL=`redis://user:pass@127.0.0.1:${rp}/2`; process.env.NODE_ENV='development'; let pr=await runtimeProbes(); const rr=pr.checks.find((x:any)=>x.key==='redis_runtime'); assert(rr&&rr.ok&&rr.mode==='redis-ping'); assert(authed); redis.close();

  console.log('[RC3] Stripe webhook signature verification');
  process.env.STRIPE_WEBHOOK_SECRET='whsec_rc3_test'; const evt={id:'evt_rc3',type:'checkout.session.completed',data:{object:{id:'cs_1',metadata:{everflow_order_id:'test_provider_order'}}}}; const raw=JSON.stringify(evt),t=Math.floor(Date.now()/1000),v1=crypto.createHmac('sha256',process.env.STRIPE_WEBHOOK_SECRET).update(`${t}.${raw}`).digest('hex'); const verified=await billingProvider('stripe').verifyWebhook({'stripe-signature':`t=${t},v1=${v1}`},raw); assert.equal(verified.eventId,'evt_rc3'); assert.equal(verified.status,'paid'); let rejected=false;try{await billingProvider('stripe').verifyWebhook({'stripe-signature':`t=${t},v1=00`},raw);}catch{rejected=true;}assert(rejected);

  console.log('[RC3] Mail retry + delivery status');
  let attempts=0; const ms=http.createServer((req:any,res:any)=>{attempts++;let body='';req.on('data',(d:any)=>body+=d);req.on('end',()=>{if(attempts<3){res.statusCode=503;res.end('retry');}else{res.statusCode=200;res.end('ok');}})}); const mp=await listen(ms); process.env.EVERFLOW_MAIL_PROVIDER='webhook';process.env.EVERFLOW_MAIL_WEBHOOK_URL=`http://127.0.0.1:${mp}/mail`;process.env.EVERFLOW_MAIL_WEBHOOK_SECRET='mail-secret';resetMailProviderForTests();const sent=await mailProvider().send({to:'rc3@example.com',subject:'RC3',text:'hello'});assert.equal(sent.attempts,3);const st:any=mailDeliveryStatus(sent.id);assert.equal(st.status,'accepted');assert.equal(st.attempts,3);ms.close();

  console.log('[RC3] Passkey readiness is capability-gated');
  delete process.env.EVERFLOW_WEBAUTHN_RP_ID; delete process.env.EVERFLOW_WEBAUTHN_ORIGIN; const pk=passkeyCapability(); assert.equal(pk.ready,false); assert(pk.mode==='dependency-missing'||pk.mode==='simplewebauthn');

  console.log('[DONE] RC3 deep probes / signature verification / mail resilience / passkey gate passed');
}
main().catch((e:any)=>{console.error(e);process.exit(1)});
