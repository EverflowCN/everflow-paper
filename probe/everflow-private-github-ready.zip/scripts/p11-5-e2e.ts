const fs=require('fs'),path=require('path'),cp=require('child_process');
import { totp } from '../apps/api/src/ops/totp';
import { objectStore } from '../apps/api/src/storage/object-store';
const root=process.cwd(),port=8825,base=`http://127.0.0.1:${port}`;
function assert(ok:any,msg:string){if(!ok)throw new Error(`ASSERT: ${msg}`)}function sleep(ms:number){return new Promise(r=>setTimeout(r,ms));}
async function raw(url:string,method='GET',body?:any,token?:string,cookie?:string){return fetch(base+url,{method,headers:{...(body!==undefined?{'content-type':'application/json'}:{}),...(token?{authorization:`Bearer ${token}`}:{}) ,...(cookie?{cookie}:{})},body:body===undefined?undefined:JSON.stringify(body)});}
async function req(url:string,method='GET',body?:any,token?:string,cookie?:string){const r=await raw(url,method,body,token,cookie),ct=r.headers.get('content-type')||'',d=ct.includes('json')?await r.json():await r.text();return{ok:r.ok,status:r.status,data:d,cookie:r.headers.get('set-cookie')||''};}
async function must(url:string,method='GET',body?:any,token?:string,cookie?:string){const r=await req(url,method,body,token,cookie);if(!r.ok)throw new Error((r.data as any)?.error||`HTTP_${r.status}`);return r;}
async function health(){for(let i=0;i<100;i++){try{const r=await req('/health');if(r.ok)return r.data as any}catch{}await sleep(100)}throw new Error('SERVER_TIMEOUT')}
async function firstSse(token:string){const controller=new AbortController();const r=await fetch(base+'/api/jobs/events',{headers:{authorization:`Bearer ${token}`},signal:controller.signal});assert(r.ok&&(r.headers.get('content-type')||'').includes('text/event-stream'),'SSE content type');const reader=r.body!.getReader(),dec=new TextDecoder();let text='';for(let i=0;i<8;i++){const part=await reader.read();if(part.done)break;text+=dec.decode(part.value,{stream:true});if(text.includes('event: jobs')&&text.includes('data: '))break;}controller.abort();return text;}
async function run(){
 fs.rmSync(path.join(root,'.runtime'),{recursive:true,force:true});
 const env={...process.env,PORT:String(port),DATABASE_URL:'',EVERFLOW_JOB_DRIVER:'memory',EVERFLOW_COMPILE_SANDBOX:'host',EVERFLOW_OBJECT_STORE:'local',EVERFLOW_BILLING_PROVIDER:'test',EVERFLOW_BOOTSTRAP_ADMIN_EMAIL:'ops@p115.local',EVERFLOW_BOOTSTRAP_ADMIN_PASSWORD:'AdminPass123!',EVERFLOW_ADMIN_BASE:'ops-p115',EVERFLOW_ADMIN_GATE_SECRET:'GateP115',EVERFLOW_OPS_MFA_MASTER_KEY:'mfa-master-p115-not-production'};
 const srv=cp.spawn(process.execPath,['dist/apps/api/src/server.js'],{cwd:root,env,stdio:['ignore','pipe','pipe']});srv.stdout.on('data',(d:any)=>process.stdout.write(String(d)));srv.stderr.on('data',(d:any)=>process.stderr.write(String(d)));
 try{
  const h=await health();assert(/^(0\.9|1\.0)/.test(String(h.version))&&h.objectStore.driver==='local'&&h.billing.provider==='test','v0.9.5 health/object/billing');
  console.log('[P11.5] user realtime SSE + test billing provider');
  const reg=(await must('/api/auth/register','POST',{email:'p115@example.com',password:'MemberPass123!',displayName:'P115'})).data as any,token=reg.token;
  const sse=await firstSse(token);assert(sse.includes('event: jobs')&&sse.includes('"jobs"'),'initial SSE jobs snapshot');
  const checkout=(await must('/api/billing/checkout','POST',{period:'month'},token)).data as any;assert(checkout.checkout.provider==='test'&&checkout.amountCents>0,'test billing checkout');
  console.log('[P11.5] object storage receives compile artifacts');
  const comp=(await must('/api/demo/compile','POST',{},token)).data as any;assert(comp.job?.status==='success'&&comp.job?.result?.storage?.driver==='local','compile stored in object store');const ref=comp.job.result.storage,buf=await objectStore().get(ref.key);assert(buf.length>100&&buf.subarray(0,4).toString()==='%PDF','stored PDF readable');
  console.log('[P11.5] Operations TOTP MFA enrollment and enforcement');
  let login=await must('/api/admin/auth/login','POST',{email:'ops@p115.local',password:'AdminPass123!',gateSecret:'GateP115'}),cookie=login.cookie.split(';')[0];const me=(await must('/api/admin/auth/me','GET',undefined,undefined,cookie)).data as any;assert(me.opsRole==='superadmin'&&!me.mfaEnabled&&me.permissions.includes('mfa.manage'),'ops role permissions');
  const enroll=(await must('/api/admin/mfa/enroll','POST',{},undefined,cookie)).data as any;assert(enroll.secret&&enroll.otpauthUri.startsWith('otpauth://'),'mfa enroll secret');const code=totp(enroll.secret);await must('/api/admin/mfa/confirm','POST',{code},undefined,cookie);await must('/api/admin/auth/logout','POST',{},undefined,cookie);
  const noCode=await req('/api/admin/auth/login','POST',{email:'ops@p115.local',password:'AdminPass123!',gateSecret:'GateP115'});assert(noCode.status===401&&(noCode.data as any).error==='OPS_MFA_REQUIRED','mfa required next login');
  login=await must('/api/admin/auth/login','POST',{email:'ops@p115.local',password:'AdminPass123!',gateSecret:'GateP115',totpCode:totp(enroll.secret)});cookie=login.cookie.split(';')[0];const sh=(await must('/api/admin/system-health','GET',undefined,undefined,cookie)).data as any;assert(/^(0\.9|1\.0)/.test(String(sh.version))&&sh.signals.queuePressure==='normal','ops health');
  console.log('[P11.5] RBAC restricts Staff capabilities');
  const self=(await must('/api/admin/auth/me','GET',undefined,undefined,cookie)).data as any;await must(`/api/admin/users/${self.user.id}`,'PATCH',{opsRole:'support',reason:'P11.5 RBAC test'},undefined,cookie);const users=await req('/api/admin/users','GET',undefined,undefined,cookie);assert(users.ok,'support can read users');const flags=await req('/api/admin/feature-flags','GET',undefined,undefined,cookie);assert(flags.status===403&&String((flags.data as any).error).includes('OPS_PERMISSION_DENIED'),'support denied flags');
  console.log('[DONE] P11.5 realtime / object-store / billing provider / RBAC / TOTP MFA passed');
 } finally {srv.kill('SIGTERM');await Promise.race([new Promise(r=>srv.once('exit',r)),sleep(3000)]);}
}
run().catch((e:any)=>{console.error(e);process.exitCode=1});
export {};
