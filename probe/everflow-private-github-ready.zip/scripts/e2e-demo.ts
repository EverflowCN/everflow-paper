import { buildImportPreview, draftToRevision } from "../packages/question-importer/src";
import { buildDocumentAst } from "../packages/document-ast/src";
import { ZeroOneAdapter } from "../packages/zeroone-adapter/src";
import { compileProject } from "../apps/compiler-worker/src";
import { PaperSnapshot } from "../packages/domain/src";

const fs = require("fs");
const path = require("path");

const root = process.cwd();
const sourcePath = path.join(root, "examples/demo-source.tex");
const tex = fs.readFileSync(sourcePath, "utf8");
const preview = buildImportPreview("demo-source.tex", tex);
if (preview.diagnostics.some(d => d.severity === "error")) {
  console.error(preview.diagnostics);
  process.exit(1);
}
console.log(`[P0] parsed questions=${preview.questionCount}, headings=${preview.headingCount}, assets=${preview.assetCount}`);

const revisions: any = {}, items: any[] = [];
preview.questions.forEach((draft, i) => {
  const qid = `demo-q-${i+1}`, rid = `demo-r-${i+1}`;
  revisions[rid] = draftToRevision(draft, qid, rid);
  items.push({ id: `item-${i+1}`, paperId: "demo-paper", sectionId: i < 2 ? "s-choice" : "s-app", questionId: qid, questionRevisionId: rid, order: i + 1 });
});
const snapshot: PaperSnapshot = {
  paper: { id: "demo-paper", ownerId: "demo-user", title: "Everflow·彼时流年若水 P0-P5 演示卷", templateVersionId: "zeroone-v31.2", mode: "exam", revision: 1, config: {}, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  sections: [
    { id: "s-choice", paperId: "demo-paper", type: "section", title: "单项选择题", order: 1 },
    { id: "s-app", paperId: "demo-paper", type: "section", title: "综合应用题", order: 2 }
  ],
  items,
  revisions
};

const ast = buildDocumentAst(snapshot);
console.log(`[P3/P4] AST nodes=${ast.root.children.length}`);
const adapter = new ZeroOneAdapter({ templateRoot: path.join(root, "templates/zeroone/v31.2"), mode: "exam", includeCover: false, includeToc: false, includeFrontmatter: false });
const generated = adapter.buildProject(ast);
const runtime = path.join(root, ".runtime/demo-exam");
adapter.materialize(generated, runtime);
console.log(`[P4] generated project=${runtime}, sourceMaps=${generated.sourceMaps.length}`);

const result = compileProject({ projectId: "demo-project", projectRevision: 1, workspace: runtime, rootFile: generated.rootFile, compiler: generated.compiler, compileMode: "export", timeoutMs: 30000, texliveImage: "local-texlive" });
console.log(`[P5] compile status=${result.status}, duration=${result.durationMs}ms`);
if (result.status !== "success" || !result.outputs.pdf) {
  console.error(result.outputs.log.slice(-8000));
  process.exit(2);
}
const outDir = path.join(root, "demo-output");
fs.mkdirSync(outDir, { recursive: true });
fs.copyFileSync(result.outputs.pdf, path.join(outDir, "everflow-p0-p5-demo.pdf"));
fs.copyFileSync(path.join(runtime, "questions/generated-web-paper.tex"), path.join(outDir, "generated-web-paper.tex"));
fs.copyFileSync(path.join(runtime, ".zeroone-source-map.json"), path.join(outDir, "source-map.json"));
console.log(`[DONE] ${path.join(outDir, "everflow-p0-p5-demo.pdf")}`);
