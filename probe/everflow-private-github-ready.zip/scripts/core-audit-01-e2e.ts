const fs=require('fs'),path=require('path'),cp=require('child_process');
const root=process.cwd(),port=8845,base=`http://127.0.0.1:${port}`;
function assert(ok:any,msg:string){if(!ok)throw new Error(`ASSERT: ${msg}`)}
function sleep(ms:number){return new Promise(r=>setTimeout(r,ms))}
async function req(url:string,method='GET',body?:any,token?:string,opts:any={}){const r=await fetch(base+url,{method,redirect:opts.redirect||'follow',headers:{...(body!==undefined?{'content-type':'application/json'}:{}),...(token?{authorization:`Bearer ${token}`}:{})},body:body===undefined?undefined:JSON.stringify(body)});const ct=r.headers.get('content-type')||'';const d=ct.includes('json')?await r.json():await r.text();if(!r.ok&&!opts.allowError)throw Object.assign(new Error((d as any)?.error||`HTTP_${r.status}`),{status:r.status,data:d,headers:r.headers});return {status:r.status,data:d,headers:r.headers};}
async function health(){for(let i=0;i<120;i++){try{const h=(await req('/health')).data;if(h.ok)return h}catch{}await sleep(100)}throw new Error('SERVER_TIMEOUT')}
function spawnServer(){const env={...process.env,PORT:String(port),DATABASE_URL:'',EVERFLOW_JOB_DRIVER:'memory',EVERFLOW_COMPILE_SANDBOX:'host',EVERFLOW_OBJECT_STORE_DRIVER:'local'};const srv=cp.spawn(process.execPath,['dist/apps/api/src/server.js'],{cwd:root,env,stdio:['ignore','pipe','pipe']});srv.stdout.on('data',(d:any)=>process.stdout.write(String(d)));srv.stderr.on('data',(d:any)=>process.stderr.write(String(d)));return srv;}
async function stop(srv:any){srv.kill('SIGTERM');await Promise.race([new Promise(r=>srv.once('exit',r)),sleep(2500)]);}
async function createQuestion(token:string,bankId:string,payload:any){return (await req('/api/questions','POST',{bankId,...payload},token)).data.question}
async function compileMode(token:string,paperId:string,mode:string){const sw=(await req(`/api/demo/template?paper=${encodeURIComponent(paperId)}`,'POST',{id:'zeroone',version:'31.2',mode},token)).data;assert(sw.template.mode===mode,`switch ${mode}`);const c=(await req(`/api/demo/compile?paper=${encodeURIComponent(paperId)}`,'POST',{},token)).data;assert(c.status==='success',`${mode} compile success: ${c.error||''}`);const info=(await req(`/api/demo/pdf-info?paper=${encodeURIComponent(paperId)}`,'GET',undefined,token)).data;assert(info.pages>=1&&info.mode===mode,`${mode} pdf info`);return {compile:c,info};}
async function run(){
 fs.rmSync(path.join(root,'.runtime'),{recursive:true,force:true});
 let srv=spawnServer();
 try{
  const h=await health();assert(String(h.version).includes('core-audit'),'core audit server version');
  const reg=(await req('/api/auth/register','POST',{email:'core-audit@example.com',password:'CoreAuditPass123!',displayName:'Core Audit User'})).data,token=reg.token;
  const banks=(await req('/api/banks','GET',undefined,token)).data.banks,bankId=banks[0].id;
  console.log('[CORE] create structured questions + formula/table/vector');
  const q1=await createQuestion(token,bankId,{type:'single_choice',year:2026,difficulty:3,subject:'数据结构',chapter:'排序',topic:'快速排序',score:2,text:'对下列快速排序划分结果，正确的是？',content:{mode:'structured',stemTex:'对下列快速排序划分结果，正确的是？',options:[{key:'A',tex:'A项'},{key:'B',tex:'B项'},{key:'C',tex:'C项'},{key:'D',tex:'D项'}],answerTex:'C',analysisTex:'枢轴划分后左侧元素不大于枢轴。',blocks:[]}});
  const vector=(await req('/api/assets','POST',{kind:'vector',name:'二叉树示意图',mimeType:'application/x-tikz',payload:{tikz:'\\begin{tikzpicture}[scale=.55]\\node[circle,draw] (a) at (0,0) {A};\\node[circle,draw] (b) at (-1,-1) {B};\\node[circle,draw] (c) at (1,-1) {C};\\draw (a)--(b) (a)--(c);\\end{tikzpicture}'}},token)).data.asset;
  const q1b=(await req(`/api/questions/${encodeURIComponent(q1.id)}/blocks`,'POST',{assetId:vector.id,placement:'above'},token)).data.question;
  assert(q1b.content.mode==='structured'&&q1b.content.options.length===4,'vector insertion preserves structured question/options');
  const q2=await createQuestion(token,bankId,{type:'single_choice',year:2026,difficulty:4,subject:'计算机组成原理',chapter:'存储系统',topic:'矩阵与Cache',score:2,text:'设矩阵访问如下，判断局部性。',content:{mode:'structured',stemTex:'设矩阵 $A=\\begin{bmatrix}1&2\\\\3&4\\end{bmatrix}$，判断下列访问的局部性。',options:[{key:'A',tex:'仅时间局部性'},{key:'B',tex:'仅空间局部性'},{key:'C',tex:'二者均有'},{key:'D',tex:'二者均无'}],answerTex:'C',analysisTex:'连续访问兼具空间与时间局部性。',blocks:[]}});
  await req(`/api/questions/${encodeURIComponent(q2.id)}/blocks`,'POST',{tex:'\\par\\smallskip\\begin{center}\\begin{tabular}{c|cc} &0&1\\\\\\hline 0&1&2\\\\1&3&4\\end{tabular}\\end{center}',placement:'below'},token);
  const q3=await createQuestion(token,bankId,{type:'comprehensive',year:2026,difficulty:5,subject:'操作系统',chapter:'虚拟内存',topic:'页表',score:15,text:'综合分析页表地址转换。',content:{mode:'structured',stemTex:'某系统采用三级页表，请给出地址转换过程并分析一次缺页后的访存序列。',options:[],answerTex:'按三级索引逐级访问页表。',analysisTex:'缺页时进入异常处理，装入页面后重新执行故障指令。',blocks:[]}});
  const q4=await createQuestion(token,bankId,{type:'comprehensive',year:2026,difficulty:4,subject:'计算机网络',chapter:'TCP',topic:'拥塞控制',score:12,text:'分析TCP拥塞窗口。',content:{mode:'structured',stemTex:'给定拥塞窗口变化序列，说明慢开始和拥塞避免的切换时刻。',options:[],answerTex:'依据阈值判断。',analysisTex:'窗口指数增长到阈值后进入线性增长。',blocks:[]}});

  console.log('[CORE] TeX import must preserve raw lowercase bbox');
  const rawTex='\\section{图}\\begin{qitems}\\begin{bbox}\\qitem 给定图 $G=(V,E)$，判断最小生成树。\\fourchoices{Prim}{Dijkstra}{Kruskal}{Floyd}\\begin{solution}Kruskal\\end{solution}\\end{bbox}\\end{qitems}';
  const imp=(await req('/api/imports/document/preview','POST',{fileName:'core-raw.tex',dataBase64:Buffer.from(rawTex).toString('base64')},token)).data;
  assert(imp.preview.questionCount===1&&imp.preview.drafts[0].contentMode==='raw_tex','tex preview raw_tex');
  const committed=(await req(`/api/imports/${encodeURIComponent(imp.importJob.id)}/commit`,'POST',{bankId,useAI:false,subject:'数据结构',chapter:'图',tags:['CoreAudit']},token)).data;
  const q5=committed.questions[0];assert(q5.content.mode==='raw_tex'&&q5.content.questionTex.includes('\\begin{bbox}'),'tex commit preserves raw bbox');

  console.log('[CORE] create paper with frozen revision snapshots and fixed answer space');
  const paper=(await req('/api/papers','POST',{title:'Core Audit 408 综合测试卷',mode:'exam',paperSize:'A3',basket:[q1.id,q2.id,q3.id,q4.id,q5.id],answerSpaces:{[q3.id]:{mode:'fixed',heightCm:5}}},token)).data.paper;
  assert(paper.snapshot.items.length===5&&Object.keys(paper.snapshot.revisionSnapshots||{}).length===5,'paper freezes all revisions');
  const redirect=await fetch(base+`/app/papers/${encodeURIComponent(paper.id)}/editor`,{redirect:'manual'});assert(redirect.status===302&&String(redirect.headers.get('location')).includes(`/ide/?paper=${paper.id}`),'paper editor redirects to paper-specific IDE');
  let ws=(await req(`/api/demo/workspace?paper=${encodeURIComponent(paper.id)}`,'GET',undefined,token)).data;
  assert(ws.paper.id===paper.id&&ws.paper.title==='Core Audit 408 综合测试卷','IDE loads selected paper');
  assert(ws.questions.length===5&&ws.questions.some((x:any)=>x.id===q1.id),'IDE contains selected paper questions not demo');
  assert(ws.source.includes(`id="${q1.id}"`)&&ws.source.includes(`id="${q5.id}"`),'source markers use real question IDs');
  assert(ws.source.includes('\\begin{tikzpicture}')&&ws.source.includes('A项')&&ws.source.includes('D项'),'vector plus structured options both render');
  assert(ws.source.includes('\\begin{tabular}')&&ws.source.includes('\\vspace*{5.0cm}'),'table block and answer-space render');
  assert(ws.source.includes('\\begin{bbox}\\qitem 给定图'),'raw TeX imported bbox preserved in generated source');

  console.log('[CORE] edit question after paper creation; old paper must stay pinned');
  const liveQ1=(await req(`/api/questions/${q1.id}`,'GET',undefined,token)).data.question;
  const changed=JSON.parse(JSON.stringify(liveQ1.content));changed.stemTex='【新版题库内容】这段文字绝不能进入已经创建的旧试卷。';
  const updated=(await req(`/api/questions/${q1.id}`,'PUT',{content:changed,changeSummary:'Core audit post-paper edit'},token)).data.question;
  assert(updated.revision>q1b.revision&&updated.content.stemTex.startsWith('【新版题库内容】'),'question edit creates new revision');
  await req(`/api/workspace/save?paper=${paper.id}`,'POST',{},token);

  console.log('[CORE] real XeLaTeX compile in Exam / Book / Public');
  const exam=await compileMode(token,paper.id,'exam');
  const book=await compileMode(token,paper.id,'book');
  const pub=await compileMode(token,paper.id,'public');
  assert(exam.info.pages>=1&&book.info.pages>=1&&pub.info.pages>=1,'all three modes generated PDF');
  await req(`/api/demo/template?paper=${paper.id}`,'POST',{id:'zeroone',version:'31.2',mode:'exam'},token);

  console.log('[CORE] source edit + compile + SyncTeX round trip');
  ws=(await req(`/api/demo/workspace?paper=${paper.id}`,'GET',undefined,token)).data;
  const save=(await req(`/api/demo/source?paper=${paper.id}`,'PUT',{source:ws.source+'\n% CORE-AUDIT-SOURCE-EDIT\n',baseRevision:ws.revision},token)).data;
  assert(save.revision===ws.revision+1,'source revision increments');
  const afterEdit=(await req(`/api/demo/compile?paper=${paper.id}`,'POST',{},token)).data;assert(afterEdit.status==='success'&&afterEdit.displayedRevision===afterEdit.currentRevision,'PDF revision catches current source');
  ws=(await req(`/api/demo/workspace?paper=${paper.id}`,'GET',undefined,token)).data;
  const qmap=ws.sourceMaps.find((m:any)=>m.entityType==='question'&&m.entityId===q2.id);assert(qmap,'q2 source map');
  const fwd=(await req(`/api/demo/synctex/forward?paper=${paper.id}`,'POST',{input:qmap.filePath,line:Math.min(qmap.endLine,qmap.startLine+2),column:0,pageHint:0},token)).data;
  assert(fwd&&fwd.page>=1,'SyncTeX forward');
  const rev=(await req(`/api/demo/synctex/reverse?paper=${paper.id}`,'POST',{page:fwd.page,x:fwd.x,y:fwd.y},token)).data;
  assert(rev&&rev.entity&&rev.entity.entityId===q2.id,'SyncTeX reverse returns same question');

  console.log('[CORE] export source ZIP excludes compile artifacts');
  const ex=(await req(`/api/exports/source?paper=${paper.id}`,'POST',{},token)).data.job;assert(ex.status==='success'&&fs.existsSync(ex.result.path),'export job success');
  const zipList=String(cp.execFileSync('unzip',['-Z1',ex.result.path],{encoding:'utf8'}));assert(zipList.includes('questions/generated-web-paper.tex'),'export contains source');assert(!/\.pdf$|\.aux$|\.log$|\.synctex/i.test(zipList),'export excludes compiled artifacts');

  console.log('[CORE] restart persistence must reopen same paper and frozen question revision');
  await stop(srv);srv=spawnServer();await health();
  const login=(await req('/api/auth/login','POST',{email:'core-audit@example.com',password:'CoreAuditPass123!'})).data,token2=login.token;
  const ws2=(await req(`/api/demo/workspace?paper=${paper.id}`,'GET',undefined,token2)).data;
  assert(ws2.paper.id===paper.id&&ws2.source.includes('CORE-AUDIT-SOURCE-EDIT'),'paper-specific IDE source persists across restart');
  assert(!ws2.source.includes('【新版题库内容】'),'old paper remains frozen after question bank edit and restart');
  assert(ws2.source.includes('对下列快速排序划分结果'),'old pinned stem still in paper');

  console.log('[CORE] paper isolation');
  const second=(await req('/api/papers','POST',{title:'第二份隔离试卷',mode:'exam',basket:[q4.id]},token2)).data.paper;
  const wsSecond=(await req(`/api/demo/workspace?paper=${second.id}`,'GET',undefined,token2)).data;
  assert(wsSecond.questions.length===1&&wsSecond.questions[0].id===q4.id&&!wsSecond.source.includes(q2.id),'second paper workspace isolated');

  // Save final exam PDF for artifact handoff.
  // The last successful Exam PDF is persisted as the last-good artifact; no redundant final compile is needed.
  const pdfRes=await fetch(base+`/api/demo/pdf?paper=${encodeURIComponent(paper.id)}`,{headers:{authorization:`Bearer ${token2}`}});assert(pdfRes.ok,'final PDF fetch');fs.writeFileSync(path.join(root,'.runtime/core-audit01-final.pdf'),Buffer.from(await pdfRes.arrayBuffer()));
  const statePath=path.join(root,'.runtime/core-audit01-state.json');fs.writeFileSync(statePath,JSON.stringify({paperId:paper.id,secondPaperId:second.id,questionIds:[q1.id,q2.id,q3.id,q4.id,q5.id],workspace:ws2,examPages:exam.info.pages,bookPages:book.info.pages,publicPages:pub.info.pages},null,2));
  console.log('[DONE] Core Audit 01: import → revision → paper → IDE → 3 modes → SyncTeX → restart → export passed');
 } finally {if(srv&&srv.exitCode===null)await stop(srv);}
}
run().then(()=>process.exit(0)).catch((e:any)=>{console.error(e);process.exit(1)});
export {};
