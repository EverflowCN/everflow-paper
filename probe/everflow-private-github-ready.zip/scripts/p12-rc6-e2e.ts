export {};
const fs=require('fs'),path=require('path'),cp=require('child_process');
const {FileRepository}=require('../apps/api/src/persistence/file-repository');
const root=process.cwd(),port=8816,base=`http://127.0.0.1:${port}`;
function assert(ok:any,msg:string){if(!ok)throw new Error(`ASSERT: ${msg}`)}
function sleep(ms:number){return new Promise(r=>setTimeout(r,ms));}
async function req(url:string,method='GET',body?:any,token?:string,ua='RC6-E2E'){const r=await fetch(base+url,{method,headers:{'content-type':'application/json','user-agent':ua,...(token?{authorization:`Bearer ${token}`}:{})},body:body===undefined?undefined:JSON.stringify(body)});const type=r.headers.get('content-type')||'',d=type.includes('json')?await r.json():await r.text();return{ok:r.ok,status:r.status,data:d,cookie:r.headers.get('set-cookie')||''};}
async function must(url:string,method='GET',body?:any,token?:string,ua?:string){const r=await req(url,method,body,token,ua);if(!r.ok)throw Object.assign(new Error(r.data?.error||`HTTP_${r.status}`),r);return r;}
async function health(){for(let i=0;i<100;i++){try{const r=await req('/health');if(r.ok)return r.data}catch{}await sleep(100)}throw new Error('SERVER_TIMEOUT')}
function start(){return cp.spawn(process.execPath,['dist/apps/api/src/server.js'],{cwd:root,env:{...process.env,PORT:String(port),DATABASE_URL:'',EVERFLOW_COMPILE_SANDBOX:'host',EVERFLOW_MAIL_PROVIDER:'dev',EVERFLOW_PUBLIC_URL:base,EVERFLOW_ACCOUNT_TOKEN_SECRET:'rc6-account-token-secret-12345678901234567890',EVERFLOW_RECOVERY_CODE_PEPPER:'rc6-recovery-pepper-1234567890123456789012'},stdio:['ignore','pipe','pipe']});}
async function run(){
 fs.rmSync(path.join(root,'.runtime'),{recursive:true,force:true});
 const srv=start();srv.stdout.on('data',(d:any)=>process.stdout.write(String(d)));srv.stderr.on('data',(d:any)=>process.stderr.write(String(d)));
 try{
  const h=await health();assert(h.version==='1.0.0-rc.6','health version rc6');
  console.log('[RC6] verified account gets new-device risk scoring + email notice');
  const reg=(await must('/api/auth/register','POST',{email:'rc6@example.com',password:'MemberPass123!',displayName:'RC6'},undefined,'iPhone Safari')).data;
  const verify=(await must('/api/auth/email-verification/request','POST',{},reg.token,'iPhone Safari')).data;
  assert(verify.devToken,'dev verify token');await must('/api/auth/email-verification/confirm','POST',{token:verify.devToken});
  const login=(await must('/api/auth/login','POST',{email:'rc6@example.com',password:'MemberPass123!'},undefined,'Windows Chrome')).data;
  assert(login.token,'second login token');
  await sleep(150);
  const sessions=(await must('/api/auth/sessions','GET',undefined,login.token,'Windows Chrome')).data.sessions;
  const risky=sessions.find((x:any)=>x.newDevice);assert(risky,'new device marked');assert(risky.riskScore>=35,'risk score persisted');assert((risky.riskReasons||[]).includes('new_user_agent'),'risk reason persisted');
  const out=path.join(root,'.runtime','mail-outbox');const mails=fs.readdirSync(out).filter((x:string)=>x.endsWith('.json')).map((x:string)=>JSON.parse(fs.readFileSync(path.join(out,x),'utf8')));
  assert(mails.some((m:any)=>m.tags?.kind==='security_new_device'),'new-device email generated');
  console.log('[RC6] scheduler lease prevents duplicate leader work');
  const leaseFile=path.join(root,'.runtime','lease-test.json'),repo=new FileRepository(leaseFile);await repo.init();
  const t0='2026-08-09T05:00:00.000Z';assert(await repo.tryAcquireLease('billing','a',60000,t0),'first leader acquires');assert(!(await repo.tryAcquireLease('billing','b',60000,'2026-08-09T05:00:30.000Z')),'second leader blocked');assert(await repo.tryAcquireLease('billing','b',60000,'2026-08-09T05:01:01.000Z'),'expired lease can be taken over');
  const persisted=JSON.parse(fs.readFileSync(leaseFile,'utf8'));assert(persisted.schemaVersion===11,'schema v11');assert(persisted.schedulerLeases?.[0]?.holder==='b','lease persisted');
  console.log('[RC6] Passkey front-end ceremony adapter remains gated by capability');
  const cap=(await must('/api/auth/passkeys/capability')).data;assert(cap.ready===false,'current env passkey remains safely gated');
  const js=fs.readFileSync(path.join(root,'apps/web/static/site/site.js'),'utf8');assert(js.includes('navigator.credentials.create'),'registration ceremony adapter present');assert(js.includes('navigator.credentials.get'),'login ceremony adapter present');
  console.log('[DONE] RC6 risk scoring / device notification / scheduler lease / Passkey adapter passed');
 }finally{srv.kill('SIGTERM');}
}
run().catch((e:any)=>{console.error(e);process.exitCode=1});
