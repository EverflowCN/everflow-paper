const fs=require('fs'),path=require('path'),cp=require('child_process');
const root=process.cwd(),port=8830,base=`http://127.0.0.1:${port}`;
function assert(v:any,m:string){if(!v)throw new Error(`ASSERT: ${m}`)}
const sleep=(ms:number)=>new Promise(r=>setTimeout(r,ms));
async function req(url:string,method='GET',body?:any,token?:string){const r=await fetch(base+url,{method,headers:{...(body!==undefined?{'content-type':'application/json'}:{}),...(token?{authorization:`Bearer ${token}`}:{})},body:body===undefined?undefined:JSON.stringify(body)});const d=(r.headers.get('content-type')||'').includes('json')?await r.json():await r.text();return{ok:r.ok,status:r.status,data:d};}
async function must(url:string,method='GET',body?:any,token?:string){const r=await req(url,method,body,token);if(!r.ok)throw new Error((r.data as any)?.error||`HTTP_${r.status}`);return r.data as any;}
async function wait(){for(let i=0;i<100;i++){try{if((await req('/health')).ok)return}catch{}await sleep(80)}throw new Error('timeout')}
async function run(){
 fs.rmSync(path.join(root,'.runtime'),{recursive:true,force:true});
 const env={...process.env,PORT:String(port),DATABASE_URL:'',EVERFLOW_JOB_DRIVER:'memory',EVERFLOW_COMPILE_SANDBOX:'host',EVERFLOW_OBJECT_STORE:'local',EVERFLOW_BILLING_PROVIDER:'test',EVERFLOW_ACCOUNT_TOKEN_SECRET:'dev-secret-dev-secret-dev-secret-123456',EVERFLOW_REDEEM_PEPPER:'dev-redeem-pepper-dev-redeem-pepper'};
 const srv=cp.spawn(process.execPath,['dist/apps/api/src/server.js'],{cwd:root,env,stdio:['ignore','pipe','pipe']});srv.stdout.on('data',(d:any)=>process.stdout.write(String(d)));srv.stderr.on('data',(d:any)=>process.stderr.write(String(d)));
 try{await wait();
  const h=await must('/health');assert(String(h.version).startsWith('1.0.0-rc'),'RC health version');
  const ready=await must('/ready');assert(ready.mode==='development'&&ready.checks.length>=7,'readiness report');
  console.log('[RC] email verification + password recovery');
  let reg=await must('/api/auth/register','POST',{email:'rc1@example.com',password:'MemberPass123!',displayName:'RC'}),token=reg.token;
  let sec=await must('/api/auth/security','GET',undefined,token);assert(!sec.account.emailVerifiedAt,'starts unverified');
  const vr=await must('/api/auth/email-verification/request','POST',{},token);assert(vr.devToken,'development verification token');
  await must('/api/auth/email-verification/confirm','POST',{token:vr.devToken});sec=await must('/api/auth/security','GET',undefined,token);assert(!!sec.account.emailVerifiedAt,'email verified');
  const pr=await must('/api/auth/password/reset/request','POST',{email:'rc1@example.com'});assert(pr.devToken,'development reset token');
  await must('/api/auth/password/reset/confirm','POST',{token:pr.devToken,newPassword:'NewMemberPass123!'});
  const replay=await req('/api/auth/password/reset/confirm','POST',{token:pr.devToken,newPassword:'AnotherPass123!'});assert(!replay.ok,'reset token stale after password hash changes');
  const old=await req('/api/auth/login','POST',{email:'rc1@example.com',password:'MemberPass123!'});assert(old.status===401,'old password rejected');
  const login=await must('/api/auth/login','POST',{email:'rc1@example.com',password:'NewMemberPass123!'});token=login.token;
  console.log('[RC] payment webhook idempotency');
  const co=await must('/api/billing/checkout','POST',{period:'month'},token),order=co.order;assert(order.providerOrderId,'provider order id');
  const evt={eventId:'evt_rc_001',providerOrderId:order.providerOrderId,status:'paid'};
  const w1=await must('/api/billing/webhooks/test','POST',evt);assert(w1.order.status==='paid'&&!w1.idempotent,'first webhook applies');
  const member1=await must('/api/membership','GET',undefined,token),end1=member1.entitlements.subscription.currentPeriodEnd;
  const w2=await must('/api/billing/webhooks/test','POST',evt);assert(w2.idempotent===true,'duplicate event idempotent');
  const member2=await must('/api/membership','GET',undefined,token);assert(member2.entitlements.subscription.currentPeriodEnd===end1,'duplicate does not extend Pro');
  console.log('[DONE] RC account recovery / verification / readiness / webhook idempotency passed');
 }finally{srv.kill('SIGTERM');await Promise.race([new Promise(r=>srv.once('exit',r)),sleep(2000)])}}
run().catch((e:any)=>{console.error(e);process.exitCode=1});export{};
