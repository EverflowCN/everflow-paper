const fs=require('fs'),path=require('path'),cp=require('child_process');
import { FileRepository } from '../apps/api/src/persistence/file-repository';
const root=process.cwd(),port=8828,base=`http://127.0.0.1:${port}`;
function assert(ok:any,msg:string){if(!ok)throw new Error(`ASSERT: ${msg}`)}
function sleep(ms:number){return new Promise(r=>setTimeout(r,ms));}
async function req(url:string,method='GET',body?:any,token?:string,cookie?:string){const r=await fetch(base+url,{method,headers:{...(body!==undefined?{'content-type':'application/json'}:{}),...(token?{authorization:`Bearer ${token}`}:{}) ,...(cookie?{cookie}:{})},body:body===undefined?undefined:JSON.stringify(body)});const ct=r.headers.get('content-type')||'',d=ct.includes('json')?await r.json():await r.text();return{ok:r.ok,status:r.status,data:d,cookie:r.headers.get('set-cookie')||''};}
async function must(url:string,method='GET',body?:any,token?:string,cookie?:string){const r=await req(url,method,body,token,cookie);if(!r.ok)throw new Error((r.data as any)?.error||`HTTP_${r.status}`);return r;}
async function health(){for(let i=0;i<100;i++){try{const r=await req('/health');if(r.ok)return r.data as any}catch{}await sleep(100)}throw new Error('SERVER_TIMEOUT')}
async function run(){
 fs.rmSync(path.join(root,'.runtime'),{recursive:true,force:true});
 const env={...process.env,PORT:String(port),DATABASE_URL:'',EVERFLOW_JOB_DRIVER:'memory',EVERFLOW_COMPILE_SANDBOX:'host',EVERFLOW_OBJECT_STORE:'local',EVERFLOW_BILLING_PROVIDER:'test',EVERFLOW_BOOTSTRAP_ADMIN_EMAIL:'ops@p118.local',EVERFLOW_BOOTSTRAP_ADMIN_PASSWORD:'AdminPass123!',EVERFLOW_ADMIN_BASE:'ops-p118',EVERFLOW_ADMIN_GATE_SECRET:'GateP118'};
 const srv=cp.spawn(process.execPath,['dist/apps/api/src/server.js'],{cwd:root,env,stdio:['ignore','pipe','pipe']});srv.stdout.on('data',(d:any)=>process.stdout.write(String(d)));srv.stderr.on('data',(d:any)=>process.stderr.write(String(d)));
 try{
  const h=await health();assert(String(h.version).startsWith('1.0.0-rc'),'v1.0 RC health');
  console.log('[P11.8] billing orders persist and activate entitlement');
  let reg=(await must('/api/auth/register','POST',{email:'rc@example.com',password:'MemberPass123!',displayName:'RC User'})).data as any;let token=reg.token;
  let orders=(await must('/api/billing/orders','GET',undefined,token)).data as any;assert(orders.orders.length===0,'starts with no orders');
  const checkout=(await must('/api/billing/checkout','POST',{period:'month'},token)).data as any;assert(checkout.order.publicId.startsWith('ORD-')&&checkout.order.status==='pending','persistent pending order');
  orders=(await must('/api/billing/orders','GET',undefined,token)).data as any;assert(orders.orders.length===1&&orders.orders[0].id===checkout.order.id,'order listed');
  const paid=(await must('/api/billing/test/complete','POST',{orderId:checkout.order.id},token)).data as any;assert(paid.order.status==='paid'&&paid.entitlements.plan==='pro','test payment activates Pro');const end1=paid.entitlements.subscription.currentPeriodEnd;
  const paidAgain=(await must('/api/billing/test/complete','POST',{orderId:checkout.order.id},token)).data as any;assert(paidAgain.entitlements.subscription.currentPeriodEnd===end1,'payment completion idempotent');
  const membership=(await must('/api/membership','GET',undefined,token)).data as any;assert(membership.entitlements.plan==='pro'&&membership.entitlements.subscription.source==='payment','membership payment source');

  console.log('[P11.8] account security settings change password and revoke sessions');
  const sec=(await must('/api/auth/security','GET',undefined,token)).data as any;assert(sec.account.email==='rc@example.com'&&sec.session.surface==='app','security summary');
  const wrong=await req('/api/auth/password/change','POST',{currentPassword:'wrong-password',newPassword:'NewMemberPass123!'},token);assert(wrong.status===401&&(wrong.data as any).error==='AUTH_CURRENT_PASSWORD_INVALID','wrong password rejected');
  const changed=await must('/api/auth/password/change','POST',{currentPassword:'MemberPass123!',newPassword:'NewMemberPass123!'},token);assert((changed.data as any).reloginRequired===true,'password change revokes sessions');
  const oldSession=await req('/api/auth/security','GET',undefined,token);assert(oldSession.status===401,'old token revoked');
  const oldLogin=await req('/api/auth/login','POST',{email:'rc@example.com',password:'MemberPass123!'});assert(oldLogin.status===401,'old password invalid');
  const newLogin=(await must('/api/auth/login','POST',{email:'rc@example.com',password:'NewMemberPass123!'})).data as any;token=newLogin.token;
  const revoke=await must('/api/auth/sessions/revoke-all','POST',{},token);assert((revoke.data as any).reloginRequired===true,'revoke all devices');
  const revoked=await req('/api/auth/security','GET',undefined,token);assert(revoked.status===401,'revoked token unusable');

  console.log('[P11.8] Operations UI respects RBAC and exposes billing orders only to permitted Staff');
  let ops=await must('/api/admin/auth/login','POST',{email:'ops@p118.local',password:'AdminPass123!',gateSecret:'GateP118'}),cookie=ops.cookie.split(';')[0];
  const me=(await must('/api/admin/auth/me','GET',undefined,undefined,cookie)).data as any;assert(me.permissions.includes('billing.read'),'superadmin billing permission');
  const adminOrders=(await must('/api/admin/orders','GET',undefined,undefined,cookie)).data as any;assert(adminOrders.orders.some((x:any)=>x.publicId===checkout.order.publicId),'Operations sees order');
  const adminHtml=await must('/ops-p118/','GET',undefined,undefined,cookie);assert(String(adminHtml.data).includes('v1.0 RC')&&String(adminHtml.data).includes('data-permission="billing.read"'),'permission-aware admin markup');
  await must(`/api/admin/users/${me.user.id}`,'PATCH',{opsRole:'support',reason:'P11.8 RBAC UI test'},undefined,cookie);
  const supportMe=(await must('/api/admin/auth/me','GET',undefined,undefined,cookie)).data as any;assert(supportMe.opsRole==='support'&&supportMe.permissions.includes('users.read')&&!supportMe.permissions.includes('billing.read'),'support permission set');
  const deniedOrders=await req('/api/admin/orders','GET',undefined,undefined,cookie);assert(deniedOrders.status===403,'support denied billing orders');
  const users=await req('/api/admin/users','GET',undefined,undefined,cookie);assert(users.ok,'support retains user read');

  console.log('[P11.8] UI route and mobile/settings quality gate');
  const siteJs=fs.readFileSync(path.join(root,'apps/web/static/site/site.js'),'utf8'),siteCss=fs.readFileSync(path.join(root,'apps/web/static/site/site.css'),'utf8'),adminJs=fs.readFileSync(path.join(root,'apps/web/static/admin/admin.js'),'utf8');
  for(const route of ['/app/settings/appearance','/app/settings/latex','/app/settings/security'])assert(siteJs.includes(route),`settings route ${route}`);
  assert(siteJs.includes('appSidebar')&&siteJs.includes('sidebarOverlay'),'mobile drawer exists');
  assert(siteCss.includes('.mobile-menu')&&siteCss.includes('[data-density="compact"]'),'responsive/density CSS');
  assert(adminJs.includes("if(can('billing.read'))")&&adminJs.includes('safeApi')&&adminJs.includes('permissionUI'),'admin fetches by permission and gates UI modules');
  const oldAdmin=await req('/admin','GET');assert(oldAdmin.status===404,'legacy /admin hidden');

  console.log('[P11.8] file repository schema v7 -> v8 migration');
  const mig=path.join(root,'.runtime','migration-v7.json');fs.mkdirSync(path.dirname(mig),{recursive:true});fs.writeFileSync(mig,JSON.stringify({schemaVersion:7,users:[],sessions:[],banks:[],questions:[],assets:[],imports:[],papers:[],projects:[],userTemplates:[],compileUsage:[],aiCredentials:[],aiSettings:[],subscriptions:[],redeemCampaigns:[],redeemCodes:[],redemptions:[],membershipCredits:[],featureFlags:[],riskCases:[],jobs:[],audit:[]}));const repo=new FileRepository(mig);await repo.init();const migrated=JSON.parse(fs.readFileSync(mig,'utf8'));assert(migrated.schemaVersion===11&&Array.isArray(migrated.billingOrders)&&Array.isArray(migrated.users),'schema migrated to v11');
  console.log('[DONE] P11.8 billing orders / account security / RBAC-aware UI / responsive UI / schema migration passed');
 } finally {srv.kill('SIGTERM');await Promise.race([new Promise(r=>srv.once('exit',r)),sleep(3000)]);}
}
run().catch((e:any)=>{console.error(e);process.exitCode=1});
export {};
