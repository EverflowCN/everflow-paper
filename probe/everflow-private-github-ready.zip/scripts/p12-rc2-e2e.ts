const fs=require('fs'),path=require('path'),cp=require('child_process');
const root=process.cwd(),port=8840,base=`http://127.0.0.1:${port}`;
function assert(v:any,m:string){if(!v)throw new Error(`ASSERT: ${m}`)}
const sleep=(ms:number)=>new Promise(r=>setTimeout(r,ms));
async function req(url:string,method='GET',body?:any,token?:string){const r=await fetch(base+url,{method,headers:{...(body!==undefined?{'content-type':'application/json'}:{}),...(token?{authorization:`Bearer ${token}`}:{})},body:body===undefined?undefined:JSON.stringify(body)});const d=(r.headers.get('content-type')||'').includes('json')?await r.json():await r.text();return{ok:r.ok,status:r.status,data:d};}
async function must(url:string,method='GET',body?:any,token?:string){const r=await req(url,method,body,token);if(!r.ok)throw new Error((r.data as any)?.error||`HTTP_${r.status}`);return r.data as any;}
async function wait(){for(let i=0;i<100;i++){try{if((await req('/health')).ok)return}catch{}await sleep(80)}throw new Error('timeout')}
async function run(){
 fs.rmSync(path.join(root,'.runtime'),{recursive:true,force:true});
 const env={...process.env,PORT:String(port),DATABASE_URL:'',EVERFLOW_JOB_DRIVER:'memory',EVERFLOW_COMPILE_SANDBOX:'host',EVERFLOW_OBJECT_STORE:'local',EVERFLOW_BILLING_PROVIDER:'test',EVERFLOW_MAIL_PROVIDER:'dev',EVERFLOW_PUBLIC_URL:base,EVERFLOW_ACCOUNT_TOKEN_SECRET:'dev-secret-dev-secret-dev-secret-123456',EVERFLOW_REDEEM_PEPPER:'dev-redeem-pepper-dev-redeem-pepper'};
 const srv=cp.spawn(process.execPath,['dist/apps/api/src/server.js'],{cwd:root,env,stdio:['ignore','pipe','pipe']});srv.stdout.on('data',(d:any)=>process.stdout.write(String(d)));srv.stderr.on('data',(d:any)=>process.stderr.write(String(d)));
 try{await wait();
   const h=await must('/health');assert(String(h.version||'').startsWith('1.0.0-rc.'),'RC version');assert(h.mail.provider==='dev','dev mail provider');
   const deep=await must('/ready?probe=1');assert(deep.runtime&&Array.isArray(deep.runtime.checks),'deep runtime probes');
   console.log('[RC2] dev mail outbox + email verification');
   const reg=await must('/api/auth/register','POST',{email:'rc2@example.com',password:'MemberPass123!',displayName:'RC2'}),token=reg.token;
   const verify=await must('/api/auth/email-verification/request','POST',{},token);assert(verify.devToken,'verification token in dev');
   const outbox=path.join(root,'.runtime','mail-outbox');const files=fs.readdirSync(outbox).filter((x:string)=>x.endsWith('.json'));assert(files.length===1,'verification mail stored in outbox');
   const msg=JSON.parse(fs.readFileSync(path.join(outbox,files[0]),'utf8'));assert(msg.to==='rc2@example.com'&&msg.text.includes('/verify-email?token='),'verification mail content');
   await must('/api/auth/email-verification/confirm','POST',{token:verify.devToken});
   console.log('[RC2] password reset also delivered through provider');
   const reset=await must('/api/auth/password/reset/request','POST',{email:'rc2@example.com'});assert(reset.devToken,'reset dev token');assert(fs.readdirSync(outbox).filter((x:string)=>x.endsWith('.json')).length===2,'reset mail stored in outbox');
   console.log('[RC2] backup scripts and cloudflare blueprint present');
   for(const f of ['deploy/backup/backup.sh','deploy/backup/restore.sh','deploy/cloudflare/production-rules.example.md'])assert(fs.existsSync(path.join(root,f)),f);
   console.log('[DONE] RC2 mail / runtime probes / deployment assets passed');
 }finally{srv.kill('SIGTERM');await Promise.race([new Promise(r=>srv.once('exit',r)),sleep(2000)])}}
run().catch((e:any)=>{console.error(e);process.exitCode=1});export{};
