const fs=require('fs'),path=require('path'),cp=require('child_process');
const root=process.cwd(),port=8797,base=`http://127.0.0.1:${port}`;
function assert(ok:any,msg:string){if(!ok)throw new Error(`ASSERT: ${msg}`)}
function sleep(ms:number){return new Promise(r=>setTimeout(r,ms))}
async function req(url:string,method='GET',body?:any,token?:string){const r=await fetch(base+url,{method,headers:{'content-type':'application/json',...(token?{authorization:`Bearer ${token}`}:{})},body:body===undefined?undefined:JSON.stringify(body)});const t=r.headers.get('content-type')||'',d=t.includes('json')?await r.json():await r.text();if(!r.ok)throw Object.assign(new Error((d as any)?.error||`HTTP_${r.status}`),{status:r.status});return d as any}
async function wait(){for(let i=0;i<100;i++){try{const h=await req('/health');if(h.ok)return h}catch{}await sleep(100)}throw new Error('SERVER_TIMEOUT')}
async function run(){
  fs.rmSync(path.join(root,'.runtime/persistence'),{recursive:true,force:true});
  const env={...process.env,PORT:String(port),DATABASE_URL:'',EVERFLOW_AI_MASTER_KEY:'everflow-test-master-key-at-least-32-bytes',EVERFLOW_BOOTSTRAP_ADMIN_EMAIL:'admin@everflow.local',EVERFLOW_BOOTSTRAP_ADMIN_PASSWORD:'EverflowPass123!',EVERFLOW_BOOTSTRAP_ADMIN_NAME:'Everflow Admin'};
  const srv=cp.spawn(process.execPath,['dist/apps/api/src/server.js'],{cwd:root,env,stdio:['ignore','pipe','pipe']});srv.stdout.on('data',(d:any)=>process.stdout.write(String(d)));srv.stderr.on('data',(d:any)=>process.stderr.write(String(d)));await wait();
  for(const p of ['/app/vector','/app/formula','/app/papers/demo/inspect','/app/settings/ai']){const r=await fetch(base+p,{redirect:'manual'});assert(r.status===200,`${p} route`) }
  const login=await req('/api/auth/login','POST',{email:'admin@everflow.local',password:'EverflowPass123!'});const token=login.token;
  const created=await req('/api/ai/credentials','POST',{provider:'openai-compatible',baseUrl:'https://api.example.com/v1',model:'vision-pro',apiKey:'test_key_everflow_secret_1234567890',label:'识题模型'},token);assert(created.credential.keyLast4==='7890','masked key last4');assert(!JSON.stringify(created).includes('test_key_everflow_secret'),'API never returns plaintext key');
  const listed=await req('/api/ai/credentials','GET',undefined,token);assert(listed.persistentAvailable===true&&listed.credentials.length===1,'encrypted credential listed');assert(!JSON.stringify(listed).includes('test_key_everflow_secret'),'list never returns plaintext key');
  const raw=fs.readFileSync(path.join(root,'.runtime/persistence/everflow-db.json'),'utf8');assert(!raw.includes('test_key_everflow_secret_1234567890'),'plaintext absent on disk');assert(raw.includes('encryptedKey'),'ciphertext persisted');
  const test=await req('/api/ai/test','POST',{provider:'openai-compatible',baseUrl:'https://api.example.com/v1',model:'vision-pro',apiKey:'test_key_everflow_secret_1234567890'},token);assert(test.ok&&test.validationOnly,'gateway validation endpoint');
  console.log('[DONE] P10.6 branding/vector/formula/blueprint/BYOK encrypted credential checks passed');srv.kill('SIGTERM');
}
run().catch((e:any)=>{console.error(e);process.exitCode=1});
export {};
