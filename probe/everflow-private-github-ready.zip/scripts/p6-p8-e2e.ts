import { demoWorkspace } from "../apps/api/src/demo-workspace";

function assert(ok: any, msg: string) { if (!ok) throw new Error(`ASSERT: ${msg}`); }

console.log("[P6] initialize workspace");
const initial: any = demoWorkspace.reset();
assert(initial.questions.length >= 3, "demo questions");
assert(initial.sourceMaps.filter((m: any) => m.entityType === "question").length >= 3, "question source maps");

console.log("[P7] compile + forward SyncTeX");
const c1: any = demoWorkspace.compile();
assert(c1.status === "success", "initial compile must succeed");
const q1: any = demoWorkspace.publicState().sourceMaps.find((m: any) => m.entityType === "question" && m.entityId === "demo-q-1");
assert(q1, "q1 source map");
const forward: any = demoWorkspace.forward(q1.filePath, q1.startLine + 1, 1, 0);
assert(forward && forward.page >= 1 && forward.x >= 0 && forward.y >= 0, "forward SyncTeX hit");
console.log(`[P7] source -> PDF page=${forward.page} x=${forward.x.toFixed(2)} y=${forward.y.toFixed(2)}`);

console.log("[P8] reverse SyncTeX + SourceMap");
const reverse: any = demoWorkspace.reverse(forward.page, forward.x, forward.y);
assert(reverse && reverse.input.includes("generated-web-paper.tex"), "reverse input file");
assert(reverse.entity?.entityId === "demo-q-1", `reverse entity ${reverse.entity?.entityId}`);
console.log(`[P8] PDF -> ${reverse.input}:${reverse.line} -> ${reverse.entity.entityId}`);

console.log("[P6] revision separation / failed compile keeps old PDF");
const s1: any = demoWorkspace.publicState();
const valid = s1.source;
const save2: any = demoWorkspace.saveSource(valid + "\n% P6-P8 revision test\n", s1.revision);
assert(!save2.conflict && save2.revision === 2, "save revision 2");
const c2: any = demoWorkspace.compile();
assert(c2.status === "success" && c2.displayedRevision === 2, "compile revision 2");
const broken = valid + "\n\\undefinedZeroOneCommandForP6P8\n";
const save3: any = demoWorkspace.saveSource(broken, 2);
assert(!save3.conflict && save3.revision === 3, "save revision 3");
const c3: any = demoWorkspace.compile();
assert(c3.status === "failed", "broken source must fail");
assert(c3.displayedRevision === 2, `old PDF should remain v2, got ${c3.displayedRevision}`);
const restore: any = demoWorkspace.saveSource(valid, 3);
assert(!restore.conflict && restore.revision === 4, "restore revision 4");
const c4: any = demoWorkspace.compile();
assert(c4.status === "success" && c4.displayedRevision === 4, "restored compile v4");

const info: any = demoWorkspace.pdfInfo();
assert(info.pages >= 1, "pdf info pages");
const png: any = demoWorkspace.renderPdfPage(1, 96);
assert(png.length > 1000, "rendered PDF page PNG");

console.log("[DONE] P6–P8 end-to-end passed");
console.log(JSON.stringify({
  sourceRevision: demoWorkspace.publicState().revision,
  pdfRevision: demoWorkspace.publicState().pdfRevision,
  pdfPages: info.pages,
  forward: { page: forward.page, x: forward.x, y: forward.y },
  reverse: { input: reverse.input, line: reverse.line, entityId: reverse.entity.entityId }
}, null, 2));
