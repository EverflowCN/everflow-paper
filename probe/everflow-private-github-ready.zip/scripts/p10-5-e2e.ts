const fs=require('fs'),path=require('path'),cp=require('child_process');
const root=process.cwd(),port=8796,base=`http://127.0.0.1:${port}`;
function assert(ok:any,msg:string){if(!ok)throw new Error(`ASSERT: ${msg}`)}
function sleep(ms:number){return new Promise(r=>setTimeout(r,ms))}
async function req(url:string,method='GET',body?:any,token?:string){const r=await fetch(base+url,{method,headers:{'content-type':'application/json',...(token?{authorization:`Bearer ${token}`}:{})},body:body===undefined?undefined:JSON.stringify(body)});const t=r.headers.get('content-type')||'',d=t.includes('json')?await r.json():await r.text();if(!r.ok)throw Object.assign(new Error((d as any)?.error||`HTTP_${r.status}`),{status:r.status});return d as any}
async function wait(){for(let i=0;i<100;i++){try{const h=await req('/health');if(h.ok)return h}catch{}await sleep(100)}throw new Error('SERVER_TIMEOUT')}
async function run(){
  fs.rmSync(path.join(root,'.runtime/persistence'),{recursive:true,force:true});
  const srv=cp.spawn(process.execPath,['dist/apps/api/src/server.js'],{cwd:root,env:{...process.env,PORT:String(port),DATABASE_URL:''},stdio:['ignore','pipe','pipe']});
  srv.stdout.on('data',(d:any)=>process.stdout.write(String(d)));srv.stderr.on('data',(d:any)=>process.stderr.write(String(d)));await wait();
  for(const p of ['/','/login','/register','/demo','/app','/app/questions','/app/papers','/app/templates','/app/vector','/app/imports','/app/tasks','/app/tutorials','/app/settings','/app/settings/ai']){const r=await fetch(base+p,{redirect:'manual'});assert(r.status===200,`${p} shell route`)}
  const a=await req('/api/auth/register','POST',{email:'shell-a@example.com',password:'ShellPass123!',displayName:'Shell A'});const b=await req('/api/auth/register','POST',{email:'shell-b@example.com',password:'ShellPass123!',displayName:'Shell B'});
  const qa=await req('/api/questions','GET',undefined,a.token),qb=await req('/api/questions','GET',undefined,b.token);assert(qa.questions.length===6&&qb.questions.length===6,'starter questions seeded');assert(qa.questions[0].id!==qb.questions[0].id,'question ownership isolation');
  const created=await req('/api/papers','POST',{title:'P10.5 Website Shell Test',mode:'exam',basket:qa.questions.slice(0,3).map((q:any)=>q.id)},a.token);assert(created.paper.title.includes('P10.5'),'paper created');const papers=await req('/api/papers','GET',undefined,a.token);assert(papers.papers.some((p:any)=>p.id===created.paper.id),'paper listed');
  const editor=await fetch(base+`/app/papers/${encodeURIComponent(created.paper.id)}/editor`,{redirect:'manual'});assert(editor.status===302&&editor.headers.get('location')==='/ide/','paper editor routes to IDE');
  console.log('[DONE] P10.5 website shell/routes/question isolation/paper creation passed');srv.kill('SIGTERM');
}
run().catch((e:any)=>{console.error(e);process.exitCode=1});

export {};
