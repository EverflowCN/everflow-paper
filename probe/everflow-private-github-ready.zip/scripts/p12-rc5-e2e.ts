export {};
const fs=require('fs'),path=require('path'),cp=require('child_process');
const root=process.cwd(),port=8815,base=`http://127.0.0.1:${port}`;
function assert(ok:any,msg:string){if(!ok)throw new Error(`ASSERT: ${msg}`)}
function sleep(ms:number){return new Promise(r=>setTimeout(r,ms));}
async function req(url:string,method='GET',body?:any,token?:string,cookie?:string,ua='RC5-E2E'){const r=await fetch(base+url,{method,headers:{'content-type':'application/json','user-agent':ua,...(token?{authorization:`Bearer ${token}`}:{}) ,...(cookie?{cookie}:{})},body:body===undefined?undefined:JSON.stringify(body)});const type=r.headers.get('content-type')||'',d=type.includes('json')?await r.json():await r.text();return{ok:r.ok,status:r.status,data:d,cookie:r.headers.get('set-cookie')||''};}
async function must(url:string,method='GET',body?:any,token?:string,cookie?:string,ua?:string){const r=await req(url,method,body,token,cookie,ua);if(!r.ok)throw Object.assign(new Error(r.data?.error||`HTTP_${r.status}`),r);return r;}
async function health(){for(let i=0;i<100;i++){try{const r=await req('/health');if(r.ok)return r.data}catch{}await sleep(100)}throw new Error('SERVER_TIMEOUT')}
function start(){return cp.spawn(process.execPath,['dist/apps/api/src/server.js'],{cwd:root,env:{...process.env,PORT:String(port),DATABASE_URL:'',EVERFLOW_BOOTSTRAP_ADMIN_EMAIL:'ops@everflow.local',EVERFLOW_BOOTSTRAP_ADMIN_PASSWORD:'AdminPass123!',EVERFLOW_ADMIN_BASE:'internal-ops-rc5',EVERFLOW_ADMIN_GATE_SECRET:'GateSecretRC5!',EVERFLOW_COMPILE_SANDBOX:'host',EVERFLOW_MAIL_PROVIDER:'dev',EVERFLOW_ACCOUNT_TOKEN_SECRET:'rc5-account-token-secret-12345678901234567890',EVERFLOW_RECOVERY_CODE_PEPPER:'rc5-recovery-pepper-1234567890123456789012',EVERFLOW_TEST_BILLING_RECONCILE_STATUS:'paid'},stdio:['ignore','pipe','pipe']});}
async function waitJob(id:string,token:string){for(let i=0;i<100;i++){const j=(await must(`/api/jobs/${id}`,'GET',undefined,token)).data.job;if(['success','failed','cancelled','stale'].includes(j.status))return j;await sleep(50)}throw new Error('JOB_TIMEOUT')}
async function run(){
 fs.rmSync(path.join(root,'.runtime'),{recursive:true,force:true});
 const srv=start();srv.stdout.on('data',(d:any)=>process.stdout.write(String(d)));srv.stderr.on('data',(d:any)=>process.stderr.write(String(d)));
 try{
  const h=await health();assert(h.version==='1.0.0-rc.6','health version rc5');
  console.log('[RC5] device/session governance');
  const a=(await must('/api/auth/register','POST',{email:'rc5@example.com',password:'MemberPass123!',displayName:'RC5'},undefined,undefined,'iPhone Safari')).data;
  const b=(await must('/api/auth/login','POST',{email:'rc5@example.com',password:'MemberPass123!'},undefined,undefined,'Windows Chrome')).data;
  let sessions=(await must('/api/auth/sessions','GET',undefined,a.token)).data.sessions;
  assert(sessions.length===2,'two sessions listed');assert(sessions.some((x:any)=>x.current),'current session marked');assert(sessions.some((x:any)=>String(x.userAgent).includes('Windows')),'user agent recorded');
  const other=sessions.find((x:any)=>!x.current);await must(`/api/auth/sessions/${other.id}`,'DELETE',undefined,a.token);
  sessions=(await must('/api/auth/sessions','GET',undefined,a.token)).data.sessions;assert(sessions.length===1&&sessions[0].current,'single-device revoke');
  console.log('[RC5] recovery-code login remains one-time');
  const codes=(await must('/api/auth/recovery-codes/regenerate','POST',{},a.token)).data.codes;
  const rec=(await must('/api/auth/recovery-code/login','POST',{email:'rc5@example.com',code:codes[0]},undefined,undefined,'Recovery Browser')).data;assert(rec.token,'recovery login token');const reused=await req('/api/auth/recovery-code/login','POST',{email:'rc5@example.com',code:codes[0]});assert(reused.status===401,'recovery code single-use');
  console.log('[RC5] billing reconciliation is a persistent job');
  const checkout=(await must('/api/billing/checkout','POST',{period:'month',provider:'test'},a.token)).data;
  const asyncRec=(await must(`/api/billing/orders/${checkout.order.id}/reconcile-async`,'POST',{},a.token)).data;assert(asyncRec.job?.kind==='billing','billing job created');
  const done=await waitJob(asyncRec.job.id,a.token);assert(done.status==='success','billing job success');const membership=(await must('/api/membership','GET',undefined,a.token)).data;assert(membership.entitlements.plan==='pro','billing job applied entitlement');
  console.log('[RC5] backup manifest + verification report are operations-only');
  const ops=await must('/api/admin/auth/login','POST',{email:'ops@everflow.local',password:'AdminPass123!',gateSecret:'GateSecretRC5!'});const cookie=ops.cookie.split(';')[0];
  const manifest=(await must('/api/admin/backup-verification/manifest','POST',{backupId:'BKP-RC5',appVersion:'1.0.0-rc.6',database:'postgres',objectStore:'minio',files:[{name:'postgres.dump',sha256:'abc',sizeBytes:123}]},undefined,cookie)).data.manifest;assert(manifest.backupId==='BKP-RC5','manifest stored');
  const report=(await must('/api/admin/backup-verification/report','POST',{backupId:'BKP-RC5',status:'passed',manifestVerified:true,databaseVerified:true,objectsVerified:true,smokeTestsPassed:true,rpoMinutes:5,rtoMinutes:20},undefined,cookie)).data.report;assert(report.status==='passed','verification stored');
  const listed=(await must('/api/admin/backup-verification','GET',undefined,undefined,cookie)).data;assert(listed.manifests.length===1&&listed.verifications.length===1,'verification list');
  console.log('[DONE] RC5 sessions / recovery UI backend / billing job / backup manifest passed');
 }finally{srv.kill('SIGTERM');}
}
run().catch((e:any)=>{console.error(e);process.exitCode=1});
