const fs=require('fs'),path=require('path'),cp=require('child_process');
const root=process.cwd(),port=8799,base=`http://127.0.0.1:${port}`;
function assert(ok:any,msg:string){if(!ok)throw new Error(`ASSERT: ${msg}`)}
function sleep(ms:number){return new Promise(r=>setTimeout(r,ms))}
async function req(url:string,method='GET',body?:any,token?:string){const r=await fetch(base+url,{method,headers:{'content-type':'application/json',...(token?{authorization:`Bearer ${token}`}:{})},body:body===undefined?undefined:JSON.stringify(body)});const t=r.headers.get('content-type')||'',d=t.includes('json')?await r.json():await r.text();if(!r.ok)throw Object.assign(new Error((d as any)?.error||`HTTP_${r.status}`),{status:r.status,body:d});return d as any}
async function wait(){for(let i=0;i<100;i++){try{const h=await req('/health');if(h.ok)return}catch{}await sleep(100)}throw new Error('SERVER_TIMEOUT')}
async function run(){
  fs.rmSync(path.join(root,'.runtime/persistence'),{recursive:true,force:true});
  const env={...process.env,PORT:String(port),DATABASE_URL:'',EVERFLOW_BOOTSTRAP_ADMIN_EMAIL:'',ZEROONE_BOOTSTRAP_ADMIN_EMAIL:''};
  const srv=cp.spawn(process.execPath,['dist/apps/api/src/server.js'],{cwd:root,env,stdio:['ignore','pipe','pipe']});srv.stdout.on('data',(d:any)=>process.stdout.write(String(d)));srv.stderr.on('data',(d:any)=>process.stderr.write(String(d)));await wait();
  const a=await req('/api/auth/register','POST',{email:'teacher-a@example.test',password:'EverflowPass123!',displayName:'Teacher A'}),ta=a.token;
  const b=await req('/api/auth/register','POST',{email:'teacher-b@example.test',password:'EverflowPass123!',displayName:'Teacher B'}),tb=b.token;
  const qa=(await req('/api/questions','GET',undefined,ta)).questions,qb=(await req('/api/questions','GET',undefined,tb)).questions;assert(qa.length===6&&qb.length===6,'starter questions isolated');
  const versions=await req('/api/taxonomies/versions','GET',undefined,ta);assert(versions.versions.some((x:any)=>x.id==='408-official-2026')&&versions.versions.some((x:any)=>x.id==='wangdao-408-2026'),'taxonomy versions exposed');
  const map=await req(`/api/questions/${encodeURIComponent(qa[0].id)}/taxonomy-mappings`,'POST',{taxonomyVersionId:'408-official-2026',path:['408','数据结构','排序','快速排序'],source:'manual',confidence:1},ta);assert(map.mapping.path.at(-1)==='快速排序','taxonomy mapping stored');
  await req(`/api/questions/${encodeURIComponent(qa[0].id)}/taxonomy-mappings`,'POST',{taxonomyVersionId:'wangdao-408-2026',path:['数据结构','排序','快速排序'],source:'migration',confidence:.95},ta);
  const relation=await req(`/api/questions/${encodeURIComponent(qa[0].id)}/relations`,'POST',{targetQuestionId:qa[1].id,type:'variant_of',metadata:{note:'E2E 变式关系'}},ta);assert(relation.relation.type==='variant_of','question relation created');
  const rels=await req(`/api/questions/${encodeURIComponent(qa[0].id)}/relations`,'GET',undefined,ta);assert(rels.outgoing.length===1&&rels.outgoing[0].targetQuestionId===qa[1].id,'relation graph query');
  let crossBlocked=false;try{await req(`/api/questions/${encodeURIComponent(qa[0].id)}/relations`,'POST',{targetQuestionId:qb[0].id,type:'similar_to'},ta)}catch(e:any){crossBlocked=e.status===404}assert(crossBlocked,'cross-user relation is blocked');

  const custom=await req('/api/questions','POST',{text:'设 $f(x)=x^2$，则 $f\'(1)$ 等于？',type:'single_choice',difficulty:2,subject:'数学',chapter:'导数',topic:'导数',answerTex:'2',analysisTex:'求导得 2x。',content:{mode:'structured',stemTex:'设 $f(x)=x^2$，则 $f\'(1)$ 等于？',options:[{key:'A',tex:'1'},{key:'B',tex:'2'}],answerTex:'2',analysisTex:'求导得 2x。'}},ta);
  const masked=await req(`/api/questions/${encodeURIComponent(custom.question.id)}/ai-projection?task=paper_selection`,'GET',undefined,ta);assert(masked.projection.answerTex===undefined&&masked.projection.analysisTex===undefined&&masked.projection.content.answerTex===undefined,'AI selection projection hides solution');
  const solve=await req(`/api/questions/${encodeURIComponent(custom.question.id)}/ai-projection?task=solution_generation`,'GET',undefined,ta);assert(solve.projection.answerTex==='2','solution task may see answer');

  const paper=await req('/api/papers','POST',{title:'知识关系 E2E',mode:'exam',basket:[qa[0].id,qa[1].id],answerSpaces:{[qa[0].id]:5,[qa[1].id]:'auto'}},ta);assert(paper.paper.snapshot.items.length===2,'paper freezes item revisions');assert(paper.paper.snapshot.items[0].override.answerSpace.heightCm===5,'answer space override persisted');
  let after=(await req('/api/questions','GET',undefined,ta)).questions;assert(after.find((x:any)=>x.id===qa[0].id).usage.count===1,'usage count increments on paper creation');
  await req('/api/papers','POST',{title:'第二份卷',mode:'book',basket:[qa[0].id]},ta);after=(await req('/api/questions','GET',undefined,ta)).questions;const used=after.find((x:any)=>x.id===qa[0].id);assert(used.usage.count===2&&used.usage.paperCount===2,'usage history tracks multiple papers');

  const tmp=path.join(root,'.runtime','e2e-docx-blocks');fs.mkdirSync(tmp,{recursive:true});const png=path.join(tmp,'dot.png');fs.writeFileSync(png,Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Wl5ZV8AAAAASUVORK5CYII=','base64'));const md=path.join(tmp,'rich.md'),docx=path.join(tmp,'rich.docx');fs.writeFileSync(md,`1. 含公式 $x^2+y^2=1$ 的题目。\n\nA. 1\n\nB. 2\n\n![图](${png})\n\n| A | B |\n|---|---|\n| 1 | 2 |`);cp.execFileSync('pandoc',[md,'-o',docx],{stdio:'ignore'});const preview=await req('/api/imports/document/preview','POST',{fileName:'rich.docx',dataBase64:fs.readFileSync(docx).toString('base64')},ta);const types=(preview.preview.documentBlocks||[]).map((x:any)=>x.type);assert(types.includes('paragraph')&&types.includes('image')&&types.includes('table'),'DOCX native block order contains text/image/table');assert((preview.preview.imageCount||0)>=1,'DOCX image count');assert((preview.preview.formulaCount||0)>=1&&(preview.preview.tableCount||0)>=1,'DOCX OMML formula and table blocks');

  const detail=await req(`/api/questions/${encodeURIComponent(qa[0].id)}`,'GET',undefined,ta);assert(detail.question.taxonomyMappings.length===2,'question detail returns multiple taxonomy mappings');assert(detail.question.usage.count===2,'question detail returns usage summary');
  console.log('[DONE] v0.7.5 taxonomy versions + relation graph + usage analytics + answer space + AI projection + DOCX blocks passed');
  srv.kill('SIGTERM');
}
run().catch((e:any)=>{console.error(e);process.exitCode=1});
export {};
