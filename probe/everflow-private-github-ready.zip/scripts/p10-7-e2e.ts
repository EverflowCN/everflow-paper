const fs=require('fs'),path=require('path'),cp=require('child_process'),http=require('http');
const root=process.cwd(),port=8798,mockPort=9899,base=`http://127.0.0.1:${port}`;
function assert(ok:any,msg:string){if(!ok)throw new Error(`ASSERT: ${msg}`)}
function sleep(ms:number){return new Promise(r=>setTimeout(r,ms))}
async function req(url:string,method='GET',body?:any,token?:string){const r=await fetch(base+url,{method,headers:{'content-type':'application/json',...(token?{authorization:`Bearer ${token}`}:{})},body:body===undefined?undefined:JSON.stringify(body)});const t=r.headers.get('content-type')||'',d=t.includes('json')?await r.json():await r.text();if(!r.ok)throw Object.assign(new Error((d as any)?.error||`HTTP_${r.status}`),{status:r.status,body:d});return d as any}
async function wait(){for(let i=0;i<100;i++){try{const h=await req('/health');if(h.ok)return h}catch{}await sleep(100)}throw new Error('SERVER_TIMEOUT')}
function mockAI(){return http.createServer((rq:any,rs:any)=>{const chunks:any[]=[];rq.on('data',(c:any)=>chunks.push(c));rq.on('end',()=>{const b=JSON.parse(Buffer.concat(chunks).toString('utf8')||'{}'),txt=JSON.stringify(b);let out:any;if(txt.includes('connection_test'))out={ok:true,capability:'text'};else out={questions:[{type:'single_choice',stem_tex:'AI识别：下列关于快速排序的说法正确的是（ ）。',options:[{key:'A',tex:'平均复杂度为 O(n log n)'},{key:'B',tex:'一定稳定'}],answer_tex:'A',analysis_tex:'快速排序平均复杂度为 O(n log n)。',subject:'数据结构',chapter:'排序',topic:'快速排序',difficulty:3,confidence:{stem:.99,options:.95,taxonomy:.98,answer:.9}}]};const body=JSON.stringify({choices:[{message:{content:JSON.stringify(out)}}]});rs.writeHead(200,{'content-type':'application/json','content-length':String(Buffer.byteLength(body))});rs.end(body)});}).listen(mockPort,'127.0.0.1')}
async function run(){
  fs.rmSync(path.join(root,'.runtime/persistence'),{recursive:true,force:true});fs.rmSync(path.join(root,'.runtime/imports'),{recursive:true,force:true});
  const mock=mockAI();
  const env={...process.env,PORT:String(port),DATABASE_URL:'',EVERFLOW_AI_MASTER_KEY:'everflow-test-master-key-at-least-32-bytes',EVERFLOW_AI_ALLOW_HTTP_LOCAL:'1',EVERFLOW_AI_TEST_ALLOW_PRIVATE:'1',EVERFLOW_BOOTSTRAP_ADMIN_EMAIL:'admin@everflow.local',EVERFLOW_BOOTSTRAP_ADMIN_PASSWORD:'EverflowPass123!',EVERFLOW_BOOTSTRAP_ADMIN_NAME:'Everflow Admin'};
  const srv=cp.spawn(process.execPath,['dist/apps/api/src/server.js'],{cwd:root,env,stdio:['ignore','pipe','pipe']});srv.stdout.on('data',(d:any)=>process.stdout.write(String(d)));srv.stderr.on('data',(d:any)=>process.stderr.write(String(d)));await wait();
  const login=await req('/api/auth/login','POST',{email:'admin@everflow.local',password:'EverflowPass123!'}),token=login.token;
  const before=await req('/api/questions','GET',undefined,token);assert(before.questions.length===6,'starter questions');
  const cred=await req('/api/ai/credentials','POST',{provider:'openai-compatible',baseUrl:`http://127.0.0.1:${mockPort}/v1`,model:'mock-vision',apiKey:'test_key_everflow_mock_secret',label:'Mock'},token);
  const tested=await req('/api/ai/gateway/test','POST',{credentialId:cred.credential.id},token);assert(tested.ok===true&&tested.model==='mock-vision','real gateway mock request');
  const routing=await req('/api/ai/task-routing','PUT',{taskRouting:{document_question_recognition:cred.credential.id,similarity_check:cred.credential.id}},token);assert(routing.settings.taskRouting.document_question_recognition===cred.credential.id,'AI task routing persisted');

  const text=`1. 第一题：快速排序平均时间复杂度是（ ）。\nA. O(n)\nB. O(n log n)\nC. O(n^2)\nD. O(1)\n\n2. 第二题：Prim 算法用于求（ ）。\nA. 最短路径\nB. 最小生成树\nC. 拓扑序列\nD. 最大流`;
  const preview=await req('/api/imports/document/preview','POST',{fileName:'batch.txt',dataBase64:Buffer.from(text).toString('base64')},token);assert(preview.preview.questionCount===2,'batch text parse 2');
  const committed=await req(`/api/imports/${preview.job.id}/commit`,'POST',{useAI:false,subject:'数据结构',tags:['E2E批量导入']},token);assert(committed.createdCount===2,'commit deterministic drafts');

  const e2eDir=path.join(root,'.runtime','e2e-docs');fs.mkdirSync(e2eDir,{recursive:true});
  const texPath=path.join(e2eDir,'paper.tex'),pdfPath=path.join(e2eDir,'paper.pdf');fs.writeFileSync(texPath,String.raw`\documentclass{article}\begin{document}1. First question\\A. One\\B. Two\\C. Three\\D. Four\newpage 2. Second question\\A. A\\B. B\\C. C\\D. D\end{document}`);cp.execFileSync('pdflatex',['-interaction=batchmode','-halt-on-error','-output-directory',e2eDir,texPath],{stdio:'ignore'});const pdfPreview=await req('/api/imports/document/preview','POST',{fileName:'paper.pdf',dataBase64:fs.readFileSync(pdfPath).toString('base64')},token);assert(pdfPreview.preview.extractionMode==='pdf-text'&&pdfPreview.preview.questionCount>=2,'text PDF parsed without AI');
  const mdPath=path.join(e2eDir,'questions.md'),docxPath=path.join(e2eDir,'questions.docx');fs.writeFileSync(mdPath,'1. Word question one\n\nA. Alpha\n\nB. Beta\n\nC. Gamma\n\nD. Delta\n\n2. Word question two\n\nA. A\n\nB. B\n\nC. C\n\nD. D');cp.execFileSync('pandoc',[mdPath,'-o',docxPath]);const docxPreview=await req('/api/imports/document/preview','POST',{fileName:'questions.docx',dataBase64:fs.readFileSync(docxPath).toString('base64')},token);assert(docxPreview.preview.extractionMode==='document'&&docxPreview.preview.questionCount>=2,'DOCX parsed through document extractor');

  // Turn a real 2-page text PDF into an image-only PDF to exercise multi-page vision chunking.
  cp.execFileSync('pdftoppm',['-png','-r','100',pdfPath,path.join(e2eDir,'scanpage')],{stdio:'ignore'});
  const scanPdf=path.join(e2eDir,'scan-image.pdf'),pagePdfs:any[]=[];
  for(const n of [1,2]){const t=path.join(e2eDir,`scan-${n}.tex`),o=path.join(e2eDir,`scan-${n}.pdf`);fs.writeFileSync(t,String.raw`\documentclass{standalone}\usepackage{graphicx}\begin{document}\includegraphics{scanpage-${n}.png}\end{document}`);cp.execFileSync('pdflatex',['-interaction=batchmode','-halt-on-error','-output-directory',e2eDir,t],{cwd:e2eDir,stdio:'ignore'});pagePdfs.push(o)}
  cp.execFileSync('pdfunite',[...pagePdfs,scanPdf],{stdio:'ignore'});
  const scanJob=await req('/api/imports/document/preview','POST',{fileName:'scan.pdf',dataBase64:fs.readFileSync(scanPdf).toString('base64')},token);assert(scanJob.preview.extractionMode==='vision-required'&&scanJob.preview.pageCount===2,'image-only PDF detected as two-page vision document');
  const scanAI=await req(`/api/imports/${scanJob.job.id}/ai-recognize`,'POST',{maxPages:2,pagesPerCall:1},token);assert(scanAI.calls.length===2&&scanAI.aiQuestions.length===2,'vision PDF processed in two page chunks');assert(scanAI.aiQuestions[0]._pageStart===1&&scanAI.aiQuestions[1]._pageStart===2,'AI questions retain source page ranges');
  const scanCommit=await req(`/api/imports/${scanJob.job.id}/commit`,'POST',{useAI:true,selectedTemporaryIds:[scanAI.aiQuestions[0].temporaryId],tags:['扫描AI导入']},token);assert(scanCommit.createdCount===1,'selected AI review item only is committed');

  const png='iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Wl5ZV8AAAAASUVORK5CYII=';
  const imgJob=await req('/api/imports/document/preview','POST',{fileName:'scan.png',dataBase64:png},token);assert(imgJob.preview.requiresAI===true,'image requires vision AI');
  const ai=await req(`/api/imports/${imgJob.job.id}/ai-recognize`,'POST',{credentialId:cred.credential.id},token);assert(ai.aiQuestions.length===1,'AI recognition returns one structured question');
  const aiCommit=await req(`/api/imports/${imgJob.job.id}/commit`,'POST',{useAI:true,tags:['AI导入']},token);assert(aiCommit.createdCount===1,'AI result committed');

  const qs=await req('/api/questions','GET',undefined,token);const qid=qs.questions[0].id,baseRev=qs.questions[0].revision;const asset=await req('/api/assets','POST',{kind:'vector',name:'E2E树图',mimeType:'image/svg+xml',payload:{svg:'<svg><circle cx="10" cy="10" r="5"/></svg>',tikz:'\\draw (0,0) circle (1);'}},token);const q1=await req(`/api/questions/${encodeURIComponent(qid)}/blocks`,'POST',{assetId:asset.asset.id,placement:'below'},token);assert(q1.question.revision===baseRev+1&&q1.question.revisions.length>=2,'vector creates new question revision');assert(q1.question.content.blocks.some((x:any)=>x.assetId===asset.asset.id),'vector asset block stored');
  const q2=await req(`/api/questions/${encodeURIComponent(qid)}/blocks`,'POST',{tex:'\\(T(n)=2T(n/2)+n\\)'},token);assert(q2.question.revision===baseRev+2,'formula creates another revision');assert(q2.question.content.blocks.some((x:any)=>x.type==='raw_tex'),'formula raw tex block stored');
  const assets=await req('/api/assets','GET',undefined,token);assert(assets.assets.some((x:any)=>x.id===asset.asset.id),'asset persisted server-side');
  const jobs=await req('/api/imports/jobs','GET',undefined,token);assert(jobs.jobs.length===5&&jobs.jobs.every((x:any)=>!x.sourcePath),'import jobs persisted without leaking source path');
  const after=await req('/api/questions','GET',undefined,token);assert(after.questions.length===10,`expected 10 questions got ${after.questions.length}`);
  const disk=fs.readFileSync(path.join(root,'.runtime/persistence/everflow-db.json'),'utf8');assert(!disk.includes('test_key_everflow_mock_secret'),'AI key plaintext absent on disk');assert(disk.includes('E2E树图'),'asset persisted to repository');
  console.log('[DONE] v0.7 document import + real AI Gateway protocol + question revisions + server assets passed');
  srv.kill('SIGTERM');mock.close();
}
run().catch((e:any)=>{console.error(e);process.exitCode=1});
export {};
