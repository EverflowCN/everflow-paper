# Everflow·彼时流年若水 — Core Audit 01

版本：`1.0.0-core-audit.1`  
日期：2026-08-09

## 目标

本轮停止扩展外围会员/安全功能，集中审查核心路径：

`题目导入 → QuestionRevision → 组卷 → Paper Snapshot → Paper 专属 IDE → Book/Exam/Public → 源码编辑 → XeLaTeX → SyncTeX → 重启恢复 → 源码导出`

测试样本故意包含：结构化四选一、矩阵公式、LaTeX 表格、TikZ 矢量图、综合题留白、长答案/解析、原始小写 `bbox` TeX 导入和多 Section。

## 本轮发现并修复的核心问题

### P0-01 选中的试卷没有真正进入对应 IDE

**原问题**：`/app/papers/:id/editor` 虽然带有试卷 ID，但服务端最终重定向到通用 `/ide/`；IDE 加载的是用户默认 Demo Workspace，而不是选中的 Paper。

**修复**：

- 路由改为 `/ide/?paper=<paperId>`。
- WorkspaceManager 现在按 `userId + paperId` 隔离 Workspace。
- Project ID 改为 `project:<userId>:paper:<paperId>`。
- IDE 所有 workspace scoped API 自动携带 `paper` 参数。
- Compile / Export Worker 从 Project 反查 Paper，并加载对应 Workspace。

**验证**：创建两份不同试卷后，两边源码和题目集合完全隔离；重启后重新打开仍是原 Paper。

### P0-02 旧试卷可能失去历史题目内容

**原问题**：PaperItem 只记录 `questionRevisionId`，而 Question 历史仅保留最近 100 个 Revision。非常旧的试卷存在历史 Revision 被截断后无法恢复原题面的风险。

**修复**：创建 Paper 时，将每个被引用 QuestionRevision 的完整内容冻结到：

`Paper.snapshot.revisionSnapshots`

Paper Workspace 优先读取冻结 Snapshot，而不是读取题库当前版本。

**验证**：创建试卷后修改题库题干生成新 Revision，重启服务器再打开旧试卷，旧题干仍保持原样，新题干没有进入旧试卷。

### P0-03 结构化题插入矢量图/公式后可能丢题干选项

**原问题**：插入 Block 时曾把 `structured` 强行变为 `mixed`，而 mixed renderer 只读取 Blocks，可能丢掉 stem/options/answer/analysis。

**修复**：

- StructuredQuestionContent 支持 supplemental `blocks`。
- 插入 Asset/LaTeX Block 不改变 content mode。
- Structured Renderer 始终保留 stem/options/answer/analysis，再渲染附加 Block。
- 兼容旧数据：与 stemTex 完全相同的历史 TextBlock 自动忽略，避免题干重复渲染。

**验证**：四个选项、答案、解析与 TikZ 同时存在于生成源码和实际 PDF。

### P0-04 编译成功后 PDF 会在 Workspace reload 时被删除

**原问题**：Template Adapter materialize 会先 `rm -rf` Workspace；API 为读取 Worker 新状态而重新加载 Workspace 时，会连刚生成的 `web-entry.pdf` 和 `web-entry.synctex.gz` 一起删除，出现“Job success，但右侧 PDF 不存在”。

**修复**：ZeroOne Adapter 与 Generic Adapter 在重新 materialize 工程时保留 last-good：

- `web-entry.pdf`
- `web-entry.synctex.gz`

源码 Revision 可以继续前进，同时旧 PDF 保持可见，直到新 Revision 编译成功覆盖。

**验证**：Memory Worker 完成后 API reload、服务器重启后 PDF/SyncTeX 均仍可恢复。

### P1-01 TeX 批量录题被错误扁平化为 structured stem

**原问题**：TeX Scanner 能正确取得原始 `bbox`，但 commit 阶段统一转为 structured stem，破坏任意自定义 TeX 语义。

**修复**：DocumentDraft 增加：

- `contentMode: raw_tex`
- `rawTex`

TeX/ZIP-TeX commit 直接生成 `content.mode = raw_tex` 和 `questionTex`，不解析/重写原始题面。

**验证**：导入后的 `\begin{bbox}...\end{bbox}` 原样进入 Paper generated source，并真实 XeLaTeX 成功。

### P1-02 普通题目编辑缺少正式 Revision API

新增：

`PUT /api/questions/:id`

支持 structured / mixed / raw_tex 内容更新；每次编辑调用 appendQuestionRevision，产生新的 `currentRevisionId`，而不是覆盖原内容。

### P1-03 解答题 answerSpace 没进入最终 PDF

- Document AST Question 节点增加 answerSpace。
- Adapter 支持固定留白 `\vspace*{Xcm}`。
- API 同时兼容数字和 `{mode:'fixed',heightCm:...}` 两种输入。

实际测试题使用 5.0 cm 留白，PDF 中可见。

### P1-04 Vector Asset 只生成注释、不真正排版

Paper Workspace hydrate 时根据 Asset 数据补 `renderTex`：

- Vector → TikZ
- Formula → LaTeX

Adapter 根据 above/below/left/right placement 真实插入 LaTeX。

本轮 TikZ 二叉树已实际出现在 PDF。

## Core Audit 01 E2E 结果

专项命令：

```bash
npm run core:audit:e2e
```

验证通过：

- [x] TeX 原样 raw_tex 导入，小写 `bbox` 不被改写
- [x] Structured + TikZ + 选项 + 答案/解析同时保留
- [x] 公式矩阵与表格进入真实 LaTeX
- [x] Paper 创建时冻结 5 个 Revision Snapshot
- [x] `/app/papers/:id/editor` 打开对应 Paper Workspace
- [x] 题库后续编辑不污染旧 Paper
- [x] Exam 真 XeLaTeX：1 physical page (A3 / 2 logical pages)
- [x] Book 真 XeLaTeX：3 pages
- [x] Public 真 XeLaTeX：5 pages
- [x] Managed Source 编辑后 source revision +1
- [x] PDF revision 追上当前 source revision
- [x] Source → SyncTeX → PDF
- [x] PDF → SyncTeX → SourceMap → 同一 Question ID
- [x] Source ZIP 导出不包含 PDF / AUX / LOG / SyncTeX
- [x] API 重启后同一 Paper Workspace 恢复
- [x] 第二份 Paper 与第一份 Paper 隔离

## 原有回归

### Unit

`npm test`：全部通过。

包含 bbox scanner、嵌套环境、标题上下文、图片引用、Paper Builder、CompileCoordinator、SyncTeX parser、跨页文本导入、SSRF 地址判断。

### P9 Template lifecycle

- Book: 3 pages
- Exam: 1 page
- Public: 5 pages
- Generic user template: 1 page

全部真实 XeLaTeX 成功。

### P6–P8 IDE / SyncTeX

- Source → PDF page 1
- PDF → `questions/generated-web-paper.tex:11`
- SourceMap → `demo-q-1`
- failed compile keeps last-good PDF

通过。

### P10

认证、双用户隔离、项目持久化、模板所有权、编译配额、Operations、重启恢复全部通过。

### P10.7

文档导入、AI Gateway protocol、QuestionRevision、服务器 Asset 回归通过。

## 实际 PDF 视觉检查

Core Audit 试卷实际输出中确认：

- TikZ 二叉树可见；
- 四选项仍在；
- Matrix 正常；
- LaTeX table 正常；
- 答案/解析正常；
- 综合题 5 cm 留白正常；
- 原始 raw `bbox` 题正常；
- A3 双逻辑页页脚存在；
- 未观察到明显黑块、裁切或内容重叠。

## 仍需继续处理的核心限制

这些不是本轮虚假标记为完成的项目：

1. **DOCX 浮动图片精确锚点**：当前能取得 inline/floating、顺序和 relationship，但复杂 Word 环绕、左右浮动到 QuestionBlock placement 的精确恢复仍需要继续做。
2. **普通位图 Asset 的 LaTeX materialization**：Vector/TikZ 和 Formula 已闭环；PNG/JPG/PDF 图的 Asset → project file → `\includegraphics` 路径还需要单独做强回归。
3. **题目编辑 UI**：后端 Revision API 已有，Question Detail 页面还需要把题干/选项/答案的实际编辑表单完全接到新接口。
4. **Paper 结构编辑**：当前新建 Paper 自动生成 Objective/Application 两 Section；part/chapter/questiongroup 的可视拖拽编辑仍需要作为下一个 Core Audit 项目检查。
5. **生产多实例 last-good PDF**：当前 File/单机环境通过 workspace + object-store；真实 S3/MinIO 跨实例恢复仍需真服务器 integration test。

## 结论

本轮不是增加外围功能，而是发现并修复了多个会直接导致“选错试卷、旧卷变题、插图丢题、编译成功却没 PDF”的核心断点。修复后，Everflow 的主路径已经能够完整跑通：

`Question → Revision → Paper Snapshot → Paper IDE → 3 Modes → PDF/SyncTeX → Restart → Export`

下一轮建议继续 Core Audit 02，专攻：

`DOCX/图片位置 → Question Block → Asset materialization → Paper 结构编辑 → 最终 PDF`。
