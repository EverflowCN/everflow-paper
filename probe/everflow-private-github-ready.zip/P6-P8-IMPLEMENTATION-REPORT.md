# P6–P8 实施报告

## 状态

| 项目 | 状态 | 验证 |
|---|---|---|
| P6 三栏 IDE | PASS | `/ide/` 可运行 |
| 左侧试卷树 | PASS | Section / Question 可定位 |
| 左侧 408 大纲树 | PASS | Taxonomy → Question |
| 左侧题库 | PASS | 搜索 + Question 选择 |
| 左侧工程文件 | PASS | Managed 文件可编辑标记、模板文件只读 |
| 中间题目视图 | PASS | 展示当前 Question TeX 与大纲上下文 |
| 中间源码视图 | PASS | 行定位、650ms 防抖保存 |
| 中间属性视图 | PASS | Question/Revision 元数据 |
| 中间差异视图 | PASS | Baseline vs Current Managed Source |
| 右侧真实 PDF | PASS | XeLaTeX → PDF → page raster preview |
| 编译日志 | PASS | latexmk/XeLaTeX log drawer |
| source/pdf revision | PASS | 独立展示；失败保留旧 PDF |
| P7 SyncTeX forward | PASS | source line → page/x/y |
| P7 SyncTeX reverse | PASS | PDF x/y → input/line |
| P8 SourceMap | PASS | input line → Question ID |
| 四层联动 | PASS | Taxonomy → Question → Source → PDF → Source → Question |

## 真实 E2E 结果

执行：

```bash
npm run ide:e2e
```

核心结果：

```text
[P7] source -> PDF page=1 x=90.92 y=101.39
[P8] PDF -> questions/generated-web-paper.tex:11 -> demo-q-1
```

并完成 revision 容错：

```text
v1 compile success
v2 source save + compile success
v3 inject invalid TeX + compile failed
PDF remains v2
v4 restore + compile success
```

## API

```text
GET  /api/demo/workspace
PUT  /api/demo/source
POST /api/demo/compile
GET  /api/demo/pdf
GET  /api/demo/pdf-info
GET  /api/demo/pdf-page?page=1
GET  /api/demo/file?path=...
POST /api/demo/synctex/forward
POST /api/demo/synctex/reverse
POST /api/demo/reset
```

## P9 以后

P9 应进入用户模板 ZIP / Template Manifest / TemplateVersion；然后再做真正数据库持久化和账号体系。AI/PDF/Word 批量导题仍不应该先于模板与持久化层。
