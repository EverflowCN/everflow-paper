# ZeroOne Paper v0.4 · P10 实施报告

## 已实现

- `Repository` 抽象，File/PostgreSQL 双 Adapter。
- scrypt 密码哈希、Session token hash、HttpOnly Cookie/Bearer。
- User / Session / QuestionBank / Paper / Project / UserTemplate / CompileUsage / Audit 数据层。
- 用户级 Workspace Runtime 与模板注册表隔离。
- Free/Pro/Admin 编译配额。
- IDE 登录/注册、账户面板、剩余编译次数、手动持久化按钮。
- `/admin/` 管理后台：统计、用户套餐、停用/启用、审计。
- Prisma P10 schema、migration stub、Docker Compose PostgreSQL 16。

## 回归结果

`npm test`：通过。  
`npm run ide:e2e`：通过，真实 SyncTeX 正/反向链未回归。  
`npm run p9:e2e`：通过，Book 3 页、Exam 1 页、Public 5 页、用户 Generic 模板 1 页。  
`npm run p10:e2e`：通过，双用户隔离、私有模板、配额、后台、重启恢复均验证。

## PostgreSQL 验证边界

当前执行容器没有 Docker/PostgreSQL/psql，因此不能对外声称 PostgreSQL 连接已经在本环境实跑。PostgresRepository、SQL bootstrap、Prisma schema 与 docker-compose 已完成；本轮运行验证使用与其共享同一 Repository 契约的 FileRepository。

## 当前安全边界

- 密码不明文保存。
- Session 数据库只保存 token SHA-256。
- 模板 ZIP 保持 P9 路径穿越/大小/入口校验。
- 所有用户数据 API 通过当前 authenticated user 的 `ownerId` 限定。
- 管理接口强制 `role === admin`。
- 编译调用前做用户配额检查。

## 下一阶段建议

P11 应把 compiler core 从 API 进程搬出：Redis/BullMQ 队列、独立 TeX Live Sandbox、编译并发/超时/CPU/RAM/PID 限制；同时将模板二进制与 PDF 输出迁移到 MinIO/S3。之后再做完整题库 CRUD、批量导题与 AI 标签。
