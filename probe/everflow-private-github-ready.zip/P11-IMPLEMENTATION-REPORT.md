# Everflow·彼时流年若水 v0.9 — P11 Persistent Jobs / Worker Architecture

## 1. 本轮目标

P11 将原先由 Web/API 请求直接承担的重任务，统一改造成可持久化、可观察、可取消、可重试并具备源码 Revision 语义的 Job。任务类型统一为：

- `compile`：XeLaTeX / PDF / SyncTeX；
- `import`：PDF / DOCX / TeX / TXT 文档解析；
- `ai`：BYOK AI Gateway 批量识题；
- `export`：源码 ZIP / 后续导出任务。

生产目标拓扑：

```text
Web / API
   ↓
Persistent Job Record
   ↓
Redis + BullMQ
   ├─ Compile Worker → isolated TeX sandbox
   ├─ Import Worker
   ├─ AI Worker
   └─ Export Worker
```

开发/当前验收环境可使用 `EVERFLOW_JOB_DRIVER=memory`，但即使 memory driver，也必须先持久化 Job，再执行处理器，因此 UI、审计、取消、stale 和失败状态不会绕过 Job 模型。

## 2. 数据模型

FileRepository schema 升级到 v7，并新增持久化 `JobRecord`：

```text
id / publicId / ownerId
kind / queueName / status
priority / progress
payload / result / error
attempts / maxAttempts
projectId / projectRevision / staleKey
cancelRequested
createdAt / startedAt / finishedAt / updatedAt
```

状态机：

```text
queued
  ↓
running ↔ retrying
  ├─ success
  ├─ failed
  ├─ cancelled
  └─ stale
```

PostgreSQL Adapter 同步新增 `zo_jobs` 表与 owner/status/staleKey 索引。

## 3. 编译任务

`POST /api/demo/compile` 当前流程：

1. 保存当前 Project/Workspace state；
2. 记录当前源码 Revision；
3. 检查账户状态、Entitlement、日配额、并发数和系统 kill switch；
4. 创建持久化 Compile Job；
5. 入队；
6. Worker 执行真实 XeLaTeX；
7. 记录 PDF Revision / SyncTeX / log；
8. 只有请求 Revision 仍然是当前 Revision 时，才允许新 PDF 成为显示版本。

### stale protection

如果用户已经从 Source v3 编辑到 Source v4，而 v3 编译结果晚到：

```text
v3 Job → stale
v4 Job → 可以成为最新 PDF
```

旧结果不会覆盖新代码对应的 PDF。

P11 E2E 实测构造旧 Revision Job，最终状态为 `stale`，结果记录：

```json
{
  "reason": "SOURCE_REVISION_CHANGED",
  "requestedRevision": 0,
  "currentRevision": 1
}
```

## 4. Import / AI / Export Worker

### Import Worker

保留 v0.7 的 quarantine、安全检查与原生文档解析，并将耗时解析移入 Import Job。结果保留文档页数、题目数及 `requiresAI` 等信息。

### AI Worker

继续使用 Pro BYOK Credential；持久化 Job payload 只引用 Credential ID，不持久化 API Key 明文。支持视觉 PDF 分批调用和文本 Draft 分块识别，并持续更新进度。

### Export Worker

源码 ZIP 由 Worker 生成，并主动排除 PDF、日志、SyncTeX、`.aux/.toc/.out/.fls/.fdb_latexmk` 等编译产物。

## 5. API 与 UI

新增：

```text
GET  /api/jobs
GET  /api/jobs/:id
POST /api/jobs/:id/cancel
POST /api/exports/source
GET  /api/admin/jobs
```

普通 Task Center 已使用真实 Persistent Jobs：

- 全部任务；
- Active；
- Success；
- failed / stale / cancelled；
- Public Job ID；
- progress；
- attempts；
- source Revision；
- result/error。

IDE 编译区显示：

```text
Job Public ID
queued / running / success / failed / stale
Source Revision
PDF Revision
progress
```

Operations 增加 Worker / Queue 观察页，但后台仍不出现在普通 App UI。

## 6. Worker 隔离

参考 Compose 拆成：

```text
API
worker-general  # import / ai / export
worker-compile  # compile only
```

API 和 general worker 不需要 Docker Socket。参考 compose 中 compile worker 的 raw Docker socket 仅用于开发/架构演示；生产环境必须替换为 rootless Docker / Podman、受限 sandbox launcher 或受控 socket proxy，不能把宿主机无限制 Docker 权限暴露给公开服务。

Compile Sandbox 继续执行 v0.8 安全规则：

- network none；
- `--cap-drop ALL`；
- `no-new-privileges`；
- CPU / RAM / PID / timeout；
- read-only root FS；
- `-no-shell-escape`。

## 7. Redis / BullMQ 当前验收边界

生产 driver 已实现为 `EVERFLOW_JOB_DRIVER=bullmq`，并包含：

- `REDIS_URL`；
- 四队列名称；
- Worker kind 分离；
- per-worker concurrency；
- 动态加载 BullMQ；
- Redis 配置；
- Docker Compose Redis service。

**但当前 OpenAI 执行容器无法完成真实 Redis/BullMQ 运行验证：**

1. 内部 npm registry 查询 `bullmq` 返回 404；
2. 当前环境不存在可运行的 Redis 服务；
3. 当前环境不存在可运行 Docker daemon。

因此本报告只声称：**BullMQ 生产驱动代码与部署配置已实现；memory driver 与全部 Persistent Job 语义已在本环境真实执行。** 不声称当前容器已经启动了 Redis/BullMQ 分布式 Worker。

在有公网 npm/Redis/Docker 的部署环境中，仍需执行一轮 P11-Redis 集成测试后才能作为生产验收完成项。

## 8. 本轮真实 E2E

`npm run p11:e2e` 最终通过：

```text
[P11] compile enters persistent job lifecycle
[P11] document import runs through import job
[P11] export worker produces source ZIP task
[P11] operations can inspect worker jobs
[P11] stale revision and cancellation invariants
[DONE] P11 persistent jobs / compile / import / export / stale / cancel passed
```

同时既有回归保持通过：

```text
npm test
npm run ide:e2e
npm run p9:e2e
npm run p10:e2e
npm run p10.5:e2e
npm run p10.6:e2e
npm run p10.7:e2e
npm run p10.7.5:e2e
npm run p10.8:e2e
npm run p10.8.5:e2e
```

其中真实 XeLaTeX / SyncTeX 仍可完成：

```text
Source line
→ PDF page/x/y
→ synctex edit
→ TeX line
→ Question ID
```

## 9. 截图说明

本轮提供：

- Task Center；
- Job Detail；
- Operations Worker/Jobs；
- IDE Async Compile。

当前容器的 Chromium 144 在 GPU/EGL 初始化阶段直接崩溃，无法稳定启动 headless 页面截图。因此交付 PNG 使用 **v0.9 当前真实 CSS/界面结构 + P11 E2E 生成的真实 Persistent Job 数据**进行静态浏览器等价渲染；API 与页面所依赖的数据链由独立真实 E2E 验证。截图不是手工设计稿，但也不应被描述为 Chromium 实机抓屏。

## 10. 下一阶段

P11 后建议：

1. 在真实服务器验证 Redis + BullMQ 分布式 Worker；
2. Redis Job event → SSE/WebSocket，替换前端轮询；
3. Compile Worker 使用 rootless sandbox service；
4. MinIO/S3 统一 PDF/ZIP/Asset 输出；
5. Operations RBAC + TOTP/WebAuthn；
6. 微信/支付宝 Billing Provider；
7. Cloudflare Tunnel/WAF/Turnstile/Rate Limit 正式部署。
