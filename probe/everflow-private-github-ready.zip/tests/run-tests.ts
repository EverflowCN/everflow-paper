import { scanTexDocument } from "../packages/tex-scanner/src";
import { buildImportPreview, draftToRevision } from "../packages/question-importer/src";
import { buildDocumentAst } from "../packages/document-ast/src";
import { ZeroOneAdapter } from "../packages/zeroone-adapter/src";
import { CompileCoordinator, CompileResult } from "../apps/compiler-worker/src";
import { PaperSnapshot } from "../packages/domain/src";
import { analyzeDocumentFile } from "../packages/document-importer/src";
import { isBlockedAddress } from "../apps/api/src/ai/gateway";

const fs = require("fs");
const path = require("path");
function assert(ok: any, msg: string) { if (!ok) throw new Error(`ASSERT: ${msg}`); }
function test(name: string, fn: () => void) { fn(); console.log(`✓ ${name}`); }

const fixture = String.raw`
% \begin{bbox} fake \end{bbox}
\questiongroup{408}
\section{排序}
\begin{bbox}
\qitem A
\begin{center}x\end{center}
\verb|\begin{bbox}| 
\qimage[width=.5\linewidth]{a.png}
\end{bbox}
\begin{verbatim}
\begin{bbox}
not real
\end{bbox}
\end{verbatim}
\subsection{快速排序}
\begin{breakablebbox}
\qitem B
\qtwoimages{x.png}{y.png}
\end{breakablebbox}
`;

test("comment/verbatim/verb 内伪 bbox 被忽略，真实题为 2 道", () => {
  const ir = scanTexDocument(fixture, "fixture.tex");
  const qs = ir.nodes.filter(n => n.type === "question");
  assert(qs.length === 2, `expected 2 got ${qs.length}`);
});

test("环境栈允许 bbox 内嵌套其它环境", () => {
  const ir = scanTexDocument(fixture, "fixture.tex");
  assert(!ir.diagnostics.some(d => d.code === "BBOX_UNCLOSED"), "bbox should close correctly");
});

test("标题上下文继承并在 subsection 更新", () => {
  const ir: any = scanTexDocument(fixture, "fixture.tex");
  const qs = ir.nodes.filter((n: any) => n.type === "question");
  assert(qs[0].headingContext.section.title === "排序", "section context");
  assert(qs[1].headingContext.subsection.title === "快速排序", "subsection context");
});

test("图片引用 qimage/qtwoimages 被提取", () => {
  const p = buildImportPreview("fixture.tex", fixture);
  const paths = p.questions.flatMap(q => q.assets.map(a => a.path));
  assert(paths.includes("a.png") && paths.includes("x.png") && paths.includes("y.png"), JSON.stringify(paths));
});

test("未闭合 bbox 返回可恢复诊断", () => {
  const ir = scanTexDocument("\\begin{bbox} x", "bad.tex");
  assert(ir.diagnostics.some(d => d.code === "BBOX_UNCLOSED" && d.recoverable), "missing BBOX_UNCLOSED");
});

test("Paper Builder + ZeroOne Adapter 保持小写 bbox", () => {
  const preview = buildImportPreview("fixture.tex", fixture);
  const revisions: any = {};
  const items: any[] = [];
  preview.questions.forEach((d, i) => {
    const qid = `q${i+1}`, rid = `r${i+1}`;
    revisions[rid] = draftToRevision(d, qid, rid);
    items.push({ id: `i${i+1}`, paperId: "p1", sectionId: "s1", questionId: qid, questionRevisionId: rid, order: i+1 });
  });
  const snapshot: PaperSnapshot = {
    paper: { id: "p1", ownerId: "u1", title: "408 测试卷", templateVersionId: "v31.2", mode: "exam", revision: 1, config: {}, createdAt: "", updatedAt: "" },
    sections: [{ id: "s1", paperId: "p1", type: "section", title: "测试题", order: 1 }],
    items,
    revisions
  };
  const ast = buildDocumentAst(snapshot);
  const root = path.resolve(process.cwd(), "templates/zeroone/v31.2");
  const adapter = new ZeroOneAdapter({ templateRoot: root, mode: "exam" });
  const generated = adapter.buildProject(ast);
  const qfile = generated.files.find(f => f.path.includes("generated-web-paper"))?.text || "";
  assert(qfile.includes("\\begin{bbox}") && !qfile.includes("\\begin{Bbox}"), "lowercase bbox required");
  assert(generated.sourceMaps.filter(m => m.entityType === "question").length === 2, "source maps");
});

test("CompileCoordinator 丢弃旧 revision", () => {
  const c = new CompileCoordinator(); c.request(10); c.request(11);
  const result: CompileResult = { jobId: "j", projectId: "p", projectRevision: 10, status: "success", outputs: { log: "" }, durationMs: 1 };
  assert(c.accept(result).status === "stale", "revision 10 should be stale after 11 requested");
});

import { parseForwardOutput, parseReverseOutput } from "../packages/synctex/src";

test("SyncTeX CLI 输出可解析多记录", () => {
  const f = parseForwardOutput(`SyncTeX result begin\nOutput:a.pdf\nPage:1\nx:10\ny:20\nh:9\nv:21\nW:30\nH:8\nOutput:a.pdf\nPage:2\nx:40\ny:50\nh:39\nv:51\nW:20\nH:7\nSyncTeX result end`);
  assert(f.length === 2 && f[0].page === 1 && f[1].page === 2, JSON.stringify(f));
  const r = parseReverseOutput(`SyncTeX result begin\nOutput:a.pdf\nInput:questions/a.tex\nLine:12\nColumn:3\nOffset:0\nSyncTeX result end`);
  assert(r.length === 1 && r[0].input === "questions/a.tex" && r[0].line === 12, JSON.stringify(r));
});



test("文本文档批量录题可识别跨页题目", () => {
  const text = `1. 第一题题干\nA. 甲\nB. 乙\nC. 丙\nD. 丁\f本页继续第一题解析信息\n2. 第二题题干\nA. 1\nB. 2\nC. 3\nD. 4`;
  const p:any = analyzeDocumentFile("sample.txt", Buffer.from(text, "utf8"));
  assert(p.questionCount === 2, `expected 2 got ${p.questionCount}`);
  assert(p.drafts[0].pageStart === 1 && p.drafts[0].pageEnd === 2, JSON.stringify(p.drafts[0]));
});

test("AI Gateway 基础 SSRF 地址判断覆盖私网和 loopback", () => {
  assert(isBlockedAddress("127.0.0.1") === true, "loopback blocked");
  assert(isBlockedAddress("10.1.2.3") === true, "rfc1918 blocked");
  assert(isBlockedAddress("192.168.1.1") === true, "rfc1918 blocked");
  assert(isBlockedAddress("8.8.8.8") === false, "public allowed");
});

console.log("All unit tests passed.");
