# Run Everflow in GitHub Codespaces

1. Open the private repository in GitHub.
2. Choose **Code → Codespaces → Create codespace on main**.
3. Wait for `postCreateCommand` to install dependencies and build.
4. In the Codespaces terminal run:

```bash
npm run api
```

5. GitHub forwards port `8787`; open the **Everflow Web** forwarded port.

This is a development/demo runtime. It uses file persistence, memory jobs, local object storage, and host XeLaTeX inside the Codespace. It is not the production topology.
