# Exam section 对齐修复报告

## 问题原因

上一版把 Exam 的标题对齐实现放在 `titlesec` 分支中，但 Exam 后端没有加载 `titlesec`。因此 `00-user-config/09-heading-alignment.tex` 中虽然写了 `ZeroOneExamSectionAlign=left`，该值并没有真正接管 exam-zh 的 `section`。

此外，旧偏移算法直接覆盖 `leftskip/rightskip`，会清除 `\centering` 与 `\raggedleft` 所需的弹性间距。

## 修复方式

- Exam 的 `section/subsection/subsubsection` 改用 `\ctexset` 直接控制。
- 增强总开关关闭时，Exam `section` 明确使用左对齐，同时保留原有字体、中文编号、前后间距、目录和分页逻辑。
- 开启增强功能后，`left/center/right` 及偏移参数真实生效。
- 偏移改为在原有弹性 glue 上叠加固定长度，不再覆盖对齐机制。

## 最小定位测试

同一张 A3 左逻辑页中，标题“ 一、单项选择题 ”的横向坐标：

| 状态 | xMin | xMax | 结果 |
|---|---:|---:|---|
| 默认关闭 | 51.024 pt | 124.524 pt | 左对齐 |
| `center` | 269.392 pt | 342.892 pt | 居中 |
| `right`，右内缩 6mm | 470.752 pt | 544.252 pt | 右对齐并向左内缩 |

## 正式入口回归

- Book：通过。
- Exam：通过，首个 section 已位于左边界。
- Public：通过。
- 致命错误：0。
- Overfull：0。
