# v31.2 图表逐对象局部双块清单

- v31.1 原图调用：69 处。
- 识别为纯文本/代码截图并改为原生 LaTeX：8 处。
- 保留“原图 + 局部隐藏候选”双块：61 处。
- 每个候选块均紧跟对应原图，使用标准 `comment` 环境单独控制。
- 不再存在统一隐藏全部候选稿的 `ZeroOneTikZCandidate` 全局环境。

## 纯文本/代码截图改写

- `questions-by-year/assets/2025/二模/q41_p09_1.png`
- `questions-by-year/assets/2026/一模/q02_p01_1.png`
- `questions-by-year/assets/2026/一模/q10_p02_1.png`
- `questions-by-year/assets/2026/一模/q18_p03_1.png`
- `questions-by-year/assets/2026/一模/q21_p04_1.png`
- `questions-by-year/assets/2026/一模/q26_p05_1.png`
- `questions-by-year/assets/2026/一模/q36_p07_1.png`
- `questions-by-year/assets/2026/一模/q43_p09_1.png`

## 图表双块

| 年份 | 原图资源 | 分类 | 推荐实现 | 原图状态 | 候选状态 | 验收 |
|---|---|---|---|---|---|---|
| 2024 | `questions-by-year/assets/2024/一模/q06_p02_1.png` | 复杂红黑树多组选项 | forest；未逐图通过前保留原图 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2024 | `questions-by-year/assets/2024/一模/q19_p05_1.png` | CPU 数据通路/控制器 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2024 | `questions-by-year/assets/2024/一模/q32_p07_1.png` | 复杂计算机网络拓扑 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2024 | `questions-by-year/assets/2024/一模/q43_p10_1.png` | 位字段/矩形字段图 | bytefield 或等宽 array | 原图显示 | 候选局部隐藏 | 未验收 |
| 2024 | `questions-by-year/assets/2024/一模/q43_p10_2.png` | 普通表格或综合表格 | tabularx / longtable / multirow | 原图显示 | 候选局部隐藏 | 未验收 |
| 2024 | `questions-by-year/assets/2024/一模/q32_p07_1.png` | 复杂计算机网络拓扑 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2024 | `questions-by-year/assets/2024/二模/q33_p07_1.png` | 复杂计算机网络拓扑 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2024 | `questions-by-year/assets/2024/二模/q46_p10_1.png` | 普通表格或综合表格 | tabularx / longtable / multirow | 原图显示 | 候选局部隐藏 | 未验收 |
| 2024 | `questions-by-year/assets/2024/二模/q47_p11_1.png` | 位字段/矩形字段图 | bytefield 或等宽 array | 原图显示 | 候选局部隐藏 | 未验收 |
| 2024 | `questions-by-year/assets/2024/二模/q47_p12_1.png` | 位字段/矩形字段图 | bytefield 或等宽 array | 原图显示 | 候选局部隐藏 | 未验收 |
| 2024 | `questions-by-year/assets/2024/三模/q07_diagram_calibrated.png` | 图/网/十字链表 | TikZ 相对定位 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2024 | `questions-by-year/assets/2024/三模/q24_p04_1.png` | 层次结构图 | forest 或 TikZ 相对定位 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2024 | `questions-by-year/assets/2024/三模/q36_p07_1.png` | 复杂计算机网络拓扑 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2024 | `questions-by-year/assets/2024/三模/q37_p07_1.png` | 复杂计算机网络拓扑 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2024 | `questions-by-year/assets/2024/三模/q46_p11_1.png` | 普通表格或综合表格 | tabularx / longtable / multirow | 原图显示 | 候选局部隐藏 | 未验收 |
| 2024 | `questions-by-year/assets/2024/三模/q47_p12_1.png` | 复杂计算机网络拓扑 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2025 | `questions-by-year/assets/2025/一模/q32_p06_1.png` | 复杂计算机网络拓扑 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2025 | `questions-by-year/assets/2025/一模/q43_p09_1.png` | 位字段/矩形字段图 | bytefield 或等宽 array | 原图显示 | 候选局部隐藏 | 未验收 |
| 2025 | `questions-by-year/assets/2025/一模/q43_p09_2.png` | 普通表格或综合表格 | tabularx / longtable / multirow | 原图显示 | 候选局部隐藏 | 未验收 |
| 2025 | `questions-by-year/assets/2025/一模/q32_p06_1.png` | 复杂计算机网络拓扑 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2025 | `questions-by-year/assets/2025/二模/q30_p06_1.png` | 普通表格或综合表格 | tabularx / longtable / multirow | 原图显示 | 候选局部隐藏 | 未验收 |
| 2025 | `questions-by-year/assets/2025/二模/q33_p07_1.png` | 复杂计算机网络拓扑 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2025 | `questions-by-year/assets/2025/二模/q33_p07_1.png` | 复杂计算机网络拓扑 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2025 | `questions-by-year/assets/2025/二模/q37_p08_1.png` | 复杂计算机网络拓扑 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2025 | `questions-by-year/assets/2025/二模/q43_p10_1.png` | 普通表格或综合表格 | tabularx / longtable / multirow | 原图显示 | 候选局部隐藏 | 未验收 |
| 2025 | `questions-by-year/assets/2025/二模/q43_p10_2.png` | CPU 数据通路/控制器 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2025 | `questions-by-year/assets/2025/二模/q43_p10_3.png` | CPU 数据通路/控制器 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2025 | `questions-by-year/assets/2025/二模/q46_p12_1.png` | 普通表格或综合表格 | tabularx / longtable / multirow | 原图显示 | 候选局部隐藏 | 未验收 |
| 2025 | `questions-by-year/assets/2025/二模/q47_p13_1.png` | 复杂计算机网络拓扑 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/一模/q32_p06_1.png` | 复杂计算机网络拓扑 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/一模/q35_p07_1.png` | 时间线/关系图 | TikZ 相对定位 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/一模/q47_topology_only.png` | 复杂计算机网络拓扑 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/二模/q07_p02_1.png` | 图/网/十字链表 | TikZ 相对定位 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/二模/q17_p05_1.png` | CPU 数据通路/控制器 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/二模/q37_p09_1.png` | 复杂计算机网络拓扑 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/二模/q43_p11_1.png` | CPU 数据通路/控制器 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/二模/q46_p12_1.png` | 普通表格或综合表格 | tabularx / longtable / multirow | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/二模/q47_p13_1.png` | 复杂计算机网络拓扑 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/三模/q06_p02_1.png` | 图/网/十字链表 | TikZ 相对定位 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/三模/q07_p02_1.png` | 图/网/十字链表 | TikZ 相对定位 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/三模/q09_p02_1.png` | 复杂红黑树多组选项 | forest；未逐图通过前保留原图 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/三模/q15_p03_1.png` | 位字段/矩形字段图 | bytefield 或等宽 array | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/三模/q15_p04_1.png` | 普通表格或综合表格 | tabularx / longtable / multirow | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/三模/q15_p04_2.png` | 普通表格或综合表格 | tabularx / longtable / multirow | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/三模/q30_p06_1.png` | 位字段/矩形字段图 | bytefield 或等宽 array | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/三模/q30_p06_2.png` | 层次结构图 | forest 或 TikZ 相对定位 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/三模/q33_p07_1.png` | 复杂计算机网络拓扑 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/三模/q36_p08_1.png` | 复杂计算机网络拓扑 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/三模/q39_p08_1.png` | 复杂计算机网络拓扑 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/三模/q40_p09_1.png` | 复杂计算机网络拓扑 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/三模/q41_p09_1.png` | 图/网/十字链表 | TikZ 相对定位 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/三模/q41_p09_2.png` | 普通表格或综合表格 | tabularx / longtable / multirow | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/三模/q42_p10_1.png` | 普通表格或综合表格 | tabularx / longtable / multirow | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/三模/q43_p11_1.png` | 普通表格或综合表格 | tabularx / longtable / multirow | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/三模/q44_p12_1.png` | CPU 数据通路/控制器 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/三模/q45_p13_1.png` | 普通表格或综合表格 | tabularx / longtable / multirow | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/三模/q45_p13_2.png` | 普通表格或综合表格 | tabularx / longtable / multirow | 原图显示 | 候选局部隐藏 | 未验收 |
| 2026 | `questions-by-year/assets/2026/三模/q47_p14_1.png` | 复杂计算机网络拓扑 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2027 | `questions-by-year/assets/2027/一模/q32_p07_1.png` | 复杂计算机网络拓扑 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2027 | `questions-by-year/assets/2027/一模/q40_p08_1.png` | 复杂计算机网络拓扑 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
| 2027 | `questions-by-year/assets/2027/一模/q47_p13_1.png` | 复杂计算机网络拓扑 | 原图正式输出；TikZ 候选隐藏 | 原图显示 | 候选局部隐藏 | 未验收 |
