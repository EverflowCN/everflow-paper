# 全功能复测报告

本版针对默认值与全部新增功能重新执行了两轮验证。

## 默认值修正

- Exam section 的备用对齐值为 left；标题对齐增强开关默认 false。
- Book、Exam、Public 水印默认 false。
- Exam Print 打印说明默认 false。
- Public Print Notes 默认 false。
- 三模式动态页眉页脚、标题对齐、Public 模块化页面、封面展开页默认均为 false。

## 默认关闭回归

Book、Exam、Public 三个正式入口均通过 XeLaTeX 干净编译，无致命错误、无 Overfull。

## 全部开启组合测试

分别为 Book、Exam、Public 同时开启相关标题对齐、动态页眉页脚、水印、打印说明、Public 自定义页面和同 PDF 封面展开页。三种模式均通过编译，无致命错误、无 Overfull。

## 已修复问题

Public 版权页的模块化信息表原先采用 tabularx，放入可复用内容宏后可能发生正文扫描越界。现改为安全的普通 tabular 固定宽度实现，可在模块化页面中稳定启用。

## 输出行为核对

- Exam Print 默认关闭时不出现“打印说明”；开启后正常出现。
- Book、Exam、Public 开启封面展开页后，最后一页均使用真实展开尺寸约 450mm × 300mm。
- 正常排版中的原封面和正文仍保留。
