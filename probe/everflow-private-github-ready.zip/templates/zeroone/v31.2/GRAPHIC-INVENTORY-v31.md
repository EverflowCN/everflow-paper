# v31 图表对象双轨清单

- 题源中的原图调用总数：69
- 正式输出策略：全部继续使用去水印原图，直到对应候选稿逐对象验收通过。
- 候选稿策略：紧跟在原图源码下方，置于 `ZeroOneTikZCandidate` 环境；默认完全排除。
- 禁止操作：不得全局开启候选环境，不得以“可编译”代替视觉验收。

| 年份 | 源码行 | 原图资源 | 初步分类 | 正式输出 | TikZ/原生候选 | 验收状态 |
|---|---:|---|---|---|---|---|
| 2024 | 67 | `questions-by-year/assets/2024/一模/q06_p02_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2024 | 232 | `questions-by-year/assets/2024/一模/q19_p05_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2024 | 404 | `questions-by-year/assets/2024/一模/q32_p07_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2024 | 529 | `questions-by-year/assets/2024/一模/q43_p10_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2024 | 540 | `questions-by-year/assets/2024/一模/q43_p10_2.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2024 | 599 | `questions-by-year/assets/2024/一模/q32_p07_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2024 | 989 | `questions-by-year/assets/2024/二模/q33_p07_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2024 | 1139 | `questions-by-year/assets/2024/二模/q46_p10_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2024 | 1157 | `questions-by-year/assets/2024/二模/q47_p11_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2024 | 1173 | `questions-by-year/assets/2024/二模/q47_p12_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2024 | 1258 | `questions-by-year/assets/2024/三模/q07_diagram_calibrated.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2024 | 1462 | `questions-by-year/assets/2024/三模/q24_p04_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2024 | 1625 | `questions-by-year/assets/2024/三模/q36_p07_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2024 | 1645 | `questions-by-year/assets/2024/三模/q37_p07_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2024 | 1749 | `questions-by-year/assets/2024/三模/q46_p11_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2024 | 1764 | `questions-by-year/assets/2024/三模/q47_p12_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2025 | 397 | `questions-by-year/assets/2025/一模/q32_p06_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2025 | 530 | `questions-by-year/assets/2025/一模/q43_p09_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2025 | 541 | `questions-by-year/assets/2025/一模/q43_p09_2.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2025 | 601 | `questions-by-year/assets/2025/一模/q32_p06_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2025 | 954 | `questions-by-year/assets/2025/二模/q30_p06_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2025 | 989 | `questions-by-year/assets/2025/二模/q33_p07_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2025 | 1009 | `questions-by-year/assets/2025/二模/q33_p07_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2025 | 1056 | `questions-by-year/assets/2025/二模/q37_p08_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2025 | 1107 | `questions-by-year/assets/2025/二模/q41_p09_1.png` | 待逐图分类 | 去水印原图 | 待建立候选稿 | 未验收 |
| 2025 | 1157 | `questions-by-year/assets/2025/二模/q43_p10_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2025 | 1169 | `questions-by-year/assets/2025/二模/q43_p10_2.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2025 | 1181 | `questions-by-year/assets/2025/二模/q43_p10_3.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2025 | 1234 | `questions-by-year/assets/2025/二模/q46_p12_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2025 | 1252 | `questions-by-year/assets/2025/二模/q47_p13_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 37 | `questions-by-year/assets/2026/一模/q02_p01_1.png` | 待逐图分类 | 去水印原图 | 待建立候选稿 | 未验收 |
| 2026 | 128 | `questions-by-year/assets/2026/一模/q10_p02_1.png` | 待逐图分类 | 去水印原图 | 待建立候选稿 | 未验收 |
| 2026 | 235 | `questions-by-year/assets/2026/一模/q18_p03_1.png` | 待逐图分类 | 去水印原图 | 待建立候选稿 | 未验收 |
| 2026 | 305 | `questions-by-year/assets/2026/一模/q21_p04_1.png` | 待逐图分类 | 去水印原图 | 待建立候选稿 | 未验收 |
| 2026 | 382 | `questions-by-year/assets/2026/一模/q26_p05_1.png` | 待逐图分类 | 去水印原图 | 待建立候选稿 | 未验收 |
| 2026 | 461 | `questions-by-year/assets/2026/一模/q32_p06_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 501 | `questions-by-year/assets/2026/一模/q35_p07_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 521 | `questions-by-year/assets/2026/一模/q36_p07_1.png` | 待逐图分类 | 去水印原图 | 待建立候选稿 | 未验收 |
| 2026 | 626 | `questions-by-year/assets/2026/一模/q43_p09_1.png` | 待逐图分类 | 去水印原图 | 待建立候选稿 | 未验收 |
| 2026 | 702 | `questions-by-year/assets/2026/一模/q47_topology_only.png` | 复杂拓扑/原图优先 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 813 | `questions-by-year/assets/2026/二模/q07_p02_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 929 | `questions-by-year/assets/2026/二模/q17_p05_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 1149 | `questions-by-year/assets/2026/二模/q37_p09_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 1238 | `questions-by-year/assets/2026/二模/q43_p11_1.png` | 待逐图分类 | 去水印原图 | 待建立候选稿 | 未验收 |
| 2026 | 1292 | `questions-by-year/assets/2026/二模/q46_p12_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 1310 | `questions-by-year/assets/2026/二模/q47_p13_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 1397 | `questions-by-year/assets/2026/三模/q06_p02_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 1412 | `questions-by-year/assets/2026/三模/q07_p02_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 1442 | `questions-by-year/assets/2026/三模/q09_p02_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 1515 | `questions-by-year/assets/2026/三模/q15_p03_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 1527 | `questions-by-year/assets/2026/三模/q15_p04_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 1539 | `questions-by-year/assets/2026/三模/q15_p04_2.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 1739 | `questions-by-year/assets/2026/三模/q30_p06_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 1750 | `questions-by-year/assets/2026/三模/q30_p06_2.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 1786 | `questions-by-year/assets/2026/三模/q33_p07_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 1829 | `questions-by-year/assets/2026/三模/q36_p08_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 1869 | `questions-by-year/assets/2026/三模/q39_p08_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 1889 | `questions-by-year/assets/2026/三模/q40_p09_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 1918 | `questions-by-year/assets/2026/三模/q41_p09_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 1929 | `questions-by-year/assets/2026/三模/q41_p09_2.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 1955 | `questions-by-year/assets/2026/三模/q42_p10_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 1977 | `questions-by-year/assets/2026/三模/q43_p11_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 1998 | `questions-by-year/assets/2026/三模/q44_p12_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 2018 | `questions-by-year/assets/2026/三模/q45_p13_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 2028 | `questions-by-year/assets/2026/三模/q45_p13_2.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2026 | 2056 | `questions-by-year/assets/2026/三模/q47_p14_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2027 | 417 | `questions-by-year/assets/2027/一模/q32_p07_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2027 | 507 | `questions-by-year/assets/2027/一模/q40_p08_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
| 2027 | 635 | `questions-by-year/assets/2027/一模/q47_p13_1.png` | 待逐图分类 | 去水印原图 | 已有 v30 候选宏 | 未验收 |
