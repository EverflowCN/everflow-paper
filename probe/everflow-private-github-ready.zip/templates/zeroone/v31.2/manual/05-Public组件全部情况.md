# Everflow·彼时流年若水：Public 独立页面大全

固定顺序：封面 -> 扉页 -> 版权页 -> 题献 -> 前言 -> 打印说明 -> 目录 -> 正文 -> 附录 -> 参考文献 -> 后记 -> 版本记录 -> 封底。

默认装配顺序为“封面 → 前言 → 目录 → 正文 → 封底”。扉页、版权页、题献、打印说明、附录、参考文献、后记和版本记录默认关闭，需要时在各自 `page.tex` 中开启。

每个页面文件夹只需要 `page.tex` 与可选 `assets/`。不再为每页另建 `config.tex`；显示开关、奇偶页、字体、图片、页眉、页脚和左右侧栏都在当前 `page.tex` 顶部修改。

| 顺序 | 文件 | 当前文件负责 | 默认显示 | 默认 side |
|---:|---|---|---|---|
| 正封 | `00-user-config/06-cover-config.tex` + `11-cover-spread.tex` | 统一/自定义/隐藏 | 是 | 独立于 Public 页面装配 |
| 2 | `02-title-page/page.tex` | 扉页的开关、字体、图片、装饰与正文 | 否 | `right` |
| 3 | `03-copyright-page/page.tex` | 版权页的开关、字体、图片、装饰与正文 | 否 | `left` |
| 4 | `04-dedication/page.tex` | 题献的开关、字体、图片、装饰与正文 | 否 | `right` |
| 5 | `05-preface/page.tex` | 前言的开关、字体、图片、装饰与正文 | 是 | `right` |
| 6 | `06-print-notes/page.tex` | 打印说明的开关、字体、图片、装饰与正文 | 否 | `any` |
| 7 | `07-table-of-contents/page.tex` | 目录的开关、字体、图片、装饰与正文 | 是 | `right` |
| 8 | `08-main-content/page.tex` | 正文的开关、字体、图片、装饰与正文 | 是 | `right` |
| 9 | `09-appendix/page.tex` | 附录的开关、字体、图片、装饰与正文 | 否 | `right` |
| 10 | `10-references/page.tex` | 参考文献的开关、字体、图片、装饰与正文 | 否 | `right` |
| 11 | `11-afterword/page.tex` | 后记的开关、字体、图片、装饰与正文 | 否 | `right` |
| 12 | `12-colophon/page.tex` | 版本记录的开关、字体、图片、装饰与正文 | 否 | `left` |
| 封底 | `00-user-config/06-cover-config.tex` + `11-cover-spread.tex` | 统一/自定义/隐藏 | 是 | 独立于 Public 页面装配 |

## 直接修改示例

以参考文献为例，打开 `public-pages/10-references/page.tex`：

```latex
\def\ZeroOnePublicUseReferences{true}
\def\ZeroOnePublicReferencesSide{right}
\def\ZeroOnePublicReferencesShowHeader{false}
\def\ZeroOnePublicReferencesShowFooter{true}
\def\ZeroOnePublicReferencesShowLeftSidebar{false}
\def\ZeroOnePublicReferencesShowRightSidebar{false}
```

同一文件内直接修改字号：

```latex
{\heiti\bfseries\fontsize{24pt}{30pt}\selectfont 参考文献}
{\songti\fontsize{11pt}{18pt}\selectfont 正文}
```

图片放入本页 `assets/`，再使用 `\includegraphics`；绝对定位例子已写在每个 `page.tex` 顶部。

## 全局装饰与奇偶页

- 整本页眉/页脚/左右侧栏：`00-user-config/03-header-footer.tex`；
- 奇偶页总开关：`public-pages/00-assembly/config.tex`，默认 `false`；
- `false` 时不自动补空白页；`true` 时才执行每页的 `right / left / any`。
