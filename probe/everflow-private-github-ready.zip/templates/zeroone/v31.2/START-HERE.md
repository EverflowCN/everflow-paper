# Everflow·彼时流年若水 v21 统一封面说明

- 旧 Book/Exam/Public 正常封面与旧 Public 封底已删除。
- 正常正封面、正常封底、独立完整展开图统一读取 `00-user-config/11-cover-spread.tex`。
- 正常正封面/封底开关位于 `00-user-config/06-cover-config.tex`。
- 可单独编译 `ZeroOne-Book-Cover-Spread.tex`、`ZeroOne-Exam-Cover-Spread.tex`、`ZeroOne-Public-Cover-Spread.tex`。
- `build/compile-*-and-cover.sh` 或 `.bat` 可同时生成正文 PDF 与独立完整展开图 PDF。
- Book 默认主题为 `ink`；ExBook 页眉、页脚默认宋体。

---

# Everflow·彼时流年若水 v13 快速开始

1. 在线平台编译器选择 **XeLaTeX**。
2. Book 编译 `ZeroOne-Book.tex`；Exam 编译 `ZeroOne-Exam.tex`；Public 编译 `ZeroOne-Public.tex`。
3. 题源入口在 `00-user-config/08-question-source.tex`。
4. ExBook 页眉、页脚和横线在 `00-user-config/03-header-footer.tex`。
5. Public 每一页直接编辑 `public-pages/编号-页面/page.tex`；本页图片放入同目录 `assets/`。
6. Public 全局奇偶页开关在 `public-pages/00-assembly/config.tex`，默认 `false`。
7. Exam 封面、pre、print 直接编辑 `exam-pages/`；A3 合版开关见 `config/exam-mixed-config.tex`。
8. 目录边距、字距、行距、缩进和点线在 `00-user-config/07-table-of-contents.tex`；全部新增开关默认 `false`。
9. 水印在 `00-user-config/05-watermark-config.tex`。

详细操作见 `docs/` 和 `manual/`。
