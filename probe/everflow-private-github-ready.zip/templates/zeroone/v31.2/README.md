# Everflow·彼时流年若水 v22 三合一工程

这是 Book / Exam / Public 共用题源的单一 LaTeX 工程。在线平台请选择 **XeLaTeX**。

## 三个正式入口

- `ZeroOne-Book.tex`：ExBook 做题本；默认主题 `ink`，默认页眉页脚为宋体；
- `ZeroOne-Exam.tex`：考试卷；
- `ZeroOne-Public.tex`：出版模式，含独立 Public 页眉页脚与书口导航。

## 本版最重要的开关

### 一键把三版切换到统一封面

在 `00-user-config/06-cover-config.tex`：

```tex
\def\ZeroOneUnifiedCoverForAllModesControl{true}
```

- `true`：Book、Exam、Public 原封面和原封底停止输出，三版强制改用统一 TeX 正封/封底；
- `false`：三版分别使用 `unified / custom / none` 来源，可换成自己的 TeX 封面或完全隐藏。

### 独立生成封面

编译 `ZeroOne-Book-Cover.tex`、`ZeroOne-Exam-Cover.tex` 或 `ZeroOne-Public-Cover.tex`。`CoverOutputMode` 支持：

```text
front / back / spine / front-back / panels / spread
```

其中 `spread` 是一张 `438mm × 297mm` 的 A4 展开图；`panels` 是正封、书脊、封底三页预览。

## 高频修改地图

- 正常封面来源、总开关、自定义文件路径：`00-user-config/06-cover-config.tex`；
- 封面文字、主题、坐标、镜像半字、二维码和独立输出：`00-user-config/11-cover-spread.tex`；
- Book / Public 页眉页脚、字体、字号和横线：`00-user-config/03-header-footer.tex`；
- Public 左右书口中心轨道：`00-user-config/12-public-edge-tabs.tex`；
- 页面边距：`00-user-config/02-page-layout.tex`；
- 题源：`00-user-config/08-question-source.tex`；
- 目录：`00-user-config/07-table-of-contents.tex`；
- 水印：`00-user-config/05-watermark-config.tex`；
- Public 单页开关：直接编辑 `public-pages/编号-页面/page.tex`。

## 封面设计规则

- 正封：左上“零”、右下“壹”；
- 封底：左上“壹”、右下“零”；
- 单独输出正封或封底时，超出物理页的字由页面边缘自然形成半字；
- 完整展开图中，背景字默认允许越过封面边界进入书脊，书脊文字最后绘制，保持清晰；
- Book、Exam、Public 使用同一视觉系统，但标题文案按模式和 Book 版式自动变化。

## 注释规则

工程内 `.tex / .sty / .cls / .sh / .bat` 文件均包含文件用途说明和至少三个“如何修改 / 修改后结果”的示例。长说明位于代码上方或独立下方，不放在代码行末。

更多说明见：`START-HERE.md`、`UNIFIED-COVER-EDGE-v22.md`、`FULL-FUNCTION-AUDIT-v22.md`、`docs/` 和 `manual/`。

## v23 新封面字号与细竖条

- “Everflow”前细竖条：在 `00-user-config/11-cover-spread.tex` 搜索 `ShowFrontBrandBar`。
- 新封面辅助小字统一字号：搜索 `ZeroOneCoverSpreadSmallTextSize`，默认 `12`。
- 关闭细竖条：把 `\ShowFrontBrandBartrue` 改为 `\ShowFrontBrandBarfalse`。


## v31.2 图表逐图局部切换

四年份题源中的图表不再使用“全局统一隐藏候选稿”的方式。每个对象都在题源中按顺序放置：

```text
A. 原图代码（默认显示）
B. 对应原生候选代码（默认由局部 comment 隐藏）
```

- 隐藏某一张原图：只给该对象的 `\qimage` 行加 `%`；
- 显示某一个候选：只注释该对象候选块的 `\begin{comment}` 和 `\end{comment}`；
- 未通过视觉校验的候选稿继续隐藏，可靠原图继续显示；
- 普通表格不要求使用 TikZ，应按对象采用 `tabularx`、`longtable`、`bytefield`、`forest` 或 TikZ。

详细操作见：`manual/11-原图与原生图逐图注释切换.md`。
