# Everflow·彼时流年若水 v21 统一封面功能验证

## 结构结果

- 旧 `covers/exbook/` 已删除。
- 旧 `public-pages/01-front-cover/` 已删除。
- 旧 `public-pages/13-back-cover/` 已删除。
- Exam 旧封面内容已替换为共享正封面组件调用。
- 正常正封面、正常封底和完整展开图统一读取 `00-user-config/11-cover-spread.tex`。
- 三种模式正常正封面与封底开关集中在 `00-user-config/06-cover-config.tex`。

## 默认状态

- Book 正常正封面：开启。
- Book 正常封底：开启。
- Exam 正常正封面：开启。
- Exam 正常封底：开启。
- Public 正常正封面：开启。
- Public 正常封底：开启。
- 正文 PDF 内附加完整展开页：默认关闭。
- 独立完整展开图入口：始终可编译。
- Book 默认主题：`ink`。
- ExBook 页眉和页脚默认字体：宋体，旧接口不再强制加粗。

## 正式入口编译

| 入口 | 结果 | 页数 |
|---|---|---:|
| `ZeroOne-Book.tex` | 通过 | 123 |
| `ZeroOne-Exam.tex` | 通过 | 37 |
| `ZeroOne-Public.tex` | 通过 | 135 |

正式入口均未发现致命错误、未定义控制序列或 Overfull 警告。

## 独立完整展开图

以下三个入口均通过编译，每个输出 1 页真实尺寸完整展开图：

- `ZeroOne-Book-Cover-Spread.tex`
- `ZeroOne-Exam-Cover-Spread.tex`
- `ZeroOne-Public-Cover-Spread.tex`

默认完整展开尺寸为 450mm × 300mm。

## 组合测试

- 正常正封面与正常封底同时开启：通过。
- 正文 PDF 内附加完整展开页：通过；附加页尺寸为 450mm × 300mm。
- 正常封面/封底与附加完整展开页同时存在：通过。
- 一键同时生成正文 PDF 与独立展开图 PDF：通过。
- 旧 `UseCover=false` 实例兼容：通过，同时关闭正常正封面和正常封底。
- Book 正文第二页恢复 A4，正封面/封底保持 216mm × 300mm：通过。
- 封面和封底无顶部/底部附加空段：通过。
