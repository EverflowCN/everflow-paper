# v26 修改说明

本版基于 v25，新增两部分功能。

## 1. 通用自定义插页系统

新增：

```tex
\ZeroOneInsertPage[mode=exam,paper=a4]{custom-pages/example-page.tex}
```

用于在题源或正文的当前位置插入独立页面。

新增：

```tex
\ZeroOneAddPageAt[mode=exam,paper=a4]{before-pre}{custom-pages/example-page.tex}
```

用于在固定结构位置挂载页面。支持：

`after-cover`、`before-pre`、`after-pre`、`before-print`、`after-print`、`before-toc`、`after-toc`、`before-body`、`after-body`、`before-backcover`。

相关文件：

- `90-core/zeroone-insert-page-core.sty`；
- `00-user-config/13-custom-pages.tex`；
- `custom-pages/example-page.tex`。

若 Exam 开启封面 A3 合版，同时又在封面与 pre/print 之间注册插页，工程会自动放弃合版并恢复独立物理页顺序，避免页面位置冲突。

## 2. 2024—2027 模拟卷题源

新增 `questions-by-year/`，包含四个年份 TeX 及配套图片。详见 `CALIBRATION-REPORT-v26.md`。
