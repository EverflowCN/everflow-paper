# Everflow·彼时流年若水 v22 统一封面、独立输出与 Public 书口说明

## 1. 三版一键替换

在 `00-user-config/06-cover-config.tex`：

```tex
\def\ZeroOneUnifiedCoverForAllModesControl{true}
```

开启后，Book、Exam、Public 的原正封和原封底不会再输出，三版都调用统一的原生 TeX 正封/封底组件。关闭后，每个模式的正封、封底、书脊可分别选择：

```text
unified / custom / none
```

## 2. 统一视觉，文案按模式变化

- Book：根据 `standard / compact / loose / single / padl / padp` 自动得到不同的“习题集 · …做题本”；
- Exam：默认“模拟试卷 · 检测卷”；
- Public：默认“408习题集 · 正式出版版”。

自动映射关闭后，可手动覆盖主标题和副标题。

## 3. A4 镜像半字

正封左上“零”、右下“壹”；封底镜像。单页输出依靠物理页边缘自然形成半字。完整展开图中，背景字默认允许进入书脊，绘制层次为：

```text
三段背景 -> 封面普通内容 -> 跨书脊背景字 -> 书脊前景文字与折线
```

因此大字可以越过边界，但不会盖住书脊标题。

## 4. 独立封面六种输出

在 `ZeroOne-Book-Cover.tex`、`ZeroOne-Exam-Cover.tex`、`ZeroOne-Public-Cover.tex` 设置：

```text
front       只输出正封
back        只输出封底
spine       只输出真实尺寸书脊
front-back  一个两页 PDF：正封、封底
panels      一个三页 PDF：正封、书脊、封底
spread      一张完整展开图：封底 + 书脊 + 正封
```

批量脚本可同时生成多个独立 PDF，也可同时生成正文和封面文件。

## 5. Public 书口居中

`00-user-config/12-public-edge-tabs.tex` 使用统一中心轨道：罗马数字、品牌、页码色块和科目名称共用同一中心轴；竖线只按固定间距偏移；奇偶页自动镜像。

## 6. Public 页眉页脚

全部集中在 `00-user-config/03-header-footer.tex`：

- 页眉字体、字号、行高和升降；
- 页眉横线显示、粗细、升降、主题跟随或固定色；
- 页脚大页码和 PAGE 标签字体、字号、位置；
- 灰色长线和主题色短线分别开启/关闭；
- 主题色短线跟随 Public 主题或使用固定自定义色。

目录页眉文字与横线仍由 `00-user-config/07-table-of-contents.tex` 独立控制，默认均关闭。
