# Everflow·彼时流年若水 v28 修改记录

## 1. Exam 封面后新增默认自定义页

Exam 前置页顺序现为：

```text
正封面 → 自定义页 → 原有 pre → print（开启时）→ 目录 → 正文
```

默认开关位于：

```tex
00-user-config/13-custom-pages.tex
```

页面内容位于：

```tex
custom-pages/before-pre-page.tex
```

默认值：

```tex
\providecommand{\ZeroOneUseExamBeforePreCustomPage}{true}
```

需要隐藏时改为 `false`。该功能使用通用插页挂载点 `before-pre`，不再为每张页面修改核心装配链。存在前置插页时，Exam 会自动避开与 A3 封面合版冲突，保证物理顺序正确。

## 2. 选择题作答空位统一为 `\blankbox`

四年份、九套试卷共 360 道单项选择题已经逐题检查：

- 每题至少包含一个 `\blankbox`；
- 共 369 个作答空位；
- 源码中每个宏前后严格保留两个 ASCII 空格；
- 标准写法为：

```tex
题干文字  \blankbox  \par
```

多空题保留原卷中的多个作答空位，不合并。

## 3. 题干分项换行

以下内容已统一改为独立段落并取消首行缩进：

```tex
\par\noindent Ⅰ. 第一项……
\par\noindent Ⅱ. 第二项……
\par\noindent Ⅲ. 第三项……
```

同样处理：

- `I. / II. / III. / IV.`；
- `① / ② / ③ / ④`；
- `(1) / （1） / 1） / 1．` 等综合题分项。

只调整断行和 LaTeX 表达，不改变题目原有措辞和顺序。

## 4. 代码统一使用 `listings`

试卷中的 C、C++、汇编及伪代码均使用：

```tex
\begin{lstlisting}[language=C]
...
\end{lstlisting}
```

共 39 个 `lstlisting` 代码块。已清理将中文题干误包进代码环境的问题，题干与代码分离。

## 5. 图表原生化

新增公共图形库：

```tex
questions-by-year/tikz/zeroone-mock-diagrams.tex
```

已将适合可靠重绘的内容改为 TikZ 或原生 LaTeX 表格，包括：

- 普通二叉树、最小深度树、路径权值树；
- 链表循环右移示意图；
- 四顶点/六顶点带权图、AOE 网；
- 目录树和 inode 表；
- 多播局域网示意图；
- 简单进程伪代码与时间线表格。

四年份题源共调用 26 次原生 TikZ/表格宏。复杂 B 树、红黑树多选图、CPU 数据通路、复杂网络拓扑、Cache/TLB/页表和大型指令表仍保留经裁切的原图，避免不确定重绘改变题意。

## 6. 兼容性修复

- 图边权标签使用独立 TikZ 样式，不再继承顶点圆形样式；
- Unicode `⊕` 改为数学模式 `\oplus`；
- Unicode `≦` 改为数学模式 `\leq`；
- 修复一处原 PDF 上标公式为 `$M=10^{6}$`；
- 检查并修复图片路径，所有图片调用均可解析。
