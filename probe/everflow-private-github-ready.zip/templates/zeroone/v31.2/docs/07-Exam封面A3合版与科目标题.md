# Everflow·彼时流年若水 v12：Exam 前置页 A3 合版与科目标题

## 封面与 pre / print 合为 A3

在 `ZeroOne-Exam.tex` 顶部预设：

```latex
\def\ZeroOneExamCoverAThreeMerge{true}
\def\ZeroOneExamCoverAThreePartner{pre}      % pre / print
\def\ZeroOneExamCoverAThreeOrder{cover-left} % cover-left / cover-right
```

关闭时将 `Merge` 改为 `false`。封面、pre 和 print 的内容分别直接编辑：

```text
exam-pages/01-cover/page.tex
exam-pages/02-pre/page.tex
exam-pages/03-print/page.tex
```

如果被选中的 partner 已隐藏，系统会给出警告，封面自动回退为独立页，其他仍显示的页面继续输出，不会生成半张空白 A3。

## 科目标题与第一个 section

默认：

```latex
\def\ZeroOneExamQuestionGroupMode{inline}
\def\ZeroOneExamMergeQuestionGroupWithFirstSection{true}
```

`\questiongroup` 已经开始新科目时，紧随其后的第一个 `\section` 不再重复执行物理换页；后续 section 仍按 `SectionForceNewPage` 执行。Exam 中的 `\publicationunittitle` 只为三合一题源兼容而保留，不参与 Exam 分页。
