# Everflow·彼时流年若水 v12：ExBook 页眉、页脚与横线

高频参数在 `00-user-config/03-header-footer.tex`。以下参数彼此独立：

- `\ZeroOneBookHeaderFontSize`：页眉字号；
- `\ZeroOneBookHeaderLineHeight`：页眉行高；
- `\ZeroOneBookHeaderTextRaise`：只移动页眉文字，正值向上；
- `\ZeroOneBookHeaderRuleRaise`：只移动页眉横线，正值向上；
- `\ZeroOneBookHeaderRuleWidth`：横线粗细，`0pt` 表示隐藏；
- `\ZeroOneBookHeaderRuleLeftIndent` / `RightIndent`：缩短横线两端；
- `\ZeroOneBookFooterTextRaise`：移动页脚文字。

示例：

```latex
% 页眉文字变小，横线变粗并向上移动
\def\ZeroOneBookHeaderFontSize{8pt}
\def\ZeroOneBookHeaderLineHeight{10pt}
\def\ZeroOneBookHeaderRuleWidth{0.8pt}
\def\ZeroOneBookHeaderRuleRaise{0.7mm}

% 只隐藏横线，不隐藏文字
\def\ZeroOneBookHeaderRuleWidth{0pt}

% 页脚向下移动 1mm
\def\ZeroOneBookFooterTextRaise{-1mm}
```

所有长度必须带单位。页眉文字、横线和正文整体位置不要混为一谈：正文与页眉的距离使用 `BookHeadSep`，横线本身的位置使用 `HeaderRuleRaise`。
