# section 强制换物理页与 Public 奇偶页

## 三版独立默认值

```latex
\def\ZeroOneBookSectionForceNewPage{true}    % Book：每个 section 换物理页
\def\ZeroOneExamSectionForceNewPage{false}  % Exam：保持现有连续试卷排版
\def\ZeroOnePublicSectionForceNewPage{true} % Public：每个 section 换物理页
\def\ZeroOneSectionKeepWithNext{true}       % 连续排版时防止标题孤立
```

Book 和 Public 的 `section` 默认整体居中，并从下一张物理页开始；Exam 默认不强制换页，仍使用现有左对齐试卷标题。Exam A3 双栏中若手动开启强制换页，会进入下一张 A3 物理页，不是只换到下一栏。

旧全局参数继续兼容：

```latex
\def\ZeroOneSectionForceNewPage{mode}  % 默认：服从三版独立值
\def\ZeroOneSectionForceNewPage{true}  % 强制三版全部换物理页
\def\ZeroOneSectionForceNewPage{false} % 强制三版全部连续排版
```

`ForceNewPage=true` 优先；设为 `false` 时再由 `KeepWithNext` 决定是否避免标题孤立在页尾。`questiongroup / part / chapter / subsection / subsubsection / Public 单元横条 / Exam 大题说明` 也分别拥有同名开关，彼此不连带。

## Public 奇偶页

```latex
\def\ZeroOnePublicParityControl{false} % 默认关闭
```

- `false`：组件和正文连续排版，不为奇偶页自动插空白页；
- `true`：按各组件文件夹中的 `side=right/left/any` 定位；
- 正文中的部分分隔页和其后内容的偏好位于 `public-pages/08-main-content/page.tex`。
