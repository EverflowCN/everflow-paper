# Everflow·彼时流年若水 v12：Public 独立页面与直接编辑

Public 的 13 个部分分别位于 `public-pages/01-...` 到 `13-...`。每个目录只需要：

```text
page.tex    # 本页的开关、奇偶页、字体、图片、页眉页脚、侧栏和正文
assets/     # 本页专用图片，可自行增加或删除
```

不再存在每页单独的 `config.tex`。要隐藏参考文献，直接打开 `public-pages/10-references/page.tex`，把：

```latex
\providecommand{\ZeroOnePublicUseReferences}{false}
```

改成 `true` 或 `false`。同一个文件顶部还可以设置：

```latex
\providecommand{\ZeroOnePublicReferencesSide}{right}
\providecommand{\ZeroOnePublicReferencesShowHeader}{true}
\providecommand{\ZeroOnePublicReferencesShowFooter}{true}
\providecommand{\ZeroOnePublicReferencesShowLeftSidebar}{true}
\providecommand{\ZeroOnePublicReferencesShowRightSidebar}{true}
```

字体可以直接在正文附近用 `\fontsize{字号}{行高}\selectfont` 修改。图片放入本页 `assets/` 后，使用 `\includegraphics`；需要绝对定位时使用 `tikzpicture[remember picture,overlay]`。每个 `page.tex` 顶部均给出可复制的具体例子。

整本 Public 的页眉、页脚、左侧栏和右侧栏总开关位于 `00-user-config/03-header-footer.tex`。全局奇偶页总开关仍位于 `public-pages/00-assembly/config.tex`，默认 `false`。
