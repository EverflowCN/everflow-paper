# Everflow·彼时流年若水 v21：统一封面与同时生成

旧 Book 封面、旧 Exam 封面和旧 Public 封底渲染代码已经删除。

现在以下输出只读取一套配置：

1. 正文 PDF 开头的正常正封面；
2. 正文 PDF 末尾的正常封底；
3. 独立完整展开图中的封底、书脊和正封面。

封面内容、颜色、字体、字号与坐标：

```text
00-user-config/11-cover-spread.tex
```

正常正封面与封底开关：

```text
00-user-config/06-cover-config.tex
```

独立完整展开图入口：

```text
ZeroOne-Book-Cover-Spread.tex
ZeroOne-Exam-Cover-Spread.tex
ZeroOne-Public-Cover-Spread.tex
```

同时生成正文与完整展开图：

```text
build/compile-book-and-cover.sh 或 .bat
build/compile-exam-and-cover.sh 或 .bat
build/compile-public-and-cover.sh 或 .bat
```

发布 ZIP 不包含编译生成的 PDF。
