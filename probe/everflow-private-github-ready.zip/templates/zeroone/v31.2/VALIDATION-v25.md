# v25 回归验证记录

## 编译结果

- `ZeroOne-Book.tex`：XeLaTeX 编译通过，131 页。
- `ZeroOne-Exam.tex`：XeLaTeX 连续两遍编译通过，37 张 A3 物理页、64 个正文逻辑页。
- `ZeroOne-Public.tex`：XeLaTeX 编译通过，140 页。

## 功能核对

- Book：`section` 从新物理页开始，编号与标题整体居中。
- Exam：`section` 保持原有连续排版和左对齐；未被 Book/Public 默认值连带修改。
- Public：`section` 从新物理页开始，中文编号与标题整体居中。
- Public 默认装配顺序为：封面、前言、目录、正文、封底；扉页与版权页未输出。
- Exam A3 页脚按左右逻辑页读取当前 `questiongroup`；“数据结构”和“计算机组成原理”均可自动切换，`section` 不会覆盖科目名。
- Exam Part 装饰图默认关闭；题干和普通 `\includegraphics` 图片正常保留。
- Public 使用 `\ZeroOnePublicHeaderYOffset=4mm` 的覆盖编译通过，页眉文字、色块和横线同步上移。

## 交付清理

交付 ZIP 不包含 PDF、AUX、LOG、OUT、TOC、SYNCTEX 等编译产物。
