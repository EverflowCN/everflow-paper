# Public 独立页面

每个编号文件夹只保留 `page.tex` 与可选的 `assets/`。显示开关、奇偶页、字体、图片、页眉、页脚和左右侧栏都在该页 `page.tex` 顶部直接修改，不再另设 `config.tex`。

全局奇偶页总开关在 `00-assembly/config.tex`，默认 `false`。整本 Public 的页眉页脚和左右侧栏总开关在 `00-user-config/03-header-footer.tex`。

## 直接编辑示例

隐藏某页：在该页 `page.tex` 顶部把对应 `Use...` 改为 `false`。
隐藏该页页眉或侧栏：把 `ShowHeader`、`ShowLeftSidebar` 等改为 `false`。
换图片：把文件放入同目录 `assets/`，然后在正文位置使用 `\includegraphics`。
改字体：在标题或正文代码上方直接设置 `\fontsize{字号}{行高}\selectfont`。

这些设置只影响当前页面，不需要去另一个统一配置文件寻找。
