# 11-afterword 专用图片目录

把只属于 `11-afterword/page.tex` 的 PNG、JPG 或 PDF 图片放在这里。
在 `page.tex` 中使用相对于工程根目录的路径，例如：

```latex
\includegraphics[width=40mm]{public-pages/11-afterword/assets/example.png}
```

建议图片在上传前压缩；不要放未使用的原图或编译输出。
