# v31 图表分类重构记录

## 当前阶段：基线回退与全量清点

1. v30 判定为失败分支，不继承其“全图表通过”结论。
2. v31 以 v29 稳定工作区为底稿，保留题目文本、bbox、blankbox、listings、Exam 自定义页和原始图像参考。
3. 所有图表对象重新进入未验收状态，不因其已是 TikZ/LaTeX 就自动通过。
4. 当前题源中共有 69 处位图调用，均已写入 `GRAPHIC-INVENTORY-v31.md`。
5. 后续实现按对象类型选择：
   - 普通表格：tabularx / array / multirow / makecell；
   - 跨页长表：longtable；
   - 协议首部和位字段：bytefield；
   - 普通树、B 树、红黑树：forest；
   - 线索树：forest + TikZ 线索箭头；
   - AOE、带权图、网络拓扑、链表：TikZ 相对定位；
   - 未完成视觉验收的复杂图保留原图，不强制用错误矢量图替换。
6. 所有题内宽度以局部 `\linewidth` 为基准，禁止使用固定整页坐标或把 `\textwidth` 当作 A3 逻辑栏宽。
