# Exam 封面修正 v24

## 修正范围

1. 普通 Exam 正封使用完整 A4 物理页，不再缩进 190mm 正文版心。
2. A3 合版时，封面完整铺满一侧 210mm x 297mm；pre/print 保留 10mm 安全边距。
3. Exam 封底改用试卷专属系列名、宣传语、功能说明和 `408 EXAM`。
4. 二维码生成隔离 `baselineskip`、`lineskip` 和段距，保持正方形。

## 修改示例

- 修改 `ZeroOneExamCoverMappedBackEnglish` 为 `408 MOCK EXAM`：Exam 封底与展开图同步变化。
- 设置 `ZeroOneExamCoverAThreeOrder=cover-right`：封面铺满 A3 右半页，伙伴页位于左侧。
- 设置 `ZeroOneExamFrontCoverSource=custom` 且关闭三版总开关：完整 A4 和 A3 合版都调用自定义 Exam 正封。
