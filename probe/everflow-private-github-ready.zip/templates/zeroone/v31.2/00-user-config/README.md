# 用户配置区

这里放经常修改的参数，`90-core/` 不建议日常修改。

- `02-page-layout.tex`：Book、Exam、Public 的版心、眉头和眉脚；
- `03-header-footer.tex`：页眉页脚文字；
- `04-question-layout.tex`：题间距、同页保护、八组标题自动分页独立开关；
- `05-watermark-config.tex`：水印类型、密度、方向、透明度和层级；
- `06-cover-config.tex`：封面、目录、前置页开关；
- `07-table-of-contents.tex`：目录边距、字体、字距、行距、缩进、点线、页码和防孤立；
- `../public-pages/各组件文件夹/page.tex`：Public 各独立组件；
- `08-question-source.tex`：单个题源或多 `\input` 总入口。

`section` 默认按模式独立控制：Book、Public 换物理页，Exam 保持连续排版。

```latex
\def\ZeroOneBookSectionForceNewPage{true}
\def\ZeroOneExamSectionForceNewPage{false}
\def\ZeroOnePublicSectionForceNewPage{true}
\def\ZeroOneSectionKeepWithNext{true}
```

旧参数 `\ZeroOneSectionForceNewPage` 仍兼容；写成 `true` 或 `false` 会统一覆盖三版，默认 `mode` 表示服从上述三版独立值。

示例：Book 切换为紧凑版，应修改主入口顶部：

```latex
\providecommand{\ZeroOneBookLayout}{compact}
```
