# Everflow·彼时流年若水 v12 可运行实例地图

所有示例从**项目根目录**使用 XeLaTeX 编译，示例不会修改正式题源。在线平台可以临时把任一示例设为主文件。

## 完整入口实例

| 文件 | 覆盖内容 |
|---|---|
| `examples/01-Book-example.tex` | Book + 全部常用题型 |
| `examples/02-Exam-example.tex` | Exam A4 + 同一 ExBook 题目内核 |
| `examples/03-Public-example.tex` | Public standard |
| `examples/04-Exam-mixed-A4-example.tex` | A4/A3 mixed 与正文独立 A4 块 |
| `examples/05-Pagination-audit-example.tex` | 标题页尾识别、题目与选项同页、超长题降级 |
| `examples/06-Page-layout-example.tex` | Book/Exam/Public 页边距、眉头、眉脚 |
| `examples/07-Watermark-example.tex` | 典型双层实时水印 |
| `examples/08-Public-components-example.tex` | 13 个组件开关与独立后置模块 |

## 题目录入片段

| 文件 | 内容 |
|---|---|
| `snippets/01-最小四选一.tex` | 最小 `bbox + qitem + fourchoices` |
| `snippets/02-罗马陈述与五选一.tex` | I/II/III 与五选项 |
| `snippets/03-判断填空简答解析.tex` | 判断、填空、简答、solution |
| `snippets/04-代码公式表格图片.tex` | 代码、公式、表格、题内图片 |
| `snippets/05-多部分多章节.tex` | part/section/题组与目录结构 |

## 水印十种情况

| 文件 | 参数组合 |
|---|---|
| `watermark-cases/01-text-grid-diagonal-sandwich.tex` | 文字 + 平铺 + 斜向 + 双层 |
| `watermark-cases/02-text-single-horizontal-foreground.tex` | 文字 + 单个 + 水平 + 前景 |
| `watermark-cases/03-text-grid-vertical-background.tex` | 文字 + 平铺 + 竖向 + 背景 |
| `watermark-cases/04-text-grid-custom-sandwich.tex` | 文字 + 自定义角度 + 双层 |
| `watermark-cases/05-image-grid-diagonal-background.tex` | 图片 + 平铺 + 斜向 + 背景 |
| `watermark-cases/06-image-single-custom-foreground.tex` | 图片 + 单个 + 自定义角度 + 前景 |
| `watermark-cases/07-scope-all.tex` | Scope=all，封面/组件也显示 |
| `watermark-cases/08-disabled.tex` | 完全关闭，无 shipout 水印钩子 |
| `watermark-cases/09-strong-50-percent-stress.tex` | 50% 强前景压力测试，不作正式默认 |
| `watermark-cases/10-invalid-values-fallback.tex` | 非法枚举值和非正步长的告警与安全回退 |

## 编译示例

```bash
xelatex -interaction=nonstopmode -halt-on-error examples/05-Pagination-audit-example.tex
xelatex -interaction=nonstopmode -halt-on-error examples/07-Watermark-example.tex
xelatex -interaction=nonstopmode -halt-on-error examples/watermark-cases/01-text-grid-diagonal-sandwich.tex
```

普通题使用小写 `bbox`；单题自身超过一整页时使用 `breakablebbox`。更完整的语法见 `examples/sources/example-question-source.tex` 和 `manual/03-题目与插图全部情况.md`。

- `09-标题自动分页独立开关.tex`：八类标题分别开启/关闭的示例。

- `11-Public奇偶页开关.tex`：开启全局奇偶页控制，演示各组件 `right / left / any` 的实际页序。

- `12-ExBook页眉与横线示例.tex`：字号、文字升降、横线位置/粗细/缩进。
- `13-Exam封面与pre合成A3.tex`：封面在左、pre 在右。
- `14-Exam封面与print合成A3.tex`：print 在左、封面在右。
- `15-A3连续标题组栏尾审计.tex`：连续标题组在 A3 左栏、右栏和下一张物理页之间移动的专项审计。
