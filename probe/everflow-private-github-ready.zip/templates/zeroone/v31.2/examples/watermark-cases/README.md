# Everflow·彼时流年若水 v12 水印组合实例

所有文件均可从项目根目录使用 XeLaTeX 独立编译，不修改正式入口。参数必须写在 `\input{...-Public.tex}` 之前，利用配置层的 `\providecommand` 覆盖默认值。

| 文件 | 覆盖情况 |
|---|---|
| `01-text-grid-diagonal-sandwich.tex` | 文字、平铺、斜向、双层（推荐电子预览） |
| `02-text-single-horizontal-foreground.tex` | 文字、单个、水平、前景 |
| `03-text-grid-vertical-background.tex` | 文字、平铺、竖向、背景 |
| `04-text-grid-custom-sandwich.tex` | 文字、平铺、自定义 50°、双层 |
| `05-image-grid-diagonal-background.tex` | 图片、平铺、斜向、背景 |
| `06-image-single-custom-foreground.tex` | 图片、单个、自定义角度、前景 |
| `07-scope-all.tex` | Scope=all：封面和独立组件也显示，自动空白页仍纯白 |
| `08-disabled.tex` | 完全关闭水印，不安装逐页绘制钩子 |
| `09-strong-50-percent-stress.tex` | 50% 强前景压力测试（正式文档不建议） |
| `10-invalid-values-fallback.tex` | 错误枚举值和非正步长的 warning 与安全回退 |

推荐正式电子审阅使用 01；纸面打印可参考 03；09 只用于覆盖压力测试。合法参数和值见 `../../manual/04-水印全部情况大全.md`。
