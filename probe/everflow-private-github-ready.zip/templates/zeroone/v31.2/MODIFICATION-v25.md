# v25 本轮修改说明

## 默认状态

- Book：`section` 默认换新物理页，标题整体居中。
- Exam：`section` 保持原有连续排版与左对齐。
- Public：`section` 默认换新物理页，中文编号和标题作为整体居中。
- Public：扉页、版权页默认关闭；前言、目录、正文默认开启。
- Exam：页脚默认显示当前 `questiongroup` 科目名称。
- Exam：Part/科目标题装饰图片默认关闭。

## Exam Part 图片开关

```latex
\def\ZeroOneExamPartImageEnabled{false}
```

该开关只控制以下命令中的可选装饰图片：

```latex
\questiongroup{数据结构}[contents/02.fast.jpg][5cm]
```

关闭后“数据结构”标题仍显示；题干、选项、解析、普通图片、封面、Logo、二维码和水印均不受影响。

## Public 页眉整体升降

```latex
\def\ZeroOnePublicHeaderYOffset{2mm}  % 整体向上 2mm
\def\ZeroOnePublicHeaderYOffset{-2mm} % 整体向下 2mm
```

该参数同时移动页眉文字、色块和横线。`HeadSep` 只控制页眉与正文的距离，不负责页眉在纸张上的绝对位置。
