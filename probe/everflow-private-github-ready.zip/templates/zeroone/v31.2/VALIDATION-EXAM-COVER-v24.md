# Exam 封面回归验证 v24

## 已验证项目

- 默认 `ZeroOne-Exam.tex` 连续编译两遍：通过，37 页。
- 默认第一页：A4 210mm x 297mm 满版，不再缩进正文版心。
- 默认末页：Exam 专属封底，英文为 `408 EXAM`。
- 默认末页二维码：保持正方形，不再出现纵向拆行。
- A3 `cover-left + pre`：通过；封面铺满左半页，pre 保留安全边距。
- A3 `cover-right + pre`：通过；封面铺满右半页，pre 保留安全边距。
- Exam 独立完整展开图：通过，438mm x 297mm。
- Book 独立完整展开图烟雾测试：通过。
- Public 独立完整展开图烟雾测试：通过。

## 用户可修改示例

1. 修改 `ZeroOneExamCoverMappedBackEnglish` 为 `408 MOCK EXAM`：Exam 封底与展开图同步显示新英文。
2. 修改 `ZeroOneExamCoverAThreeOrder` 为 `cover-right`：封面移动到 A3 右半页。
3. 修改 `ZeroOneExamCoverAThreePartner` 为 `print`：A3 另一半改为打印说明页。
