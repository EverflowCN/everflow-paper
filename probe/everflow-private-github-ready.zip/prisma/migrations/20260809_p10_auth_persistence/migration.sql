-- P10 persistence/account layer. The runnable API also contains an idempotent PostgreSQL bootstrap
-- because the current execution environment cannot run PostgreSQL/Prisma migrations.
CREATE TABLE IF NOT EXISTS "User" ("id" text PRIMARY KEY,"email" text UNIQUE NOT NULL,"displayName" text NOT NULL,"passwordHash" text NOT NULL,"role" text NOT NULL DEFAULT 'user',"plan" text NOT NULL DEFAULT 'free',"disabled" boolean NOT NULL DEFAULT false,"createdAt" timestamptz NOT NULL DEFAULT now(),"updatedAt" timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS "Session" ("id" text PRIMARY KEY,"userId" text NOT NULL REFERENCES "User"("id") ON DELETE CASCADE,"tokenHash" text UNIQUE NOT NULL,"createdAt" timestamptz NOT NULL DEFAULT now(),"expiresAt" timestamptz NOT NULL);
CREATE INDEX IF NOT EXISTS "Session_userId_idx" ON "Session"("userId");
CREATE INDEX IF NOT EXISTS "Session_expiresAt_idx" ON "Session"("expiresAt");
CREATE TABLE IF NOT EXISTS "QuestionBank" ("id" text PRIMARY KEY,"ownerId" text NOT NULL REFERENCES "User"("id") ON DELETE CASCADE,"name" text NOT NULL,"description" text,"schemaVersion" integer NOT NULL DEFAULT 1,"createdAt" timestamptz NOT NULL DEFAULT now(),"updatedAt" timestamptz NOT NULL DEFAULT now());
CREATE INDEX IF NOT EXISTS "QuestionBank_ownerId_idx" ON "QuestionBank"("ownerId");
CREATE TABLE IF NOT EXISTS "CompileUsage" ("id" text PRIMARY KEY,"userId" text NOT NULL REFERENCES "User"("id") ON DELETE CASCADE,"day" date NOT NULL,"count" integer NOT NULL DEFAULT 0,"totalDurationMs" bigint NOT NULL DEFAULT 0,"updatedAt" timestamptz NOT NULL DEFAULT now(),UNIQUE("userId","day"));
CREATE TABLE IF NOT EXISTS "AuditLog" ("id" text PRIMARY KEY,"actorUserId" text,"action" text NOT NULL,"targetType" text,"targetId" text,"metadata" jsonb,"createdAt" timestamptz NOT NULL DEFAULT now());
