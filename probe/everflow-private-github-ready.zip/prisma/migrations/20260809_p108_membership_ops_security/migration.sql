ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "accountStatus" TEXT NOT NULL DEFAULT 'normal';
ALTER TABLE "Session" ADD COLUMN IF NOT EXISTS "surface" TEXT NOT NULL DEFAULT 'app';

CREATE TABLE IF NOT EXISTS "Subscription" (
  "id" TEXT PRIMARY KEY,
  "userId" TEXT NOT NULL,
  "plan" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "source" TEXT NOT NULL,
  "currentPeriodStart" TIMESTAMP(3),
  "currentPeriodEnd" TIMESTAMP(3),
  "cancelAtPeriodEnd" BOOLEAN NOT NULL DEFAULT false,
  "metadata" JSONB,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS "Subscription_userId_updatedAt_idx" ON "Subscription"("userId","updatedAt");

CREATE TABLE IF NOT EXISTS "FeatureFlag" (
  "key" TEXT PRIMARY KEY,
  "enabled" BOOLEAN NOT NULL DEFAULT false,
  "description" TEXT,
  "rolloutPercentage" INTEGER NOT NULL DEFAULT 100,
  "plans" JSONB NOT NULL DEFAULT '[]'::jsonb,
  "userIds" JSONB NOT NULL DEFAULT '[]'::jsonb,
  "config" JSONB,
  "updatedBy" TEXT,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "RiskCase" (
  "id" TEXT PRIMARY KEY,
  "userId" TEXT,
  "type" TEXT NOT NULL,
  "severity" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "source" TEXT NOT NULL,
  "evidence" JSONB,
  "decision" JSONB,
  "assignedTo" TEXT,
  "createdBy" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS "RiskCase_status_updatedAt_idx" ON "RiskCase"("status","updatedAt");
CREATE INDEX IF NOT EXISTS "RiskCase_userId_updatedAt_idx" ON "RiskCase"("userId","updatedAt");
