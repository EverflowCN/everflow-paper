ALTER TABLE zo_sessions ADD COLUMN IF NOT EXISTS last_seen_at timestamptz;
ALTER TABLE zo_sessions ADD COLUMN IF NOT EXISTS ip text;
ALTER TABLE zo_sessions ADD COLUMN IF NOT EXISTS user_agent text;
UPDATE zo_sessions SET last_seen_at = created_at WHERE last_seen_at IS NULL;
