CREATE TABLE IF NOT EXISTS "BillingOrder" (
  "id" TEXT PRIMARY KEY,
  "publicId" TEXT NOT NULL UNIQUE,
  "userId" TEXT NOT NULL,
  "provider" TEXT NOT NULL,
  "providerOrderId" TEXT,
  "plan" TEXT NOT NULL,
  "period" TEXT NOT NULL,
  "amountCents" INTEGER NOT NULL,
  "currency" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "checkoutUrl" TEXT,
  "metadata" JSONB,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "paidAt" TIMESTAMP(3)
);
CREATE INDEX IF NOT EXISTS "BillingOrder_userId_updatedAt_idx" ON "BillingOrder"("userId","updatedAt");
CREATE UNIQUE INDEX IF NOT EXISTS "BillingOrder_provider_providerOrderId_key" ON "BillingOrder"("provider","providerOrderId") WHERE "providerOrderId" IS NOT NULL;
