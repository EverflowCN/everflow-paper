-- Everflow v0.8.5 — redemption codes, lifecycle simulator and bonus credits.
CREATE TABLE IF NOT EXISTS "RedeemCampaign" (
  "id" TEXT PRIMARY KEY,
  "publicId" TEXT NOT NULL UNIQUE,
  "name" TEXT NOT NULL,
  "reward" JSONB NOT NULL,
  "status" TEXT NOT NULL,
  "validFrom" TIMESTAMPTZ,
  "expiresAt" TIMESTAMPTZ,
  "perUserLimit" INTEGER NOT NULL DEFAULT 1,
  "createdBy" TEXT NOT NULL,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS "RedeemCode" (
  "id" TEXT PRIMARY KEY,
  "publicId" TEXT NOT NULL UNIQUE,
  "campaignId" TEXT NOT NULL REFERENCES "RedeemCampaign"("id") ON DELETE CASCADE,
  "codeHash" TEXT NOT NULL UNIQUE,
  "codeLast4" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "maxUses" INTEGER NOT NULL DEFAULT 1,
  "usedCount" INTEGER NOT NULL DEFAULT 0,
  "validFrom" TIMESTAMPTZ,
  "expiresAt" TIMESTAMPTZ,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS "RedeemCode_campaignId_createdAt_idx" ON "RedeemCode"("campaignId","createdAt");
CREATE TABLE IF NOT EXISTS "Redemption" (
  "id" TEXT PRIMARY KEY,
  "publicId" TEXT NOT NULL UNIQUE,
  "userId" TEXT NOT NULL,
  "codeId" TEXT NOT NULL REFERENCES "RedeemCode"("id"),
  "campaignId" TEXT NOT NULL REFERENCES "RedeemCampaign"("id"),
  "status" TEXT NOT NULL,
  "reward" JSONB NOT NULL,
  "claimedAt" TIMESTAMPTZ NOT NULL,
  "rewardAppliedAt" TIMESTAMPTZ,
  "error" TEXT,
  "metadata" JSONB,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE("codeId","userId")
);
CREATE INDEX IF NOT EXISTS "Redemption_userId_updatedAt_idx" ON "Redemption"("userId","updatedAt");
CREATE TABLE IF NOT EXISTS "MembershipCredit" (
  "id" TEXT PRIMARY KEY,
  "userId" TEXT NOT NULL,
  "kind" TEXT NOT NULL,
  "granted" INTEGER NOT NULL,
  "remaining" INTEGER NOT NULL,
  "expiresAt" TIMESTAMPTZ,
  "source" TEXT NOT NULL,
  "sourceId" TEXT,
  "metadata" JSONB,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS "MembershipCredit_userId_kind_expiresAt_idx" ON "MembershipCredit"("userId","kind","expiresAt");
