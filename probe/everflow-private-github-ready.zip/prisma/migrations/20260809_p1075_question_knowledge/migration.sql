CREATE TABLE "QuestionTaxonomyMapping" (
  "id" TEXT PRIMARY KEY,
  "ownerId" TEXT NOT NULL,
  "questionId" TEXT NOT NULL,
  "taxonomyVersionId" TEXT NOT NULL,
  "taxonomyNodeId" TEXT,
  "path" JSONB NOT NULL,
  "source" TEXT NOT NULL,
  "confidence" DOUBLE PRECISION,
  "mappedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "QuestionTaxonomyMapping_questionId_taxonomyVersionId_key" UNIQUE ("questionId","taxonomyVersionId")
);
CREATE INDEX "QuestionTaxonomyMapping_ownerId_taxonomyVersionId_idx" ON "QuestionTaxonomyMapping"("ownerId","taxonomyVersionId");
CREATE INDEX "QuestionTaxonomyMapping_questionId_idx" ON "QuestionTaxonomyMapping"("questionId");

CREATE TABLE "QuestionRelationEdge" (
  "id" TEXT PRIMARY KEY,
  "ownerId" TEXT NOT NULL,
  "sourceQuestionId" TEXT NOT NULL,
  "targetQuestionId" TEXT NOT NULL,
  "type" TEXT NOT NULL,
  "metadata" JSONB,
  "createdBy" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "QuestionRelationEdge_sourceQuestionId_targetQuestionId_type_key" UNIQUE ("sourceQuestionId","targetQuestionId","type")
);
CREATE INDEX "QuestionRelationEdge_ownerId_type_idx" ON "QuestionRelationEdge"("ownerId","type");
CREATE INDEX "QuestionRelationEdge_targetQuestionId_idx" ON "QuestionRelationEdge"("targetQuestionId");

CREATE TABLE "QuestionUsageEvent" (
  "id" TEXT PRIMARY KEY,
  "ownerId" TEXT NOT NULL,
  "questionId" TEXT NOT NULL,
  "paperId" TEXT NOT NULL,
  "usedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "QuestionUsageEvent_questionId_paperId_key" UNIQUE ("questionId","paperId")
);
CREATE INDEX "QuestionUsageEvent_ownerId_usedAt_idx" ON "QuestionUsageEvent"("ownerId","usedAt");
CREATE INDEX "QuestionUsageEvent_questionId_usedAt_idx" ON "QuestionUsageEvent"("questionId","usedAt");
