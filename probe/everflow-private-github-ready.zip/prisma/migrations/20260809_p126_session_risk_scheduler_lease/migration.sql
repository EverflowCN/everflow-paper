-- Everflow v1.0 RC.6: session risk metadata + scheduler lease coordination
ALTER TABLE zo_sessions ADD COLUMN IF NOT EXISTS risk_score integer NOT NULL DEFAULT 0;
ALTER TABLE zo_sessions ADD COLUMN IF NOT EXISTS risk_reasons jsonb NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE zo_sessions ADD COLUMN IF NOT EXISTS new_device boolean NOT NULL DEFAULT false;

CREATE TABLE IF NOT EXISTS zo_scheduler_leases(
  key text PRIMARY KEY,
  holder text NOT NULL,
  expires_at timestamptz NOT NULL,
  updated_at timestamptz NOT NULL
);
CREATE INDEX IF NOT EXISTS zo_scheduler_leases_exp_idx ON zo_scheduler_leases(expires_at);
