# Everflow·彼时流年若水 v1.0 RC / Production Readiness 实施报告

## 本轮目标

在 v0.9.8 的 UI/Billing/Security 基线上补齐首轮公网部署前最容易造成生产事故的四类边界：账户恢复、邮箱验证、支付 Webhook 幂等和上线 Readiness Gate，并继续做 UI 回归。

## 1. 账户恢复与邮箱验证

新增：

- `POST /api/auth/email-verification/request`
- `POST /api/auth/email-verification/confirm`
- `POST /api/auth/password/reset/request`
- `POST /api/auth/password/reset/confirm`
- `/forgot-password`
- `/reset-password`
- `/verify-email`

Token 使用 HMAC-SHA256 签名并包含 purpose、userId、email、expiresAt、nonce 和当前 passwordHash 摘要。密码重置完成后 passwordHash 改变，因此旧 reset token 会自动变为 stale，避免重复使用。

生产环境要求 `EVERFLOW_ACCOUNT_TOKEN_SECRET` 至少 32 字符。当前 RC 尚未连接真实 SMTP/邮件服务商；开发环境为 E2E 返回 `devToken`，生产环境不会返回 token。

## 2. Billing Webhook 幂等状态机

新增公共 Provider Webhook：

`POST /api/billing/webhooks/:provider`

Test Provider 已实测：

1. BillingOrder 创建为 pending；
2. event `evt_rc_001` 通知 paid；
3. BillingOrder -> paid；
4. 创建/刷新 payment Subscription；
5. 相同 eventId 再通知一次返回 `idempotent: true`；
6. Pro 到期日没有被再次延长。

Webhook 处理事件 ID 写入 BillingOrder metadata，保留最近事件集合与 lastWebhookAt/lastWebhookStatus。

真实 WeChat / Alipay / Stripe 仍为 Provider 插槽；它们在上线前必须完成官方签名/证书验签与退款事件映射，当前 RC 不将其标记为完成。

## 3. Production Readiness Gate

新增：

- `GET /ready`
- `npm run production:check`
- `apps/api/src/ops/readiness.ts`
- `deploy/production/GO-LIVE-CHECKLIST.md`

生产必需检查：

- PostgreSQL / `DATABASE_URL`
- BullMQ + Redis
- S3-compatible Object Store
- Docker/Podman Compiler Sandbox
- `EVERFLOW_ACCOUNT_TOKEN_SECRET`
- `EVERFLOW_REDEEM_PEPPER`
- hidden Operations path + Gate Secret

可选但上线推荐：

- real Billing Provider
- Cloudflare Tunnel

实测默认配置：BLOCKED / exit code 2。
补齐所有 required 配置后：READY / exit code 0。

注意：目前 `/ready` 是**配置级 gate**，不是 Redis/MinIO 的主动网络探针。真实服务连通性必须在部署环境 Integration Test 中完成。

## 4. Operations UI

System Health 新增 `Production Readiness` 行：

- READY / BLOCKED
- blocking keys
- development / production mode

Billing 行增加 `Webhook idempotency enabled` 提示。

## 5. UI 回归

本轮增加/更新：

- 找回密码页面
- 邮箱验证状态
- 安全设置页
- Operations Readiness 状态
- Billing webhook 状态展示

继续保持已确认的 A 风格：低阴影、细边框、小圆角、浅灰工作区；没有重新引入大渐变、大卡片或玻璃拟态。

## 6. 实际回归

通过：

- `npm test`
- `npm run p11.8:e2e`
- `npm run p11.5:e2e`
- `npm run p10.8.5:e2e`
- `npm run rc:e2e`
- `npm run p9:e2e`：Book 3 pages / Exam 1 page / Public 5 pages / generic 1 page
- P6-P8 SyncTeX 关键输出：source -> PDF -> TeX line -> Question ID 正常；该脚本在当前工具调用超时上限后被外层终止，但关键双向定位步骤已完成输出。

RC 专项验证：

- 邮箱从 unverified -> verified
- reset token 使用后 stale
- 旧密码无法登录
- 新密码可登录
- payment webhook duplicate 不重复叠加 Pro
- `/ready` development 状态可读
- `production:check` 缺配置 BLOCKED / required 配置齐全 READY

## 7. 尚未冒充完成的生产项

需要真实服务器/第三方账户才能完成：

- Redis/BullMQ 真实运行与断线/重连/worker failover 测试
- MinIO/S3 真实 runtime 和 bucket lifecycle
- Cloudflare Tunnel/WAF/Rate Limit/Access
- WeChat/Alipay/Stripe 真实 webhook 签名验签
- SMTP/Resend/SES 等真实邮件 Provider
- WebAuthn / Passkey
- PostgreSQL backup/restore drill
- Prometheus/OpenTelemetry/Grafana

这些项目均保留在 Go-Live Checklist 中，未标成 production complete。
