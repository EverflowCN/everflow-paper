# GitHub hosting boundary

## What GitHub can do for this repository

- Keep the source in a **Private** repository.
- Run GitHub Actions for build, unit tests, security checks, and smoke tests.
- Provide Codespaces as a temporary development environment if enabled for the account.

## What GitHub Pages cannot do

Everflow is not a static site. The complete product requires a long-running Node API plus production services such as PostgreSQL, Redis/BullMQ, object storage, and a sandboxed XeLaTeX worker. GitHub Pages cannot host these server-side processes.

Do **not** publish the full product using GitHub Pages and assume it is production deployment.

## Recommended production topology

Private GitHub repository → GitHub Actions CI/CD → external Linux host / container platform → Cloudflare → Everflow API + workers + PostgreSQL + Redis + object storage + compiler sandbox.

GitHub remains the source-of-truth and CI/CD control plane; the runtime lives on an actual server/container platform.

## GitHub-native temporary runtime: Codespaces

The repository includes `.devcontainer/`. A private GitHub Codespace can run the application for development/testing and forward port `8787`. This is the closest supported way to “run Everflow on GitHub” itself. The Codespace stops when the development environment stops and is not a production service.
