@echo off
where node >nul 2>nul || (echo [missing] node & exit /b 1)
where tsc >nul 2>nul || (echo [missing] tsc & exit /b 1)
where latexmk >nul 2>nul || (echo [missing] latexmk & exit /b 1)
where xelatex >nul 2>nul || (echo [missing] xelatex & exit /b 1)
where synctex >nul 2>nul || (echo [missing] synctex & exit /b 1)
where pdfinfo >nul 2>nul || (echo [missing] pdfinfo ^(Poppler^) & exit /b 1)
where pdftoppm >nul 2>nul || (echo [missing] pdftoppm ^(Poppler^) & exit /b 1)
npm run ide
