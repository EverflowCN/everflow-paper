# Everflow·彼时流年若水 — Core Audit 02

Core Audit 02 focuses only on the product core: DOCX image anchor preservation, ordinary PNG/PDF image assets, versioned question editing, and editable paper hierarchy. It builds directly on Core Audit 01, which already verified paper-specific IDE workspaces, frozen QuestionRevision snapshots, raw lowercase `bbox` TeX import, last-good PDF persistence, answer-space rendering, three-mode XeLaTeX, SyncTeX and restart persistence.

## Core Audit 02 additions

- DOCX OpenXML image extraction retains image bytes plus inline/floating anchor metadata and maps them into Question asset blocks.
- Imported DOCX images become private Asset records rather than transient placeholders.
- PNG/PDF image assets are materialized into `everflow-assets/` and rendered with real `\includegraphics` during XeLaTeX.
- `PUT /api/questions/:id` remains the canonical revision-producing edit path and the question UI now uses it.
- Paper hierarchy can be edited via `questiongroup / part / chapter / section / subsection / custom`, including drag/reorder and moving questions between sections.
- Cyclic section hierarchies are rejected server-side.

See `CORE-AUDIT-02-REPORT.md` for the full audit, regression results and known limits.
