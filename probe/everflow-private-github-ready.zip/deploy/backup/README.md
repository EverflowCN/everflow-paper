# Everflow Backup / Restore

- Database backups use PostgreSQL custom format (`pg_dump -Fc`).
- Object storage backup is provider-specific and can be attached through `EVERFLOW_OBJECT_BACKUP_COMMAND`.
- A backup is not considered valid until a restore drill succeeds in an isolated database and the RC smoke tests pass.
- Never restore directly over production without a maintenance window and a verified rollback path.
