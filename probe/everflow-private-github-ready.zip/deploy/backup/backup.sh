#!/usr/bin/env bash
set -euo pipefail
: "${DATABASE_URL:?DATABASE_URL required}"
OUT="${1:-./backups/$(date -u +%Y%m%dT%H%M%SZ)}"
mkdir -p "$OUT"
pg_dump --format=custom --no-owner --no-acl "$DATABASE_URL" > "$OUT/postgres.dump"
printf '%s\n' "$(date -u +%FT%TZ)" > "$OUT/created-at.txt"
if [[ -n "${EVERFLOW_OBJECT_BACKUP_COMMAND:-}" ]]; then bash -lc "$EVERFLOW_OBJECT_BACKUP_COMMAND"; fi
sha256sum "$OUT/postgres.dump" > "$OUT/SHA256SUMS"
SIZE="$(wc -c < "$OUT/postgres.dump" | tr -d ' ')"
SHA="$(cut -d' ' -f1 "$OUT/SHA256SUMS")"
cat > "$OUT/manifest.json" <<EOF
{
  "format": "everflow-backup-manifest-v1",
  "createdAt": "$(cat "$OUT/created-at.txt")",
  "appVersion": "${EVERFLOW_APP_VERSION:-1.0.0-rc.5}",
  "database": "postgres",
  "objectBackupCommandConfigured": $([[ -n "${EVERFLOW_OBJECT_BACKUP_COMMAND:-}" ]] && echo true || echo false),
  "files": [{"name":"postgres.dump","sizeBytes":$SIZE,"sha256":"$SHA"}]
}
EOF
echo "Backup written to $OUT"
echo "Manifest: $OUT/manifest.json"
