#!/usr/bin/env bash
set -euo pipefail
: "${DATABASE_URL:?DATABASE_URL required}"
DUMP="${1:?Usage: restore.sh /path/postgres.dump}"
[[ -f "$DUMP" ]] || { echo "dump not found" >&2; exit 2; }
DIR="$(cd "$(dirname "$DUMP")" && pwd)"
if [[ -f "$DIR/SHA256SUMS" ]]; then (cd "$DIR" && sha256sum -c SHA256SUMS); fi
START="$(date +%s)"
pg_restore --clean --if-exists --no-owner --no-acl --dbname="$DATABASE_URL" "$DUMP"
SMOKE="not-run"
if [[ -n "${EVERFLOW_RESTORE_SMOKE_COMMAND:-}" ]]; then
  if bash -lc "$EVERFLOW_RESTORE_SMOKE_COMMAND"; then SMOKE="passed"; else SMOKE="failed"; fi
fi
END="$(date +%s)"
cat > "$DIR/restore-verification.json" <<EOF
{
  "format": "everflow-restore-verification-v1",
  "verifiedAt": "$(date -u +%FT%TZ)",
  "manifestVerified": $([[ -f "$DIR/SHA256SUMS" ]] && echo true || echo false),
  "databaseRestored": true,
  "smokeTests": "$SMOKE",
  "rtoSeconds": $((END-START))
}
EOF
echo "Database restore completed."
echo "Verification report: $DIR/restore-verification.json"
