# Cloudflare production rule blueprint

Apply these as a deployment checklist; exact rule syntax depends on the Cloudflare plan/account at deployment time.

1. Proxy only public application hostnames; keep database, Redis, MinIO and worker networks private.
2. `/api/auth/login`, `/api/auth/password/reset/request`, `/api/membership/redeem`: stricter rate limits and managed challenge after repeated failures.
3. `/api/compile`, `/api/imports/*`, `/api/ai/*`: authenticated traffic only; edge rate limit complements server-side quota.
4. Operations hostname: Cloudflare Access allow policy before Everflow Operations authentication + TOTP/RBAC.
5. Block direct origin access; prefer Tunnel. If origin is public, restrict it to Cloudflare and use authenticated origin controls.
6. Preserve SSE by disabling buffering/caching on `/api/jobs/events`.
7. Cache immutable public assets only; never cache authenticated API responses.
8. Log WAF/rate-limit actions and alert on sudden changes in block rate or origin 5xx.
