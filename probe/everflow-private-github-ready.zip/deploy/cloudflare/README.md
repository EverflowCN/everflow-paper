# Cloudflare edge baseline for Everflow

目标：公网请求只通过 Cloudflare 到达 Everflow API，源站不直接公开。

建议的生产顺序：

1. Cloudflare Tunnel 只指向 `api:8787`。
2. DNS 不发布源站真实 IP；源站防火墙拒绝非必要入站。
3. WAF Managed Rules 开启后，再加 Everflow 自定义规则。
4. `/api/auth/login`、`/api/auth/register`、`/api/membership/redeem`、`/api/demo/compile`、`/api/imports/*`、`/api/ai/*` 分别配置独立 Rate Limit。
5. 注册、连续登录失败、Demo 高频编译等路径启用 Turnstile；正常已登录用户不要每次编译都做人机验证。
6. Operations 隐藏路径再置于 Cloudflare Access/Zero Trust 后，形成 Edge Staff Access → Everflow Ops Login → TOTP MFA → RBAC。
7. SSE `/api/jobs/events` 需允许长连接，禁用代理缓冲；应用已发送 `X-Accel-Buffering: no`。

应用层限流仍然保留，Cloudflare 是第一层而不是唯一一层。
