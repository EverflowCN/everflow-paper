# Everflow·彼时流年若水 v1.0 RC — Go-Live Checklist

## Required before public traffic

- PostgreSQL is the active repository (`DATABASE_URL`).
- Redis/BullMQ is active (`EVERFLOW_JOB_DRIVER=bullmq`).
- S3-compatible object storage is active (MinIO/S3), with bucket lifecycle/backups.
- Compile Worker uses Docker/Podman sandbox; no host compiler in production.
- `EVERFLOW_ACCOUNT_TOKEN_SECRET`, `EVERFLOW_REDEEM_PEPPER`, AI and Ops MFA master keys are stored in a secret manager.
- Operations route is behind Cloudflare Access/Zero Trust and TOTP MFA.
- Cloudflare WAF, rate limiting and origin protection/Tunnel are enabled.
- Billing provider is switched away from `test`; webhook signature verification must be implemented and verified for that provider.
- Real email provider is connected before relying on email verification/password recovery for users.
- PostgreSQL backup and restore drill is completed.
- Redis is not treated as the only source of durable Job state.
- `/health` and `/ready` are monitored separately. `/ready` must return 200 before traffic cutover.

## RC caveats

The repository contains production topology and adapters for BullMQ/S3-compatible storage, but this development container cannot prove a real external Redis/MinIO/Cloudflare/payment-provider runtime. Those require deployment-environment integration tests.
