# Rootless compiler sandbox

生产环境不要把 rootful `/var/run/docker.sock` 裸挂给 Compile Worker。

v0.9.5 的 compiler worker 支持：

- `EVERFLOW_CONTAINER_RUNTIME=docker`：调用 Docker CLI，可通过 `DOCKER_HOST` 指向 rootless Docker daemon。
- `EVERFLOW_CONTAINER_RUNTIME=podman`：调用 Podman CLI，可使用 rootless Podman。

无论 runtime 是 Docker 还是 Podman，编译容器仍强制：

- `--network none`
- `--cap-drop ALL`
- `no-new-privileges`
- memory / CPU / PID limit
- read-only root filesystem
- isolated `/tmp`
- `latexmk -no-shell-escape`

`docker-compose.production.yml` 只挂 rootless socket 给 Compile Worker；API、Import Worker、AI Worker、Export Worker 均不接触容器运行时 socket。
