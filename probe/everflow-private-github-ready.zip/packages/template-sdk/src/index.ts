import { DocumentAST } from "../../document-ast/src";

export type CompilerType = "xelatex" | "pdflatex" | "lualatex";
export interface GeneratedProjectFile {
  path: string;
  kind: "tex" | "asset" | "style" | "font" | "other";
  generated: boolean;
  editable: boolean;
  text?: string;
  sourcePath?: string;
  sha256: string;
}
export interface SourceMapEntry {
  filePath: string;
  startLine: number;
  endLine: number;
  entityType: "question" | "section" | "paper";
  entityId: string;
  entityRevisionId?: string;
}
export interface GeneratedProject {
  rootFile: string;
  files: GeneratedProjectFile[];
  sourceMaps: SourceMapEntry[];
  compiler: CompilerType;
  templateRoot?: string;
}
export interface TemplateAdapter {
  buildProject(document: DocumentAST): GeneratedProject;
  materialize(project: GeneratedProject, destination: string): void;
}
