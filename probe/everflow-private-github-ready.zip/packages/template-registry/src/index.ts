const fs = require("fs");
const path = require("path");
const os = require("os");
const cp = require("child_process");
const crypto = require("crypto");

export type TemplateAdapterKind = "zeroone" | "generic";
export interface TemplateModeManifest {
  label: string;
  entrypoint: string;
  injectionMarker?: string;
}
export interface TemplateManifest {
  schemaVersion: 1;
  id: string;
  name: string;
  version: string;
  description?: string;
  adapter: TemplateAdapterKind;
  compiler: "xelatex" | "pdflatex" | "lualatex";
  questionEnvironment?: string;
  modes: Record<string, TemplateModeManifest>;
}
export interface RegisteredTemplate {
  manifest: TemplateManifest;
  root: string;
  builtIn: boolean;
}

function slug(value: string): string {
  const s = value.trim().toLowerCase().replace(/[^a-z0-9._-]+/g, "-").replace(/^-+|-+$/g, "");
  return s || `template-${Date.now()}`;
}
function safeManifest(raw: any): TemplateManifest {
  if (!raw || raw.schemaVersion !== 1) throw new Error("TEMPLATE_MANIFEST_VERSION_UNSUPPORTED");
  if (!raw.id || !raw.name || !raw.version || !raw.adapter || !raw.compiler || !raw.modes) throw new Error("TEMPLATE_MANIFEST_INVALID");
  if (!["zeroone", "generic"].includes(raw.adapter)) throw new Error("TEMPLATE_ADAPTER_UNSUPPORTED");
  if (!["xelatex", "pdflatex", "lualatex"].includes(raw.compiler)) throw new Error("TEMPLATE_COMPILER_UNSUPPORTED");
  const modes: any = {};
  for (const [key, mode] of Object.entries(raw.modes)) {
    const m: any = mode;
    if (!m || typeof m.entrypoint !== "string" || !m.entrypoint.trim()) throw new Error(`TEMPLATE_MODE_INVALID:${key}`);
    modes[key] = { label: String(m.label || key), entrypoint: m.entrypoint.replace(/\\/g, "/"), injectionMarker: m.injectionMarker };
  }
  if (!Object.keys(modes).length) throw new Error("TEMPLATE_MODES_EMPTY");
  return {
    schemaVersion: 1,
    id: slug(String(raw.id)), name: String(raw.name), version: String(raw.version),
    description: raw.description ? String(raw.description) : undefined,
    adapter: raw.adapter, compiler: raw.compiler,
    questionEnvironment: raw.questionEnvironment ? String(raw.questionEnvironment) : "bbox",
    modes
  };
}
function inferManifest(root: string, fileName: string): TemplateManifest {
  const entries: Record<string, TemplateModeManifest> = {};
  const z = [
    ["book", "Book", "ZeroOne-Book.tex"],
    ["exam", "Exam", "ZeroOne-Exam.tex"],
    ["public", "Public", "ZeroOne-Public.tex"]
  ];
  for (const [key, label, file] of z) if (fs.existsSync(path.join(root, file))) entries[key] = { label, entrypoint: file };
  if (Object.keys(entries).length) return {
    schemaVersion: 1, id: slug(path.basename(fileName, path.extname(fileName))), name: path.basename(fileName, path.extname(fileName)),
    version: "1.0.0", description: "自动识别的 Everflow 兼容模板", adapter: "zeroone", compiler: "xelatex", questionEnvironment: "bbox", modes: entries
  };
  const candidates = ["main.tex", "Main.tex", "index.tex"];
  const entry = candidates.find(f => fs.existsSync(path.join(root, f)));
  if (!entry) throw new Error("TEMPLATE_ENTRYPOINT_NOT_FOUND: 请提供 template.manifest.json 或 main.tex");
  return {
    schemaVersion: 1, id: slug(path.basename(fileName, path.extname(fileName))), name: path.basename(fileName, path.extname(fileName)),
    version: "1.0.0", description: "自动识别的通用 LaTeX 模板", adapter: "generic", compiler: "xelatex", questionEnvironment: "bbox",
    modes: { default: { label: "Default", entrypoint: entry, injectionMarker: "% ZEROONE:QUESTIONS" } }
  };
}
function detectRoot(extractDir: string): string {
  const entries = fs.readdirSync(extractDir).filter((n: string) => n !== "__MACOSX");
  if (entries.length === 1 && fs.statSync(path.join(extractDir, entries[0])).isDirectory()) return path.join(extractDir, entries[0]);
  return extractDir;
}
function hashDirectory(root: string): string {
  const rows: string[] = [];
  const walk = (dir: string) => {
    for (const name of fs.readdirSync(dir).sort()) {
      const full = path.join(dir, name); const st = fs.statSync(full);
      if (st.isDirectory()) walk(full); else rows.push(`${path.relative(root, full).replace(/\\/g, "/")}:${crypto.createHash("sha256").update(fs.readFileSync(full)).digest("hex")}`);
    }
  };
  walk(root); return crypto.createHash("sha256").update(rows.join("\n")).digest("hex");
}

export class TemplateRegistry {
  constructor(private readonly projectRoot: string, private readonly ownerScope: string = "global") {}
  private get builtInRoot() { return path.join(this.projectRoot, "templates"); }
  private get userRoot() { return path.join(this.projectRoot, ".runtime/template-registry", this.ownerScope.replace(/[^a-zA-Z0-9._-]/g, "_"), "templates"); }

  private scanRoot(base: string, builtIn: boolean): RegisteredTemplate[] {
    const out: RegisteredTemplate[] = [];
    if (!fs.existsSync(base)) return out;
    const manifests: string[] = [];
    const walk = (dir: string, depth: number) => {
      if (depth > 4) return;
      for (const n of fs.readdirSync(dir)) {
        const full = path.join(dir, n); const st = fs.statSync(full);
        if (st.isDirectory()) walk(full, depth + 1);
        else if (n === "template.manifest.json") manifests.push(full);
      }
    };
    walk(base, 0);
    for (const file of manifests) {
      try { out.push({ manifest: safeManifest(JSON.parse(fs.readFileSync(file, "utf8"))), root: path.dirname(file), builtIn }); } catch { /* invalid manifests are ignored from listing */ }
    }
    return out;
  }

  list(): RegisteredTemplate[] {
    const all = [...this.scanRoot(this.builtInRoot, true), ...this.scanRoot(this.userRoot, false)];
    const seen = new Set<string>();
    return all.filter(t => { const k = `${t.manifest.id}@${t.manifest.version}`; if (seen.has(k)) return false; seen.add(k); return true; })
      .sort((a,b) => Number(b.builtIn) - Number(a.builtIn) || a.manifest.name.localeCompare(b.manifest.name));
  }
  get(id: string, version?: string): RegisteredTemplate {
    const list = this.list().filter(t => t.manifest.id === id && (!version || t.manifest.version === version));
    if (!list.length) throw new Error("TEMPLATE_NOT_FOUND");
    return list[0];
  }
  importZip(zipPath: string, originalName: string): RegisteredTemplate {
    if (!fs.existsSync(zipPath)) throw new Error("TEMPLATE_ZIP_NOT_FOUND");
    const size = fs.statSync(zipPath).size;
    if (size > 80 * 1024 * 1024) throw new Error("TEMPLATE_ZIP_TOO_LARGE");
    const listing = cp.spawnSync("unzip", ["-Z1", zipPath], { encoding: "utf8", timeout: 10000 });
    if (listing.status !== 0) throw new Error(`TEMPLATE_ZIP_INVALID:${listing.stderr || listing.stdout}`);
    const names = String(listing.stdout || "").split(/\r?\n/).filter(Boolean);
    if (names.length > 5000) throw new Error("TEMPLATE_ZIP_TOO_MANY_FILES");
    for (const n of names) {
      const normalized = n.replace(/\\/g, "/");
      if (normalized.startsWith("/") || normalized.split("/").includes("..")) throw new Error(`TEMPLATE_ZIP_UNSAFE_PATH:${n}`);
    }
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "zeroone-template-"));
    try {
      const unzip = cp.spawnSync("unzip", ["-q", zipPath, "-d", tmp], { encoding: "utf8", timeout: 30000 });
      if (unzip.status !== 0) throw new Error(`TEMPLATE_ZIP_EXTRACT_FAILED:${unzip.stderr || unzip.stdout}`);
      const root = detectRoot(tmp);
      const manifestPath = path.join(root, "template.manifest.json");
      const manifest = fs.existsSync(manifestPath) ? safeManifest(JSON.parse(fs.readFileSync(manifestPath, "utf8"))) : inferManifest(root, originalName);
      for (const mode of Object.values(manifest.modes)) if (!fs.existsSync(path.join(root, mode.entrypoint))) throw new Error(`TEMPLATE_ENTRYPOINT_MISSING:${mode.entrypoint}`);
      const dest = path.join(this.userRoot, manifest.id, manifest.version);
      fs.rmSync(dest, { recursive: true, force: true }); fs.mkdirSync(path.dirname(dest), { recursive: true }); fs.cpSync(root, dest, { recursive: true });
      fs.writeFileSync(path.join(dest, "template.manifest.json"), JSON.stringify(manifest, null, 2), "utf8");
      fs.writeFileSync(path.join(dest, ".template-hash"), hashDirectory(dest), "utf8");
      return { manifest, root: dest, builtIn: false };
    } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
  }
}
