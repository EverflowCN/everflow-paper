import { scanTexDocument, TexDiagnostic, QuestionNode } from "../../tex-scanner/src";
import { QuestionRevision, QuestionType } from "../../domain/src";

const crypto = require("crypto");

export interface ImportedQuestionDraft {
  temporaryId: string;
  ordinal: number;
  type: QuestionType;
  environment: "bbox" | "breakablebbox";
  contentMode: "raw_tex";
  rawTex: string;
  headingContext: QuestionNode["headingContext"];
  assets: QuestionNode["assets"];
  source: QuestionNode["source"];
}

export interface ImportPreview {
  sourceFile: string;
  questionCount: number;
  headingCount: number;
  assetCount: number;
  questions: ImportedQuestionDraft[];
  diagnostics: TexDiagnostic[];
}

function inferType(section = ""): QuestionType {
  if (/多项|多选/.test(section)) return "multiple_choice";
  if (/单项|单选|选择/.test(section)) return "single_choice";
  if (/填空/.test(section)) return "fill_blank";
  if (/判断/.test(section)) return "true_false";
  if (/综合|应用|解答|计算|简答|证明/.test(section)) return "comprehensive";
  return "custom";
}

function idFor(raw: string, ordinal: number): string {
  return `import_${ordinal}_${crypto.createHash("sha256").update(raw).digest("hex").slice(0, 12)}`;
}

export function buildImportPreview(sourceFile: string, tex: string): ImportPreview {
  const ir = scanTexDocument(tex, sourceFile);
  const questionNodes = ir.nodes.filter((n): n is QuestionNode => n.type === "question");
  const assetKeys = new Set<string>();
  const questions = questionNodes.map((q, idx) => {
    q.assets.forEach(a => assetKeys.add(a.path));
    return {
      temporaryId: idFor(q.rawTex, idx + 1),
      ordinal: idx + 1,
      type: inferType(q.headingContext.section?.title || q.headingContext.subsection?.title || ""),
      environment: q.environment,
      contentMode: "raw_tex" as const,
      rawTex: q.rawTex,
      headingContext: q.headingContext,
      assets: q.assets,
      source: q.source
    };
  });
  return {
    sourceFile,
    questionCount: questions.length,
    headingCount: ir.nodes.filter(n => n.type === "heading").length,
    assetCount: assetKeys.size,
    questions,
    diagnostics: ir.diagnostics
  };
}

export function draftToRevision(draft: ImportedQuestionDraft, questionId: string, revisionId: string, createdBy = "system"): QuestionRevision {
  const checksum = crypto.createHash("sha256").update(draft.rawTex).digest("hex");
  return {
    id: revisionId,
    questionId,
    revisionNumber: 1,
    contentMode: "raw_tex",
    content: { mode: "raw_tex", questionTex: draft.rawTex },
    assetIds: [],
    createdBy,
    createdAt: new Date().toISOString(),
    changeSummary: "Imported from TeX bbox source",
    checksum
  };
}
