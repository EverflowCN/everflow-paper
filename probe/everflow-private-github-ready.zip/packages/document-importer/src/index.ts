import { buildImportPreview } from "../../question-importer/src";
const fs=require("fs"), path=require("path"), os=require("os"), cp=require("child_process"), crypto=require("crypto");

export type DocumentKind="tex"|"pdf"|"docx"|"text"|"image"|"zip"|"unknown";
export interface DocumentDraft {
  temporaryId:string;
  ordinal:number;
  type:"single_choice"|"multiple_choice"|"fill_blank"|"short_answer"|"comprehensive"|"true_false"|"custom";
  stem:string;
  options:string[];
  rawText:string;
  pageStart?:number;
  pageEnd?:number;
  confidence:number;
  needsReview:boolean;
  source:{fileName:string;pageStart?:number;pageEnd?:number};
  ai?:any;
  contentMode?:"structured"|"raw_tex";
  rawTex?:string;
  importBlocks?:any[];
}
export type DocumentBlockType="paragraph"|"formula"|"image"|"table";
export interface DocumentBlock {
  index:number;
  type:DocumentBlockType;
  text?:string;
  relationshipId?:string;
  mediaPath?:string;
  inline?:boolean;
  metadata?:Record<string,unknown>;
}
export interface DocumentImportPreview {
  sourceFile:string;
  kind:DocumentKind;
  extractionMode:"tex-structural"|"text"|"document"|"pdf-text"|"vision-required"|"zip-tex";
  pageCount?:number;
  textChars:number;
  questionCount:number;
  imageCount:number;
  requiresAI:boolean;
  drafts:DocumentDraft[];
  warnings:string[];
  texPreview?:any;
  documentBlocks?:DocumentBlock[];
  formulaCount?:number;
  tableCount?:number;
}

function extKind(fileName:string):DocumentKind{const e=path.extname(fileName).toLowerCase();if(e==='.tex')return'tex';if(e==='.pdf')return'pdf';if(e==='.docx'||e==='.doc')return'docx';if(['.txt','.md','.rtf'].includes(e))return'text';if(['.png','.jpg','.jpeg','.webp','.bmp','.tif','.tiff'].includes(e))return'image';if(e==='.zip')return'zip';return'unknown';}
function cleanName(n:string){return path.basename(n).replace(/[^\w.\-\u4e00-\u9fff]+/g,'_').slice(0,180)||'upload.bin';}
function run(cmd:string,args:string[],opts:any={}){return cp.execFileSync(cmd,args,{encoding:'utf8',maxBuffer:32*1024*1024,...opts});}
function countDocxImages(file:string){try{return String(run('unzip',['-Z1',file])).split(/\r?\n/).filter((x:string)=>/^word\/media\//.test(x)).length}catch{return 0}}
function pageCountPdf(file:string){try{const s=String(run('pdfinfo',[file]));const m=s.match(/^Pages:\s+(\d+)/m);return m?Number(m[1]):undefined}catch{return undefined}}
function inferType(raw:string):DocumentDraft['type']{if(/(?:多项|多选)/.test(raw))return'multiple_choice';if(/(?:判断题|正确的是|错误的是|下列.*[（(]\s*[）)]|A[.、．])/s.test(raw))return'single_choice';if(/填空/.test(raw))return'fill_blank';if(/(?:计算|证明|分析|综合|简答|说明)/.test(raw))return'comprehensive';return'custom';}
function splitOptions(text:string){const marks=[...text.matchAll(/(?:^|\n)\s*([A-HＡ-Ｈ])[\.、．\)）]\s*/g)];if(marks.length<2)return{stem:text.trim(),options:[] as string[]};const start=marks[0].index||0,stem=text.slice(0,start).trim(),opts:string[]=[];for(let i=0;i<marks.length;i++){const a=(marks[i].index||0)+marks[i][0].length,b=i+1<marks.length?(marks[i+1].index||text.length):text.length;opts.push(`${marks[i][1].toUpperCase()}. ${text.slice(a,b).trim()}`)}return{stem,options:opts};}
function normalizeQuestionText(s:string){return s.replace(/\f/g,'\n').replace(/[ \t]+/g,' ').replace(/\n{3,}/g,'\n\n').trim();}
function segmentPages(pages:string[],fileName:string):DocumentDraft[]{const starts:{page:number;index:number;num:number;matchLen:number}[]=[];for(let p=0;p<pages.length;p++){const re=/(?:^|\n)\s*(\d{1,3})[\.、．]\s+(?=\S)/g;let m;while((m=re.exec(pages[p]))){starts.push({page:p,index:(m.index||0)+(m[0].startsWith('\n')?1:0),num:Number(m[1]),matchLen:m[0].trimStart().length});}}
  if(!starts.length){const raw=normalizeQuestionText(pages.join('\n'));if(!raw)return[];const {stem,options}=splitOptions(raw);return[{temporaryId:'doc_1_'+crypto.createHash('sha1').update(raw).digest('hex').slice(0,10),ordinal:1,type:inferType(raw),stem,options,rawText:raw,pageStart:1,pageEnd:pages.length,confidence:0.35,needsReview:true,source:{fileName,pageStart:1,pageEnd:pages.length}}];}
  const out:DocumentDraft[]=[];for(let i=0;i<starts.length;i++){const st=starts[i],nx=starts[i+1];let chunks:string[]=[];if(!nx||nx.page!==st.page){chunks.push(pages[st.page].slice(st.index));for(let p=st.page+1;p<(nx?nx.page:pages.length);p++)chunks.push(pages[p]);if(nx)chunks.push(pages[nx.page].slice(0,nx.index));}else chunks=[pages[st.page].slice(st.index,nx.index)];let raw=normalizeQuestionText(chunks.join('\n'));raw=raw.replace(/^\s*\d{1,3}[\.、．]\s+/,'');if(raw.length<4)continue;const {stem,options}=splitOptions(raw),confidence=Math.min(.96,.56+(options.length>=4?.22:0)+(raw.length>30?.1:0));out.push({temporaryId:`doc_${i+1}_${crypto.createHash('sha1').update(raw).digest('hex').slice(0,10)}`,ordinal:i+1,type:inferType(raw),stem,options,rawText:raw,pageStart:st.page+1,pageEnd:(nx?nx.page+1:pages.length),confidence,needsReview:confidence<.82,source:{fileName,pageStart:st.page+1,pageEnd:(nx?nx.page+1:pages.length)}});}return out;}
function analyzeText(fileName:string,text:string,mode:DocumentImportPreview['extractionMode'],imageCount=0,pageCount?:number):DocumentImportPreview{const pages=text.split('\f');while(pages.length>1&&!pages[pages.length-1].trim())pages.pop();const drafts=segmentPages(pages,fileName);return{sourceFile:fileName,kind:extKind(fileName),extractionMode:mode,pageCount:pageCount||pages.length,textChars:text.length,questionCount:drafts.length,imageCount,requiresAI:drafts.length===0||drafts.some(x=>x.needsReview),drafts,warnings:drafts.length?[]:['未能可靠识别题号边界，建议使用 AI 或人工框选。']};}

function xmlDecode(s:string){return s.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&apos;/g,"'");}
function imageMime(mediaPath:string|undefined){const e=String(mediaPath||'').toLowerCase();if(e.endsWith('.png'))return'image/png';if(e.endsWith('.jpg')||e.endsWith('.jpeg'))return'image/jpeg';if(e.endsWith('.webp'))return'image/webp';if(e.endsWith('.pdf'))return'application/pdf';if(e.endsWith('.svg'))return'image/svg+xml';return'application/octet-stream';}
function xmlAttr(chunk:string,name:string){const m=chunk.match(new RegExp(`${name}="([^"]+)"`));return m?m[1]:undefined;}
function extractDocxBlocks(file:string):DocumentBlock[]{
  let xml='',rels='';try{xml=String(run('unzip',['-p',file,'word/document.xml']));rels=String(run('unzip',['-p',file,'word/_rels/document.xml.rels']));}catch{return[];}
  const relMap=new Map<string,string>();for(const m of rels.matchAll(/<Relationship\b[^>]*Id="([^"]+)"[^>]*Target="([^"]+)"[^>]*\/>/g))relMap.set(m[1],m[2].replace(/^\.\//,''));
  const body=(xml.match(/<w:body[\s\S]*?<\/w:body>/)||[])[0]||xml;
  const chunks=[...body.matchAll(/<(w:p|w:tbl)\b[\s\S]*?<\/\1>/g)].map(m=>m[0]);const out:DocumentBlock[]=[];let idx=0;
  for(const chunk of chunks){
    if(chunk.startsWith('<w:tbl')){const cells=[...chunk.matchAll(/<w:t(?:\s[^>]*)?>([\s\S]*?)<\/w:t>/g)].map(x=>xmlDecode(x[1])).filter(Boolean);out.push({index:idx++,type:'table',text:cells.join(' | '),metadata:{cellTextCount:cells.length,latex:`\\begin{tabular}{${'c'.repeat(Math.max(1,Math.min(8,cells.length)))}}${cells.map((x,i)=>`${x}${i===cells.length-1?'':' & '}`).join('')}\\end{tabular}`}});continue;}
    const texts=[...chunk.matchAll(/<w:t(?:\s[^>]*)?>([\s\S]*?)<\/w:t>/g)].map(x=>xmlDecode(x[1])).filter(Boolean);if(texts.length)out.push({index:idx++,type:'paragraph',text:texts.join('')});
    const formulaCount=(chunk.match(/<(?:m:oMath|m:oMathPara)\b/g)||[]).length;if(formulaCount){const mathText=[...chunk.matchAll(/<m:t(?:\s[^>]*)?>([\s\S]*?)<\/m:t>/g)].map(x=>xmlDecode(x[1])).join('');out.push({index:idx++,type:'formula',text:mathText||undefined,metadata:{format:'OMML',count:formulaCount}});}
    for(const m of chunk.matchAll(/<a:blip\b[^>]*r:embed="([^"]+)"[^>]*\/?>(?:<\/a:blip>)?/g)){
      const rid=m[1],target=relMap.get(rid),mediaPath=target?`word/${target.replace(/^word\//,'')}`:undefined,isAnchor=/<wp:anchor\b/.test(chunk);let dataBase64:string|undefined;
      if(mediaPath){try{dataBase64=Buffer.from(run('unzip',['-p',file,mediaPath],{encoding:null}) as any).toString('base64')}catch{}}
      const extent=chunk.match(/<wp:extent\b[^>]*cx="(\d+)"[^>]*cy="(\d+)"/),posH=(chunk.match(/<wp:positionH\b[^>]*relativeFrom="([^"]+)"[\s\S]*?<wp:align>([^<]+)<\/wp:align>/)||[]),posV=(chunk.match(/<wp:positionV\b[^>]*relativeFrom="([^"]+)"[\s\S]*?<wp:align>([^<]+)<\/wp:align>/)||[]),offH=(chunk.match(/<wp:positionH\b[^>]*[\s\S]*?<wp:posOffset>(-?\d+)<\/wp:posOffset>/)||[]),offV=(chunk.match(/<wp:positionV\b[^>]*[\s\S]*?<wp:posOffset>(-?\d+)<\/wp:posOffset>/)||[]),wrap=(chunk.match(/<wp:(wrapNone|wrapSquare|wrapTight|wrapThrough|wrapTopAndBottom)\b/)||[])[1];
      const h=String(posH[2]||'').toLowerCase(),placement=isAnchor?(h==='right'?'right':h==='left'?'left':'below'):'inline';
      out.push({index:idx++,type:'image',relationshipId:rid,mediaPath,inline:!isAnchor,metadata:{anchor:isAnchor?'floating':'inline',placement,mimeType:imageMime(mediaPath),dataBase64,horizontal:h||undefined,vertical:String(posV[2]||'').toLowerCase()||undefined,relativeFromH:posH[1]||undefined,relativeFromV:posV[1]||undefined,offsetXEmu:offH[1]?Number(offH[1]):undefined,offsetYEmu:offV[1]?Number(offV[1]):undefined,widthEmu:extent?Number(extent[1]):undefined,heightEmu:extent?Number(extent[2]):undefined,wrap}});
    }
  }
  return out;
}

function attachDocxBlocksToDrafts(drafts:DocumentDraft[],blocks:DocumentBlock[]){
  if(!drafts.length||!blocks.length)return drafts;const ranges:any[]=[];let current=-1;
  for(const b of blocks){if(b.type==='paragraph'){const text=String(b.text||'').trim(),m=text.match(/^\s*(\d{1,3})[\.、．]\s+/);if(m){current=Math.min(drafts.length-1,Math.max(0,Number(m[1])-1));ranges[current]=ranges[current]||[];continue;}if(text.length>=4){const hit=drafts.findIndex(d=>String(d.stem||'').replace(/\s+/g,'').startsWith(text.replace(/\s+/g,'')));if(hit>=0){current=hit;ranges[current]=ranges[current]||[];continue;}}if(current<0&&drafts.length===1){current=0;ranges[current]=ranges[current]||[];}}if(current>=0&&(b.type==='image'||b.type==='formula'||b.type==='table')){ranges[current]=ranges[current]||[];if(b.type==='image'){ranges[current].push({kind:'image',placement:String((b.metadata as any)?.placement||'inline'),mediaPath:b.mediaPath,mimeType:(b.metadata as any)?.mimeType,dataBase64:(b.metadata as any)?.dataBase64,anchor:{mode:(b.metadata as any)?.anchor,horizontal:(b.metadata as any)?.horizontal,vertical:(b.metadata as any)?.vertical,relativeFromH:(b.metadata as any)?.relativeFromH,relativeFromV:(b.metadata as any)?.relativeFromV,wrap:(b.metadata as any)?.wrap,offsetXEmu:(b.metadata as any)?.offsetXEmu,offsetYEmu:(b.metadata as any)?.offsetYEmu,widthEmu:(b.metadata as any)?.widthEmu,heightEmu:(b.metadata as any)?.heightEmu}});}else if(b.type==='formula')ranges[current].push({kind:'raw_tex',content:`\\(${String(b.text||'').replace(/\\/g,'\\\\')}\\)`,placement:'inline',source:'OMML'});else ranges[current].push({kind:'raw_tex',content:String((b.metadata as any)?.latex||`% Word table: ${b.text||''}`),placement:'below',source:'DOCX_TABLE'});}}
  return drafts.map((d,i)=>({...d,importBlocks:ranges[i]||[]}));
}
function assertZipSafe(zipPath:string){const names=String(run('unzip',['-Z1',zipPath])).split(/\r?\n/).filter(Boolean);if(names.length>2000)throw new Error('IMPORT_ZIP_TOO_MANY_FILES');for(const n of names){if(path.isAbsolute(n)||n.split(/[\\/]+/).includes('..'))throw new Error('IMPORT_ZIP_PATH_TRAVERSAL');}return names;}

export function analyzeDocumentFile(fileName:string,data:any):DocumentImportPreview{
  if(data.length>50*1024*1024)throw new Error('IMPORT_FILE_TOO_LARGE');const kind=extKind(fileName);if(kind==='unknown')throw new Error('IMPORT_FILE_TYPE_UNSUPPORTED');
  if(kind==='tex'){const tex=data.toString('utf8'),p=buildImportPreview(fileName,tex);return{sourceFile:fileName,kind,extractionMode:'tex-structural',textChars:tex.length,questionCount:p.questionCount,imageCount:p.assetCount,requiresAI:false,drafts:p.questions.map((q:any,i:number)=>({temporaryId:q.temporaryId,ordinal:i+1,type:q.type,stem:q.rawTex,options:[],rawText:q.rawTex,contentMode:'raw_tex',rawTex:q.rawTex,confidence:1,needsReview:false,source:{fileName}})),warnings:p.diagnostics.filter((d:any)=>d.severity!=='info').map((d:any)=>`${d.code}: ${d.message}`),texPreview:p};}
  if(kind==='image')return{sourceFile:fileName,kind,extractionMode:'vision-required',textChars:0,questionCount:0,imageCount:1,requiresAI:true,drafts:[],warnings:['图片/扫描件需要视觉 AI 或人工框选后录题。']};
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'everflow-import-')),fp=path.join(tmp,cleanName(fileName));fs.writeFileSync(fp,data);try{
    if(kind==='pdf'){const pages=pageCountPdf(fp);let text='';try{text=String(run('pdftotext',['-layout',fp,'-']));}catch{}const visible=text.replace(/\s/g,'').length;if(visible<Math.max(20,(pages||1)*8))return{sourceFile:fileName,kind,extractionMode:'vision-required',pageCount:pages,textChars:text.length,questionCount:0,imageCount:0,requiresAI:true,drafts:[],warnings:['该 PDF 可提取文本过少，疑似扫描件；建议使用视觉 AI。']};return analyzeText(fileName,text,'pdf-text',0,pages);}
    if(kind==='docx'){let text='';try{text=String(run('pandoc',[fp,'-t','plain']));}catch{throw new Error('IMPORT_DOCX_PARSE_FAILED')}const blocks=extractDocxBlocks(fp),base=analyzeText(fileName,text,'document',countDocxImages(fp)),drafts=attachDocxBlocksToDrafts(base.drafts,blocks);return{...base,drafts,documentBlocks:blocks,formulaCount:blocks.filter(x=>x.type==='formula').length,tableCount:blocks.filter(x=>x.type==='table').length,warnings:[...base.warnings,...(blocks.some(x=>x.type==='image')?['已提取 Word 图片二进制、锚点与顺序；复杂环绕将保留锚点元数据并进入人工确认。']:[])]};}
    if(kind==='text'){return analyzeText(fileName,data.toString('utf8'),'text');}
    if(kind==='zip'){const names=assertZipSafe(fp),texNames=names.filter((n:string)=>/\.tex$/i.test(n));if(!texNames.length)throw new Error('IMPORT_ZIP_NO_TEX');const target=texNames.find((n:string)=>/(question|题|main)/i.test(n))||texNames[0];const tex=String(run('unzip',['-p',fp,target]));const p=buildImportPreview(`${fileName}:${target}`,tex);return{sourceFile:fileName,kind,extractionMode:'zip-tex',textChars:tex.length,questionCount:p.questionCount,imageCount:p.assetCount,requiresAI:false,drafts:p.questions.map((q:any,i:number)=>({temporaryId:q.temporaryId,ordinal:i+1,type:q.type,stem:q.rawTex,options:[],rawText:q.rawTex,contentMode:'raw_tex',rawTex:q.rawTex,confidence:1,needsReview:false,source:{fileName}})),warnings:[`从 ZIP 中选择题源：${target}`,...p.diagnostics.filter((d:any)=>d.severity!=='info').map((d:any)=>`${d.code}: ${d.message}`)],texPreview:p};}
    throw new Error('IMPORT_FILE_TYPE_UNSUPPORTED');
  } finally {fs.rmSync(tmp,{recursive:true,force:true});}
}

export function commitDraftToPayload(d:DocumentDraft,id:string,meta:any={}){const common={id,no:meta.no||d.ordinal,year:meta.year||new Date().getFullYear(),type:meta.typeLabel||({'single_choice':'单选','multiple_choice':'多选','comprehensive':'综合','fill_blank':'填空','true_false':'判断'} as any)[d.type]||'自定义',difficulty:meta.difficulty||3,subject:meta.subject||'待分类',chapter:meta.chapter||'待分类',topic:meta.topic||'待确认',score:meta.score||2,text:d.stem,opts:d.options.join('　'),tags:Array.isArray(meta.tags)?meta.tags:['批量导入'],sourceDocument:{fileName:d.source.fileName,pageStart:d.pageStart,pageEnd:d.pageEnd},revision:1,importConfidence:d.confidence};if(d.contentMode==='raw_tex'||d.rawTex){const tex=String(d.rawTex||d.rawText||d.stem);return{...common,text:tex,content:{mode:'raw_tex',questionTex:tex}};}const blocks:any[]=[{type:'text',content:d.stem}];for(const b of Array.isArray(d.importBlocks)?d.importBlocks:[]){if(b.kind==='raw_tex')blocks.push({type:'raw_tex',content:String(b.content||''),placement:b.placement||'below'});else if(b.kind==='image')blocks.push({type:'import_asset',importAsset:b});}return{...common,content:{mode:'structured',stemTex:d.stem,options:d.options.map((x,i)=>({key:String.fromCharCode(65+i),tex:x.replace(/^[A-H]\.\s*/, '')})),blocks}};}

export function buildAITextFromPreview(preview:DocumentImportPreview,maxChars=50000){const chunks=preview.drafts.map(d=>`[Question ${d.ordinal}${d.pageStart?` pages ${d.pageStart}-${d.pageEnd||d.pageStart}`:''}]\n${d.rawText}`);return chunks.join('\n\n').slice(0,maxChars);}
export function visionPartsFromFile(fileName:string,filePath:string,startPage=1,maxPages=4):{mimeType:string;dataBase64:string}[]{const kind=extKind(fileName);if(kind==='image'){const ext=path.extname(fileName).toLowerCase(),mime=ext==='.png'?'image/png':ext==='.webp'?'image/webp':'image/jpeg';return[{mimeType:mime,dataBase64:fs.readFileSync(filePath).toString('base64')}];}if(kind!=='pdf')return[];const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'everflow-pages-')),prefix=path.join(tmp,'page');try{const first=Math.max(1,startPage),last=first+Math.max(1,Math.min(8,maxPages))-1;run('pdftoppm',['-f',String(first),'-l',String(last),'-r','130','-png',filePath,prefix],{encoding:null});const files=fs.readdirSync(tmp).filter((x:string)=>x.endsWith('.png')).sort();return files.map((x:string)=>({mimeType:'image/png',dataBase64:fs.readFileSync(path.join(tmp,x)).toString('base64')}));}finally{fs.rmSync(tmp,{recursive:true,force:true});}}
