export type UUID = string;

export type QuestionContentMode = "structured" | "mixed" | "raw_tex";
export type QuestionType =
  | "single_choice"
  | "multiple_choice"
  | "fill_blank"
  | "short_answer"
  | "comprehensive"
  | "true_false"
  | "custom";

export interface QuestionSource {
  type: "real_exam" | "mock_exam" | "book" | "user" | "import" | "ai" | "unknown";
  name?: string;
  year?: number;
  originalNumber?: string;
  metadata?: Record<string, unknown>;
}

export interface Question {
  id: UUID;
  bankId: UUID;
  currentRevisionId: UUID;
  type: QuestionType;
  difficulty?: number;
  defaultScore?: number;
  source?: QuestionSource;
  createdAt: string;
  updatedAt: string;
  archivedAt?: string;
}

export interface QuestionOption {
  key: string;
  tex: string;
}

export interface TextBlock { type: "text"; content: string; }
export interface RawTexBlock { type: "raw_tex"; content: string; }
export interface AssetBlock {
  type: "asset";
  assetId: UUID;
  placement: "inline" | "above" | "below" | "left" | "right" | "option";
  optionKey?: string;
  widthRatio?: number;
  anchor?: {
    mode?: "inline" | "floating";
    horizontal?: "left" | "center" | "right" | "absolute";
    vertical?: "top" | "center" | "bottom" | "absolute";
    relativeFromH?: string;
    relativeFromV?: string;
    wrap?: string;
    offsetXEmu?: number;
    offsetYEmu?: number;
    widthEmu?: number;
    heightEmu?: number;
  };
}
export type QuestionBlock = TextBlock | RawTexBlock | AssetBlock;

export interface StructuredQuestionContent {
  mode: "structured";
  stemTex: string;
  options?: QuestionOption[];
  answerTex?: string;
  analysisTex?: string;
  noteTex?: string;
  /** Supplemental visual/LaTeX blocks inserted without discarding structured stem/options. */
  blocks?: QuestionBlock[];
}

export interface RawTexQuestionContent {
  mode: "raw_tex";
  questionTex: string;
  answerTex?: string;
  analysisTex?: string;
}

export interface MixedQuestionContent {
  mode: "mixed";
  blocks: QuestionBlock[];
  answerBlocks?: QuestionBlock[];
  analysisBlocks?: QuestionBlock[];
}

export type QuestionContent = StructuredQuestionContent | RawTexQuestionContent | MixedQuestionContent;

export interface QuestionRevision {
  id: UUID;
  questionId: UUID;
  revisionNumber: number;
  contentMode: QuestionContentMode;
  content: QuestionContent;
  assetIds: UUID[];
  createdBy: UUID;
  createdAt: string;
  changeSummary?: string;
  checksum: string;
}

export interface Taxonomy {
  id: UUID;
  bankId: UUID;
  name: string;
  version: string;
  type: "official_exam_outline" | "book" | "custom";
  isDefault: boolean;
}

export interface TaxonomyNode {
  id: UUID;
  taxonomyId: UUID;
  parentId?: UUID;
  code?: string;
  name: string;
  level: number;
  order: number;
  metadata?: Record<string, unknown>;
}

export interface QuestionTaxonomyRelation {
  questionId: UUID;
  taxonomyNodeId: UUID;
  relation: "primary" | "secondary";
  confidence?: number;
  source: "manual" | "import" | "ai";
}

export interface Paper {
  id: UUID;
  ownerId: UUID;
  title: string;
  templateVersionId: UUID;
  mode: "book" | "exam" | "public" | string;
  revision: number;
  config: Record<string, unknown>;
  createdAt: string;
  updatedAt: string;
}

export type PaperSectionType = "questiongroup" | "part" | "chapter" | "section" | "subsection" | "custom";
export interface PaperSection {
  id: UUID;
  paperId: UUID;
  parentId?: UUID;
  type: PaperSectionType;
  title: string;
  order: number;
  config?: Record<string, unknown>;
}

export interface PaperItemOverride {
  stemTex?: string;
  hidden?: boolean;
  answerSpace?: PaperAnswerSpace;
  config?: Record<string, unknown>;
}

export interface PaperItem {
  id: UUID;
  paperId: UUID;
  sectionId: UUID;
  questionId: UUID;
  questionRevisionId: UUID;
  order: number;
  score?: number;
  override?: PaperItemOverride;
}

export interface PaperSnapshot {
  paper: Paper;
  sections: PaperSection[];
  items: PaperItem[];
  revisions: Record<UUID, QuestionRevision>;
}

export type QuestionRelationType =
  | "variant_of"
  | "parent_of"
  | "similar_to"
  | "same_source"
  | "prerequisite"
  | "duplicate_of";

export interface TaxonomyVersionRef {
  id: UUID;
  name: string;
  version: string;
  type: "official_exam_outline" | "book" | "custom";
  subject?: string;
}

export interface QuestionTaxonomyMapping {
  taxonomyVersionId: UUID;
  taxonomyNodeId?: UUID;
  path: string[];
  source: "manual" | "import" | "ai" | "migration";
  confidence?: number;
  mappedAt: string;
}

export interface QuestionRelationEdge {
  id: UUID;
  type: QuestionRelationType;
  sourceQuestionId: UUID;
  targetQuestionId: UUID;
  createdBy: UUID;
  createdAt: string;
  metadata?: Record<string, unknown>;
}

export interface QuestionUsageSummary {
  count: number;
  paperCount: number;
  lastUsedAt?: string;
  recentPaperIds: UUID[];
}

export type AnswerSpaceMode = "auto" | "none" | "fixed";
export interface PaperAnswerSpace {
  mode: AnswerSpaceMode;
  heightCm?: number;
}
