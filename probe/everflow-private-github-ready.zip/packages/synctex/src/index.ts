const childProcess = require("child_process");
const path = require("path");

export interface SyncTexForwardResult {
  page: number;
  x: number;
  y: number;
  h?: number;
  v?: number;
  width?: number;
  height?: number;
  output?: string;
}

export interface SyncTexReverseResult {
  input: string;
  line: number;
  column: number;
  offset?: number;
}

function parseRecords(text: string): Record<string, string>[] {
  const lines = text.split(/\r?\n/);
  const records: Record<string, string>[] = [];
  let current: Record<string, string> = {};
  let inResult = false;
  for (const raw of lines) {
    const line = raw.trimEnd();
    if (line === "SyncTeX result begin") { inResult = true; current = {}; continue; }
    if (line === "SyncTeX result end") {
      if (Object.keys(current).length) records.push(current);
      current = {}; inResult = false; continue;
    }
    if (!inResult) continue;
    if (!line.trim()) {
      if (Object.keys(current).length) { records.push(current); current = {}; }
      continue;
    }
    const i = line.indexOf(":");
    if (i > 0) {
      const key = line.slice(0, i);
      if ((key === "Output" && current.Output) || (key === "Input" && current.Input)) { records.push(current); current = {}; }
      current[key] = line.slice(i + 1);
    }
  }
  if (Object.keys(current).length) records.push(current);
  return records;
}

function n(record: Record<string, string>, key: string, fallback = 0): number {
  const value = Number(record[key]);
  return Number.isFinite(value) ? value : fallback;
}

export function parseForwardOutput(text: string): SyncTexForwardResult[] {
  return parseRecords(text)
    .filter(r => r.Page)
    .map(r => ({
      page: n(r, "Page"), x: n(r, "x"), y: n(r, "y"),
      h: r.h !== undefined ? n(r, "h") : undefined,
      v: r.v !== undefined ? n(r, "v") : undefined,
      width: r.W !== undefined ? n(r, "W") : undefined,
      height: r.H !== undefined ? n(r, "H") : undefined,
      output: r.Output
    }));
}

export function parseReverseOutput(text: string): SyncTexReverseResult[] {
  return parseRecords(text)
    .filter(r => r.Input && r.Line)
    .map(r => ({
      input: r.Input,
      line: n(r, "Line"),
      column: n(r, "Column", 1),
      offset: r.Offset !== undefined ? n(r, "Offset") : undefined
    }));
}

export function forwardSync(opts: { workspace: string; pdf: string; input: string; line: number; column?: number; pageHint?: number }): SyncTexForwardResult[] {
  const input = opts.input.replace(/\\/g, "/");
  const base = `${Math.max(1, opts.line)}:${Math.max(0, opts.column || 0)}`;
  // SyncTeX 1.5 shipped by TeX Live accepts the portable line:column:input form.
  // Some newer builds also accept a page hint, but including a zero hint is parsed as part of the input on older builds.
  const query = opts.pageHint && opts.pageHint > 0 ? `${base}:${opts.pageHint}:${input}` : `${base}:${input}`;
  const res = childProcess.spawnSync("synctex", ["view", "-i", query, "-o", opts.pdf], {
    cwd: opts.workspace, encoding: "utf8", maxBuffer: 4 * 1024 * 1024
  });
  if (res.error) throw res.error;
  return parseForwardOutput(`${res.stdout || ""}\n${res.stderr || ""}`);
}

export function reverseSync(opts: { workspace: string; pdf: string; page: number; x: number; y: number }): SyncTexReverseResult[] {
  const query = `${Math.max(1, opts.page)}:${opts.x}:${opts.y}:${opts.pdf}`;
  const res = childProcess.spawnSync("synctex", ["edit", "-o", query], {
    cwd: opts.workspace, encoding: "utf8", maxBuffer: 4 * 1024 * 1024
  });
  if (res.error) throw res.error;
  return parseReverseOutput(`${res.stdout || ""}\n${res.stderr || ""}`);
}

export function normalizeSyncInput(workspace: string, input: string): string {
  const abs = path.isAbsolute(input) ? input : path.resolve(workspace, input);
  return path.relative(workspace, abs).replace(/\\/g, "/");
}
