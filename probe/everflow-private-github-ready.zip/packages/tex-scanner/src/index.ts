export interface ScannerPosition {
  offset: number;
  line: number;
  column: number;
}

export interface SourceSpan {
  file: string;
  startOffset: number;
  endOffset: number;
  startLine: number;
  endLine: number;
  startColumn: number;
  endColumn: number;
}

export interface TexDiagnostic {
  severity: "info" | "warning" | "error";
  code: string;
  message: string;
  source?: SourceSpan;
  recoverable: boolean;
}

export type TexTokenType = "text" | "command" | "begin_env" | "end_env" | "comment" | "verbatim";
export interface TexToken {
  type: TexTokenType;
  value: string;
  name?: string;
  args?: string[];
  start: ScannerPosition;
  end: ScannerPosition;
}

export interface HeadingContextEntry { title: string; source: SourceSpan; }
export interface HeadingContext {
  questiongroup?: HeadingContextEntry;
  part?: HeadingContextEntry;
  chapter?: HeadingContextEntry;
  section?: HeadingContextEntry;
  subsection?: HeadingContextEntry;
}

export interface AssetReference {
  command: string;
  path: string;
  source: SourceSpan;
}

export interface HeadingNode {
  type: "heading";
  command: "questiongroup" | "part" | "chapter" | "section" | "subsection";
  title: string;
  source: SourceSpan;
}

export interface QuestionNode {
  type: "question";
  environment: "bbox" | "breakablebbox";
  rawTex: string;
  source: SourceSpan;
  headingContext: HeadingContext;
  assets: AssetReference[];
  diagnostics: TexDiagnostic[];
}

export interface InputNode {
  type: "input";
  command: "input" | "include";
  path: string;
  source: SourceSpan;
}

export type TexNode = HeadingNode | QuestionNode | InputNode;
export interface TexDocumentIR {
  sourceFile: string;
  nodes: TexNode[];
  tokens: TexToken[];
  diagnostics: TexDiagnostic[];
}

const VERBATIM_ENVS = new Set(["verbatim", "Verbatim", "lstlisting", "minted"]);
const HEADINGS = new Set(["questiongroup", "part", "chapter", "section", "subsection"]);
const ASSET_COMMANDS: Record<string, number[]> = {
  includegraphics: [0],
  qimage: [0],
  choiceimage: [0],
  qsideimage: [0],
  qtwoimages: [0, 1],
  choicewithimage: [1]
};
const MULTI_ARG_COUNTS: Record<string, number> = {
  includegraphics: 1,
  qimage: 1,
  choiceimage: 1,
  qsideimage: 2,
  qtwoimages: 2,
  choicewithimage: 2
};

function isLetter(ch: string): boolean { return /[A-Za-z@]/.test(ch); }
function isEscaped(source: string, offset: number): boolean {
  let n = 0;
  for (let i = offset - 1; i >= 0 && source[i] === "\\"; i--) n++;
  return n % 2 === 1;
}

class PositionIndex {
  private readonly lineStarts: number[] = [0];
  constructor(private readonly source: string) {
    for (let i = 0; i < source.length; i++) if (source[i] === "\n") this.lineStarts.push(i + 1);
  }
  at(offset: number): ScannerPosition {
    let lo = 0, hi = this.lineStarts.length - 1;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      if (this.lineStarts[mid] <= offset) lo = mid + 1; else hi = mid - 1;
    }
    const lineIndex = Math.max(0, hi);
    return { offset, line: lineIndex + 1, column: offset - this.lineStarts[lineIndex] + 1 };
  }
  span(file: string, start: number, end: number): SourceSpan {
    const a = this.at(start), b = this.at(Math.max(start, end));
    return { file, startOffset: start, endOffset: end, startLine: a.line, endLine: b.line, startColumn: a.column, endColumn: b.column };
  }
}

function skipSpace(source: string, cursor: number): number {
  while (cursor < source.length && /\s/.test(source[cursor])) cursor++;
  return cursor;
}

function readBalanced(source: string, cursor: number, open = "{", close = "}"): { value: string; end: number } | null {
  cursor = skipSpace(source, cursor);
  if (source[cursor] !== open) return null;
  let depth = 0;
  const start = cursor + 1;
  for (let i = cursor; i < source.length; i++) {
    const ch = source[i];
    if ((ch === open || ch === close) && isEscaped(source, i)) continue;
    if (ch === open) depth++;
    else if (ch === close) {
      depth--;
      if (depth === 0) return { value: source.slice(start, i), end: i + 1 };
    }
  }
  return null;
}

function readCommandName(source: string, slash: number): { name: string; end: number } {
  let i = slash + 1;
  if (i >= source.length) return { name: "", end: i };
  if (!isLetter(source[i])) return { name: source[i], end: i + 1 };
  const start = i;
  while (i < source.length && isLetter(source[i])) i++;
  return { name: source.slice(start, i), end: i };
}

function readArgs(source: string, cursor: number, count: number): { args: string[]; end: number } {
  const args: string[] = [];
  let i = skipSpace(source, cursor);
  if (source[i] === "[") {
    const optional = readBalanced(source, i, "[", "]");
    if (optional) i = optional.end;
  }
  for (let n = 0; n < count; n++) {
    const arg = readBalanced(source, i);
    if (!arg) break;
    args.push(arg.value);
    i = arg.end;
  }
  return { args, end: i };
}

export function tokenizeTex(source: string): TexToken[] {
  const pos = new PositionIndex(source);
  const tokens: TexToken[] = [];
  let i = 0;
  while (i < source.length) {
    if (source[i] === "%" && !isEscaped(source, i)) {
      const start = i;
      while (i < source.length && source[i] !== "\n") i++;
      tokens.push({ type: "comment", value: source.slice(start, i), start: pos.at(start), end: pos.at(i) });
      continue;
    }
    if (source[i] !== "\\") { i++; continue; }

    const start = i;
    const cmd = readCommandName(source, i);
    if (!cmd.name) { i = cmd.end; continue; }

    if (cmd.name === "verb") {
      let cursor = cmd.end;
      if (source[cursor] === "*") cursor++;
      const delimiter = source[cursor];
      if (delimiter && !/\s/.test(delimiter)) {
        const close = source.indexOf(delimiter, cursor + 1);
        i = close >= 0 ? close + 1 : source.length;
        tokens.push({ type: "verbatim", name: "verb", value: source.slice(start, i), start: pos.at(start), end: pos.at(i) });
        continue;
      }
    }

    if (cmd.name === "begin" || cmd.name === "end") {
      const envArg = readBalanced(source, cmd.end);
      if (envArg) {
        const env = envArg.value.trim();
        const tokenEnd = envArg.end;
        tokens.push({ type: cmd.name === "begin" ? "begin_env" : "end_env", value: env, name: env, args: [env], start: pos.at(start), end: pos.at(tokenEnd) });
        i = tokenEnd;
        if (cmd.name === "begin" && VERBATIM_ENVS.has(env)) {
          const endLiteral = `\\end{${env}}`;
          const close = source.indexOf(endLiteral, i);
          if (close >= 0) {
            if (close > i) tokens.push({ type: "verbatim", name: env, value: source.slice(i, close), start: pos.at(i), end: pos.at(close) });
            const closeEnd = close + endLiteral.length;
            tokens.push({ type: "end_env", value: env, name: env, args: [env], start: pos.at(close), end: pos.at(closeEnd) });
            i = closeEnd;
          } else {
            if (i < source.length) tokens.push({ type: "verbatim", name: env, value: source.slice(i), start: pos.at(i), end: pos.at(source.length) });
            i = source.length;
          }
        }
        continue;
      }
    }

    let argCount = 0;
    if (HEADINGS.has(cmd.name) || cmd.name === "input" || cmd.name === "include") argCount = 1;
    else if (MULTI_ARG_COUNTS[cmd.name]) argCount = MULTI_ARG_COUNTS[cmd.name];
    const parsed = argCount ? readArgs(source, cmd.end, argCount) : { args: [] as string[], end: cmd.end };
    const end = parsed.args.length ? parsed.end : cmd.end;
    tokens.push({ type: "command", value: cmd.name, name: cmd.name, args: parsed.args, start: pos.at(start), end: pos.at(end) });
    i = Math.max(cmd.end, end);
  }
  return tokens;
}

function cloneContext(context: HeadingContext): HeadingContext {
  return { ...context };
}

export function scanTexDocument(source: string, sourceFile = "input.tex"): TexDocumentIR {
  const tokens = tokenizeTex(source);
  const index = new PositionIndex(source);
  const nodes: TexNode[] = [];
  const diagnostics: TexDiagnostic[] = [];
  const environmentStack: { name: string; token: TexToken }[] = [];
  const headingContext: HeadingContext = {};
  const questions: { env: "bbox" | "breakablebbox"; startToken: TexToken; depth: number; context: HeadingContext; diagnostics: TexDiagnostic[] }[] = [];
  const assetEvents: AssetReference[] = [];

  const spanForToken = (t: TexToken) => index.span(sourceFile, t.start.offset, t.end.offset);
  const headingOrder = ["questiongroup", "part", "chapter", "section", "subsection"] as const;

  for (const token of tokens) {
    if (token.type === "command" && token.name && HEADINGS.has(token.name) && token.args?.[0] !== undefined) {
      const command = token.name as HeadingNode["command"];
      const node: HeadingNode = { type: "heading", command, title: token.args[0].trim(), source: spanForToken(token) };
      nodes.push(node);
      (headingContext as any)[command] = { title: node.title, source: node.source };
      const level = headingOrder.indexOf(command);
      for (let j = level + 1; j < headingOrder.length; j++) delete (headingContext as any)[headingOrder[j]];
    }

    if (token.type === "command" && (token.name === "input" || token.name === "include") && token.args?.[0]) {
      nodes.push({ type: "input", command: token.name, path: token.args[0].trim(), source: spanForToken(token) });
    }

    if (token.type === "command" && token.name && ASSET_COMMANDS[token.name] && token.args) {
      for (const idx of ASSET_COMMANDS[token.name]) {
        const p = token.args[idx];
        if (p) assetEvents.push({ command: token.name, path: p.trim(), source: spanForToken(token) });
      }
    }

    if (token.type === "begin_env" && token.name) {
      environmentStack.push({ name: token.name, token });
      if (token.name === "bbox" || token.name === "breakablebbox") {
        questions.push({ env: token.name, startToken: token, depth: environmentStack.length, context: cloneContext(headingContext), diagnostics: [] });
      }
      continue;
    }

    if (token.type === "end_env" && token.name) {
      if (environmentStack.length === 0) {
        diagnostics.push({ severity: "error", code: "ENVIRONMENT_UNEXPECTED_END", message: `Unexpected \\end{${token.name}}`, source: spanForToken(token), recoverable: true });
        continue;
      }
      const top = environmentStack[environmentStack.length - 1];
      if (top.name !== token.name) {
        diagnostics.push({ severity: "error", code: "ENVIRONMENT_MISMATCH", message: `Expected \\end{${top.name}} but found \\end{${token.name}}`, source: spanForToken(token), recoverable: true });
        const matchIndex = environmentStack.map(x => x.name).lastIndexOf(token.name);
        if (matchIndex >= 0) environmentStack.splice(matchIndex);
        continue;
      }

      const closingDepth = environmentStack.length;
      environmentStack.pop();
      if ((token.name === "bbox" || token.name === "breakablebbox") && questions.length) {
        const qIndex = [...questions].map(q => q.env).lastIndexOf(token.name as any);
        if (qIndex >= 0) {
          const q = questions[qIndex];
          if (q.depth === closingDepth) {
            questions.splice(qIndex, 1);
            const start = q.startToken.start.offset;
            const end = token.end.offset;
            const qSpan = index.span(sourceFile, start, end);
            const assets = assetEvents.filter(a => a.source.startOffset >= start && a.source.endOffset <= end);
            nodes.push({ type: "question", environment: q.env, rawTex: source.slice(start, end), source: qSpan, headingContext: q.context, assets, diagnostics: q.diagnostics });
          }
        }
      }
    }
  }

  for (const q of questions) {
    const d: TexDiagnostic = {
      severity: "error",
      code: "BBOX_UNCLOSED",
      message: `Unclosed ${q.env} environment`,
      source: index.span(sourceFile, q.startToken.start.offset, q.startToken.end.offset),
      recoverable: true
    };
    diagnostics.push(d);
  }
  for (const env of environmentStack) {
    if (env.name !== "bbox" && env.name !== "breakablebbox") diagnostics.push({
      severity: "warning", code: "ENVIRONMENT_UNCLOSED", message: `Unclosed ${env.name} environment`, source: spanForToken(env.token), recoverable: true
    });
  }

  nodes.sort((a, b) => a.source.startOffset - b.source.startOffset);
  return { sourceFile, nodes, tokens, diagnostics };
}
