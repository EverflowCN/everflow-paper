import { PaperSnapshot, QuestionContent, PaperSectionType } from "../../domain/src";

export interface DocumentRootNode { type: "root"; id: string; children: DocumentNode[]; }
export interface HeadingDocumentNode { type: "heading"; id: string; sectionId: string; headingType: PaperSectionType; title: string; level: number; }
export interface QuestionDocumentNode {
  type: "question";
  id: string;
  paperItemId: string;
  questionId: string;
  questionRevisionId: string;
  displayNumber: number;
  score?: number;
  answerSpace?: { mode: "auto" | "none" | "fixed"; heightCm?: number };
  content: QuestionContent;
}
export interface RawTexDocumentNode { type: "raw_tex"; id: string; tex: string; }
export interface PageBreakNode { type: "page_break"; id: string; }
export type DocumentNode = HeadingDocumentNode | QuestionDocumentNode | RawTexDocumentNode | PageBreakNode;
export interface DocumentAST { root: DocumentRootNode; paperId: string; paperRevision: number; title: string; mode: string; }

export function buildDocumentAst(snapshot: PaperSnapshot): DocumentAST {
  const children: DocumentNode[] = [];
  const sections = [...snapshot.sections].sort((a, b) => a.order - b.order);
  let displayNumber = 1;
  const depthOf = (sectionId: string): number => {
    const map = new Map(sections.map(s => [s.id, s]));
    let depth = 0, cur = map.get(sectionId);
    while (cur?.parentId && map.has(cur.parentId)) { depth++; cur = map.get(cur.parentId); }
    return depth;
  };
  for (const section of sections) {
    children.push({ type: "heading", id: `heading:${section.id}`, sectionId: section.id, headingType: section.type, title: section.title, level: depthOf(section.id) });
    const items = snapshot.items.filter(i => i.sectionId === section.id && !i.override?.hidden).sort((a, b) => a.order - b.order);
    for (const item of items) {
      const rev = snapshot.revisions[item.questionRevisionId];
      if (!rev) throw new Error(`Missing QuestionRevision ${item.questionRevisionId}`);
      children.push({
        type: "question",
        id: `paper-item:${item.id}`,
        paperItemId: item.id,
        questionId: item.questionId,
        questionRevisionId: item.questionRevisionId,
        displayNumber: displayNumber++,
        score: item.score,
        answerSpace: item.override?.answerSpace,
        content: item.override?.stemTex && rev.content.mode === "structured"
          ? { ...rev.content, stemTex: item.override.stemTex }
          : rev.content
      });
    }
  }
  return { root: { type: "root", id: `paper:${snapshot.paper.id}`, children }, paperId: snapshot.paper.id, paperRevision: snapshot.paper.revision, title: snapshot.paper.title, mode: snapshot.paper.mode };
}
