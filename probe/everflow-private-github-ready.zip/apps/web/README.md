# P6–P8 IDE

当前仓库提供一个**零依赖、可立即运行的三栏 IDE 前端**，由 `apps/api` 直接托管到 `/ide/`。它用于先验证完整交互链：

- 左侧：试卷 / 大纲 / 题库 / 文件；
- 中间：题目 / 源码 / 属性 / 差异；
- 右侧：真实 XeLaTeX PDF 页面预览、编译日志；
- SourceMap：Question → `generated-web-paper.tex` 行号；
- SyncTeX forward：源码/题目 → PDF；
- SyncTeX reverse：双击 PDF → 源码行 → Question；
- source revision / PDF revision 分离，编译失败保留上一版 PDF；
- 650ms 自动保存 + 自动编译；
- Managed Source 只开放 `questions/generated-web-paper.tex` 编辑，其它模板文件只读。

## 为什么这版没有把 Next.js / Monaco / PDF.js 作为强依赖

P6–P8 的领域接口已经按可替换 Surface 设计。本执行环境的 npm registry 不提供 `next` 等包，因此本次先用原生浏览器控件 + 服务端 PDF raster surface 完整打通真实交互链，避免交付一个无法构建的空壳。生产版可以把：

- `textarea` → Monaco Editor；
- raster PDF surface → PDF.js；
- 静态 shell → Next.js App Router；

替换掉，而后端 API、SourceMap、SyncTeX、revision 契约无需改变。
