(()=>{
  const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let currentMe=null;
  const can=p=>!!currentMe?.permissions?.includes(p);

  async function api(u,o={}){
    const r=await fetch(u,{headers:{'content-type':'application/json',...(o.headers||{})},credentials:'same-origin',...o});
    const d=(r.headers.get('content-type')||'').includes('json')?await r.json():await r.text();
    if(!r.ok)throw Object.assign(new Error(d?.error||String(r.status)),{status:r.status,data:d});
    return d;
  }
  async function safeApi(u,fallback){try{return await api(u)}catch(e){if(e.status===403)return fallback;throw e}}
  function permissionUI(){
    $$('[data-permission]').forEach(el=>{const p=el.dataset.permission;el.hidden=!can(p)});
    $$('[data-requires]').forEach(el=>{const p=el.dataset.requires;const ok=can(p);el.disabled=!ok;el.title=ok?'':`需要权限：${p}`});
  }
  async function login(){
    try{
      await api('/api/admin/auth/login',{method:'POST',body:JSON.stringify({email:$('#email').value,password:$('#password').value,gateSecret:$('#gateSecret').value,totpCode:$('#totpCode')?.value||''})});
      $('#loginError').textContent=''; await load();
    }catch(e){$('#loginError').textContent=e.message}
  }
  async function logout(){
    await api('/api/admin/auth/logout',{method:'POST',body:'{}'}).catch(()=>{});
    currentMe=null; $('#console').hidden=true; $('#opsLogin').hidden=false; $('#refresh').hidden=true; $('#logout').hidden=true;
  }
  async function patchUser(id,patch){
    if(!can('users.write'))return alert('当前 Staff 角色没有 users.write 权限');
    const reason=prompt('请输入操作原因（会写入审计日志）'); if(!reason)return;
    await api(`/api/admin/users/${encodeURIComponent(id)}`,{method:'PATCH',body:JSON.stringify({...patch,reason})}); await load();
  }
  function renderStats(s={}){
    const rows=[['用户',s.users??'—'],['Pro',s.proUsers??'—'],['题库',s.banks??'—'],['试卷',s.papers??'—'],['工程',s.projects??'—'],['今日编译',s.compilesToday??'—'],['待处理 Case',s.openCases??'—']];
    $('#stats').innerHTML=rows.map(([a,b])=>`<div class="stat"><small>${a}</small><b>${b}</b></div>`).join('');
  }
  function renderUsers(users=[]){
    const allowWrite=can('users.write'),allowRevoke=can('sessions.revoke');
    $('#users').innerHTML=users.map(u=>`<tr><td class="user-title"><b>${esc(u.displayName)}</b><span>${esc(u.email)}</span></td><td><span class="pill ${u.role==='admin'?'admin':''}">${esc(u.role==='admin'?(u.opsRole||'superadmin'):'user')}</span></td><td><span class="pill ${u.entitlementPlan||u.plan}">${esc(u.entitlementPlan||u.plan)}</span></td><td><span class="pill ${u.accountStatus!=='normal'?'off':''}">${esc(u.accountStatus||'normal')}</span></td><td>${u.role==='admin'?`<span class="badge ${u.opsMfaEnabled?'ok':'warn'}">${u.opsMfaEnabled?'TOTP ON':'TOTP OFF'}</span>`:'—'}</td><td>${new Date(u.createdAt).toLocaleString()}</td><td><div class="row-actions">${allowWrite?`<select data-plan="${u.id}"><option value="free" ${u.plan==='free'?'selected':''}>Free</option><option value="pro" ${u.plan==='pro'?'selected':''}>Pro</option></select>${u.role==='admin'?`<select data-opsrole="${u.id}">${['support','moderator','billing','ops','security','superadmin'].map(x=>`<option ${u.opsRole===x?'selected':''}>${x}</option>`).join('')}</select>`:''}<select data-risk="${u.id}">${['normal','watch','restricted','suspended','banned'].map(x=>`<option ${u.accountStatus===x?'selected':''}>${x}</option>`).join('')}</select>`:''}${allowRevoke?`<button data-revoke="${u.id}">踢下线</button>`:''}${!allowWrite&&!allowRevoke?'<span class="muted">只读</span>':''}</div></td></tr>`).join('')||'<tr><td colspan="7" class="empty">暂无用户</td></tr>';
    $$('[data-plan]').forEach(x=>x.onchange=()=>patchUser(x.dataset.plan,{plan:x.value}));
    $$('[data-opsrole]').forEach(x=>x.onchange=()=>patchUser(x.dataset.opsrole,{opsRole:x.value}));
    $$('[data-risk]').forEach(x=>x.onchange=()=>patchUser(x.dataset.risk,{accountStatus:x.value}));
    $$('[data-revoke]').forEach(x=>x.onclick=async()=>{if(!can('sessions.revoke'))return;const reason=prompt('强制退出原因');if(!reason)return;await api(`/api/admin/users/${x.dataset.revoke}/sessions/revoke`,{method:'POST',body:JSON.stringify({reason})});alert('已撤销会话')});
  }
  function renderAudit(rows=[]){$('#audit').innerHTML=rows.map(a=>`<div class="audit-row"><span>${new Date(a.createdAt).toLocaleString()}</span><b>${esc(a.action)}</b><span>${esc(a.targetType||'')} ${esc(a.targetId||'')}</span><span>${esc(a.actorUserId||'system')}</span></div>`).join('')||'<div class="empty">暂无日志</div>'}
  function renderFlags(flags=[]){$('#flags').innerHTML=flags.map(f=>`<div class="audit-row"><b>${esc(f.key)}</b><span>${f.enabled?'ON':'OFF'} · ${f.rolloutPercentage}%</span><span>${esc((f.plans||[]).join(',')||'all plans')}</span><span>${new Date(f.updatedAt).toLocaleString()}</span></div>`).join('')||'<div class="empty">暂无 Feature Flag</div>'}
  function renderCases(rows=[]){$('#cases').innerHTML=rows.map(c=>`<div class="audit-row"><span>${esc(c.severity)}</span><b>${esc(c.type)}</b><span>${esc(c.status)} · ${esc(c.userId||'system')}</span><span>${new Date(c.updatedAt).toLocaleString()}</span></div>`).join('')||'<div class="empty">暂无待处理 Case</div>'}
  function rewardLabel(r){if(!r)return'—';if(r.kind==='pro_days')return`Pro ${r.amount}天`;if(r.kind==='compile_credits')return`编译 +${r.amount}`;if(r.kind==='import_page_credits')return`导入页 +${r.amount}`;return r.kind||'reward'}
  function renderCampaigns(rows=[]){
    $('#campaigns').innerHTML=rows.map(c=>`<div class="audit-row"><b>${esc(c.publicId)} · ${esc(c.name)}</b><span>${esc(rewardLabel(c.reward))}</span><span>${c.codes||0} 个码 · 已兑 ${c.used||0}</span>${can('redeem.write')?`<button data-gencodes="${c.id}">生成码</button>`:'<span class="muted">只读</span>'}</div>`).join('')||'<div class="empty">暂无兑换活动</div>';
    $$('[data-gencodes]').forEach(b=>b.onclick=async()=>{const count=Math.max(1,Math.min(1000,Number(prompt('生成多少个兑换码？','10')||0)));if(!count)return;const maxUses=Math.max(1,Number(prompt('每个码最多使用次数','1')||1));const reason=prompt('生成原因（审计）')||'';if(!reason)return;const out=await api(`/api/admin/redeem-campaigns/${b.dataset.gencodes}/codes`,{method:'POST',body:JSON.stringify({count,maxUses,reason})});const text=(out.plaintextCodes||[]).join('\n'),blob=new Blob([text],{type:'text/plain;charset=utf-8'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`Everflow-redeem-${Date.now()}.txt`;a.click();URL.revokeObjectURL(a.href);alert(`已生成 ${out.plaintextCodes.length} 个兑换码。完整码只在本次返回，并已下载 TXT。`);await load()});
  }
  function renderRedemptions(rows=[]){$('#redemptions').innerHTML=rows.slice(0,50).map(r=>`<div class="audit-row"><b>${esc(r.publicId)}</b><span>${esc(rewardLabel(r.reward))}</span><span>${esc(r.status)} · ${esc(r.userId)}</span><span>${new Date(r.claimedAt).toLocaleString()}</span></div>`).join('')||'<div class="empty">暂无兑换记录</div>'}
  function renderOrders(rows=[]){
    const labels={created:'已创建',pending:'待支付',paid:'已支付',failed:'失败',cancelled:'已取消',refunded:'已退款'};
    $('#orders').innerHTML=rows.slice(0,60).map(o=>`<div class="order-row"><div><b>${esc(o.publicId)}</b><span>${esc(o.provider)} · ${esc(o.plan).toUpperCase()} ${esc(o.period)}</span></div><div><span class="badge ${o.status==='paid'?'ok':o.status==='failed'?'warn':'blue'}">${esc(labels[o.status]||o.status)}</span><b>¥${(Number(o.amountCents||0)/100).toFixed(2)}</b></div><div><span>${esc(o.userId)}</span><small>${new Date(o.updatedAt).toLocaleString()}</small></div></div>`).join('')||'<div class="empty">暂无支付订单</div>';
  }
  function campaignDialog(){if(!can('redeem.write'))return;const name=prompt('活动名称','Pro 30天活动');if(!name)return;const type=prompt('奖励类型：pro_days / compile_credits / import_page_credits','pro_days')||'pro_days';const amount=Math.max(1,Number(prompt('奖励数量','30')||0));const reason=prompt('创建原因（审计）')||'';if(!reason)return;return api('/api/admin/redeem-campaigns',{method:'POST',body:JSON.stringify({name,reward:{kind:type,amount},perUserLimit:1,reason})}).then(load)}
  async function subscriptionSimulator(){if(!can('billing.write'))return;const email=prompt('输入测试用户邮箱');if(!email)return;const users=(await api('/api/admin/users')).users||[],u=users.find(x=>x.email===email);if(!u)return alert('未找到用户');const action=prompt('动作：grant_pro / renew_success / renew_failure / expire / refund / cancel_at_period_end / reactivate','grant_pro');if(!action)return;const days=Number(prompt('天数（部分动作使用）','30')||30),reason=prompt('模拟原因（审计）')||'';if(!reason)return;const out=await api('/api/admin/subscription-simulator',{method:'POST',body:JSON.stringify({userId:u.id,action,days,reason})});alert(`${u.email}\n${out.subscription.status}\n当前权益：${out.entitlements.plan.toUpperCase()}\n到期：${out.subscription.currentPeriodEnd||'—'}`);await load()}
  function renderJobs(data={}){const runtime=data.runtime||{},rows=data.jobs||[];$('#jobRuntime').innerHTML=`<span class="badge">${esc(String(runtime.driver||'memory').toUpperCase())}</span> <span class="badge">${runtime.redisConfigured?'Redis configured':'Memory / Dev'}</span>`;$('#jobs').innerHTML=rows.length?rows.slice(0,18).map(j=>`<div class="job-row"><div><b>${esc(j.publicId)}</b><span>${esc(j.kind)} · ${esc(j.queueName)} · ${j.progress||0}% · attempt ${j.attempts}/${j.maxAttempts}</span></div><div><span class="badge ${j.status==='success'?'ok':j.status==='failed'?'warn':'blue'}">${esc(j.status)}</span><small>${j.projectRevision?`source v${j.projectRevision}`:'—'}</small></div></div>`).join(''):'<div class="empty">暂无后台任务</div>'}
  function renderHealth(h={},me={}){const runtime=h.runtime?.checks||[],runtimeText=runtime.map(x=>`${x.ok?'✓':'✕'} ${x.key} ${x.latencyMs||0}ms`).join(' · ')||'Not probed';const sec=$('#securityOverview');if(sec)sec.innerHTML=[['OPS Role',me.opsRole||'—'],['MFA',me.mfaEnabled?'TOTP Enabled':'Not Enabled'],['Queue',String(h.queue?.driver||'memory').toUpperCase()],['Object Store',String(h.objectStore?.driver||'local').toUpperCase()],['Mail',String(h.mail?.provider||'dev').toUpperCase()]].map(([a,b])=>`<div class="security-card"><small>${esc(a)}</small><b>${esc(b)}</b></div>`).join('');$('#systemHealth').innerHTML=`<div class="audit-row"><b>Queue Pressure</b><span>${esc(h.signals?.queuePressure||'normal')}</span><span>Active ${h.signals?.activeJobs||0} · Failed 1h ${h.signals?.failedJobsLastHour||0}</span><span>${h.time?new Date(h.time).toLocaleString():'—'}</span></div><div class="audit-row"><b>Production Readiness</b><span>${h.readiness?.ok?'READY':'BLOCKED'}</span><span>${h.readiness?.blocking?.length?'Blocking: '+h.readiness.blocking.join(', '):'Required checks passed'}</span><span>${esc(h.readiness?.mode||'development')}</span></div><div class="audit-row"><b>Runtime Connectivity</b><span>${h.runtime?.ok?'REACHABLE':'CHECK'}</span><span>${esc(runtimeText)}</span><span>${h.runtime?.at?new Date(h.runtime.at).toLocaleTimeString():'—'}</span></div><div class="audit-row"><b>Billing</b><span>${esc(h.billing?.provider||'test')}</span><span>WeChat ${h.billing?.wechatVerifyConfigured?'验签✓':h.billing?.wechatConfigured?'配置':'—'} · Alipay ${h.billing?.alipayVerifyConfigured?'验签✓':h.billing?.alipayConfigured?'配置':'—'} · Stripe ${h.billing?.stripeVerifyConfigured?'验签✓':h.billing?.stripeConfigured?'配置':'—'}</span><span>Webhook idempotency enabled</span></div><div class="audit-row"><b>Billing Scheduler</b><span>${h.scheduler?.billingReconcile?.enabled?'ENABLED':'OFF'}</span><span>${h.scheduler?.billingReconcile?.enabled?`${Math.round((h.scheduler.billingReconcile.intervalMs||0)/1000)}s · persistent lease`:'Manual / Job API only'}</span><span>multi-instance safe</span></div>`}

  function renderBackupDrills(data={},verification={}){const plan=data.plan||{},rows=data.drills||[],manifests=verification.manifests||[],reports=verification.verifications||[];$('#backupDrills').innerHTML=`<div class="audit-row"><b>Restore Drill Plan</b><span>${plan.automaticRestoreEnabled?'自动命令已配置':'人工/隔离环境执行'}</span><span>${(plan.steps||[]).length} 个检查步骤</span><span>生产库禁止直接覆盖</span></div><div class="audit-row"><b>Backup Manifest</b><span>${manifests.length?esc(manifests[0].backupId):'尚未登记'}</span><span>${manifests.length?`${manifests[0].files?.length||0} files · ${esc(manifests[0].appVersion||'')}`:'backup.sh 会生成 manifest.json + SHA256'}</span><span>${manifests.length?new Date(manifests[0].createdAt).toLocaleString():'—'}</span></div><div class="audit-row"><b>Restore Verification</b><span>${reports.length?esc(reports[0].status):'尚未验证'}</span><span>${reports.length?`Manifest ${reports[0].manifestVerified?'✓':'—'} · DB ${reports[0].databaseVerified?'✓':'—'} · Objects ${reports[0].objectsVerified?'✓':'—'} · Smoke ${reports[0].smokeTestsPassed?'✓':'—'}`:'隔离环境恢复后记录验证报告'}</span><span>${reports.length?new Date(reports[0].createdAt).toLocaleString():'—'}</span></div>`+(rows.map(d=>`<div class="audit-row"><b>${esc(d.id)}</b><span>${esc(d.status)} · DB ${d.databaseRestored?'✓':'—'} · Objects ${d.objectsVerified?'✓':'—'} · Smoke ${d.smokeTestsPassed?'✓':'—'}</span><span>RPO ${d.rpoMinutes||0}m · RTO ${d.rtoMinutes||0}m</span><span>${new Date(d.createdAt).toLocaleString()}</span></div>`).join('')||'<div class="empty">尚未记录 Restore Drill</div>')}
  async function recordDrill(){if(!can('security.manage'))return;const status=prompt('演练结果：passed / failed / planned','passed')||'planned',notes=prompt('演练说明（会进入审计）','隔离环境恢复演练')||'';if(!notes)return;const databaseRestored=confirm('数据库已在隔离环境恢复并验证？'),objectsVerified=confirm('对象存储抽样验证通过？'),smokeTestsPassed=confirm('应用 Smoke Test 通过？');const rpoMinutes=Number(prompt('RPO（分钟）','5')||0),rtoMinutes=Number(prompt('RTO（分钟）','20')||0);await api('/api/admin/backup-drills',{method:'POST',body:JSON.stringify({status,notes,reason:notes,databaseRestored,objectsVerified,smokeTestsPassed,rpoMinutes,rtoMinutes})});await load()}
  async function enrollMfa(){if(!can('mfa.manage'))return;try{const e=await api('/api/admin/mfa/enroll',{method:'POST',body:'{}'});alert(`MFA Secret（仅本次显示）：\n${e.secret}\n\n请加入 Authenticator，然后输入当前 6 位验证码。`);const code=prompt('输入 Authenticator 当前 6 位验证码');if(!code)return;await api('/api/admin/mfa/confirm',{method:'POST',body:JSON.stringify({code})});alert('TOTP MFA 已启用。下一次 Operations 登录必须输入验证码。');await load()}catch(e){alert(`MFA 配置失败：${e.message}`)}}

  async function load(){
    try{
      const me=await api('/api/admin/auth/me'); currentMe=me; permissionUI();
      $('#opsLogin').hidden=true; $('#console').hidden=false; $('#refresh').hidden=false; $('#logout').hidden=false;
      $('#identity').textContent=`${me.user.displayName} · ${me.opsRole||'staff'} · ${me.permissions.length} permissions · 独立 OPS Session`;
      const calls={};
      if(can('dashboard.read'))calls.stats=safeApi('/api/admin/stats',null);
      if(can('users.read'))calls.users=safeApi('/api/admin/users',{users:[]});
      if(can('audit.read')){calls.audit=safeApi('/api/admin/audit?limit=100',{audit:[]});calls.backup=safeApi('/api/admin/backup-drills',{plan:{steps:[]},drills:[]});calls.backupVerify=safeApi('/api/admin/backup-verification',{manifests:[],verifications:[]})}
      if(can('flags.read'))calls.flags=safeApi('/api/admin/feature-flags',{flags:[]});
      if(can('risk.read'))calls.cases=safeApi('/api/admin/risk-cases',{cases:[]});
      if(can('billing.read')){calls.campaigns=safeApi('/api/admin/redeem-campaigns',{campaigns:[]});calls.redemptions=safeApi('/api/admin/redemptions',{redemptions:[]});calls.orders=safeApi('/api/admin/orders',{orders:[]})}
      if(can('jobs.read'))calls.jobs=safeApi('/api/admin/jobs',{jobs:[],runtime:{}});
      if(can('dashboard.read'))calls.health=safeApi('/api/admin/system-health',{});
      const entries=Object.entries(calls),values=await Promise.all(entries.map(x=>x[1])),out=Object.fromEntries(entries.map((e,i)=>[e[0],values[i]]));
      if(out.stats){$('#persist').textContent=`Persistence · ${String(out.stats.persistence||'unknown').toUpperCase()}`;renderStats(out.stats.stats)}
      if(out.users)renderUsers(out.users.users); if(out.audit)renderAudit(out.audit.audit); if(out.backup)renderBackupDrills(out.backup,out.backupVerify||{}); if(out.flags)renderFlags(out.flags.flags); if(out.cases)renderCases(out.cases.cases); if(out.campaigns)renderCampaigns(out.campaigns.campaigns); if(out.redemptions)renderRedemptions(out.redemptions.redemptions); if(out.orders)renderOrders(out.orders.orders); if(out.jobs)renderJobs(out.jobs); if(out.health)renderHealth(out.health,me);
      $('#permissionSummary').innerHTML=me.permissions.map(p=>`<span class="permission-chip">${esc(p)}</span>`).join('')||'<span class="muted">无额外权限</span>';
    }catch(e){
      if(e.status===403||e.status===401){currentMe=null;$('#console').hidden=true;$('#opsLogin').hidden=false;$('#refresh').hidden=true;$('#logout').hidden=true}else $('#loginError').textContent=e.message;
    }
  }

  async function recordManifest(){if(!can('security.manage'))return;const backupId=prompt('备份编号','BKP-'+new Date().toISOString().slice(0,10).replace(/-/g,''));if(!backupId)return;const notes=prompt('说明','backup.sh manifest imported')||'';await api('/api/admin/backup-verification/manifest',{method:'POST',body:JSON.stringify({backupId,appVersion:'1.0.0-rc.6',database:'postgres',objectStore:'s3/minio',files:[],notes})});await load()}
  async function recordVerification(){if(!can('security.manage'))return;const backupId=prompt('被验证的备份编号');if(!backupId)return;const status=prompt('passed / failed / partial','passed')||'partial',notes=prompt('验证说明','隔离环境恢复验证')||'';await api('/api/admin/backup-verification/report',{method:'POST',body:JSON.stringify({backupId,status,manifestVerified:confirm('Manifest / SHA256 已验证？'),databaseVerified:confirm('数据库恢复验证通过？'),objectsVerified:confirm('对象存储验证通过？'),smokeTestsPassed:confirm('应用 Smoke Test 通过？'),notes})});await load()}
  $('#login').onclick=login; $('#recordManifest').onclick=recordManifest; $('#recordVerification').onclick=recordVerification; $('#recordDrill').onclick=recordDrill; $('#logout').onclick=logout; $('#refresh').onclick=load; $('#healthRefresh').onclick=load; $('#mfaEnroll').onclick=enrollMfa;
  $('#addFlag').onclick=async()=>{if(!can('flags.write'))return;const key=prompt('Flag key，例如 vector.v2');if(!key)return;const enabled=confirm('立即启用？'),reason=prompt('变更原因')||'';if(!reason)return;await api('/api/admin/feature-flags',{method:'PUT',body:JSON.stringify({key,enabled,rolloutPercentage:100,reason})});await load()};
  $('#newCampaign').onclick=campaignDialog; $('#subscriptionSim').onclick=subscriptionSimulator;
  $('#addCase').onclick=async()=>{if(!can('risk.write'))return;const userId=prompt('用户ID（系统Case可留空）')||'',type=prompt('Case 类型','resource_abuse')||'manual_review';await api('/api/admin/risk-cases',{method:'POST',body:JSON.stringify({userId:userId||undefined,type,severity:'medium',evidence:{note:'manual case'}})});await load()};
  load();
})();
