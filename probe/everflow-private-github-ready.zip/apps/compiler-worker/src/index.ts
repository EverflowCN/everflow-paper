const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const childProcess = require("child_process");

export type CompileStatus = "success" | "failed" | "timeout" | "cancelled" | "stale";
export type SandboxMode = "host" | "docker";
export interface CompileRequest {
  projectId: string;
  projectRevision: number;
  workspace: string;
  rootFile: string;
  compiler: "xelatex" | "pdflatex" | "lualatex";
  compileMode: "preview" | "export";
  timeoutMs: number;
  texliveImage?: string;
  sandboxMode?:SandboxMode;
  memoryMb?:number;
  cpus?:number;
  pidsLimit?:number;
  maxPdfMb?:number;
}
export interface CompileResult {
  jobId: string;
  projectId: string;
  projectRevision: number;
  status: CompileStatus;
  outputs: { pdf?: string; log: string; synctex?: string };
  durationMs: number;
  exitCode?: number;
  sandbox?:{mode:SandboxMode;network:"none"|"host";image?:string;runtime?:"docker"|"podman"};
}

export function hashProjectFiles(workspace: string): string {
  const entries: string[] = [];
  const walk = (dir: string) => {
    for (const name of fs.readdirSync(dir).sort()) {
      const full = path.join(dir, name);
      const rel = path.relative(workspace, full).replace(/\\/g, "/");
      if ([".git", ".runtime"].includes(name)) continue;
      const stat = fs.statSync(full);
      if (stat.isDirectory()) walk(full);
      else if (!/\.(aux|log|out|toc|synctex\.gz|fls|fdb_latexmk|xdv|pdf)$/.test(name)) {
        const h = crypto.createHash("sha256").update(fs.readFileSync(full)).digest("hex");
        entries.push(`${rel}:${h}`);
      }
    }
  };
  walk(workspace);
  return crypto.createHash("sha256").update(entries.join("\n")).digest("hex");
}
function validateRequest(req:CompileRequest){
  const ws=path.resolve(req.workspace),root=String(req.rootFile||"").replace(/\\/g,"/");
  if(path.isAbsolute(root)||root.split("/").includes("..")||!root.toLowerCase().endsWith(".tex"))throw new Error("COMPILE_ROOT_INVALID");
  const full=path.resolve(ws,root);if(!full.startsWith(ws+path.sep)||!fs.existsSync(full))throw new Error("COMPILE_ROOT_NOT_FOUND");
}
export function latexmkArgs(req:CompileRequest){
  const engineFlag: any = { xelatex: "-xelatex", pdflatex: "-pdf", lualatex: "-lualatex" };
  const args = [engineFlag[req.compiler], "-synctex=1", "-no-shell-escape", "-interaction=nonstopmode", "-file-line-error"];
  if (req.compileMode === "export") args.push("-halt-on-error");args.push(req.rootFile);return args;
}
export function dockerSandboxArgs(req:CompileRequest){
  const image=String(req.texliveImage||process.env.EVERFLOW_TEXLIVE_IMAGE||"").trim();if(!image)throw new Error("TEXLIVE_IMAGE_REQUIRED");
  const ws=path.resolve(req.workspace),memory=Math.max(128,Math.min(4096,Number(req.memoryMb||process.env.EVERFLOW_COMPILE_MEMORY_MB||768))),cpus=Math.max(.25,Math.min(4,Number(req.cpus||process.env.EVERFLOW_COMPILE_CPUS||1))),pids=Math.max(32,Math.min(512,Number(req.pidsLimit||process.env.EVERFLOW_COMPILE_PIDS||128)));
  return["run","--rm","--network","none","--cap-drop","ALL","--security-opt","no-new-privileges:true","--pids-limit",String(pids),"--memory",`${memory}m`,"--cpus",String(cpus),"--read-only","--tmpfs","/tmp:rw,noexec,nosuid,size=128m","-e","HOME=/tmp","-v",`${ws}:/work:rw`,"-w","/work",image,"latexmk",...latexmkArgs(req)];
}
function resolveMode(req:CompileRequest):SandboxMode{
  if(req.sandboxMode)return req.sandboxMode;const configured=String(process.env.EVERFLOW_COMPILE_SANDBOX||"").toLowerCase();if(configured==="docker")return"docker";if(configured==="host")return"host";if(process.env.NODE_ENV==="production"||process.env.EVERFLOW_REQUIRE_SANDBOX==="1")throw new Error("COMPILE_SANDBOX_REQUIRED");return"host";
}
export function compileProject(req: CompileRequest): CompileResult {
  validateRequest(req);const started = Date.now(),jobId = `job_${req.projectRevision}_${started}`,mode=resolveMode(req),args=latexmkArgs(req);
  let status: CompileStatus = "failed",stdout = "", stderr = "", exitCode: number | undefined;
  try {
    const runtime=(String(process.env.EVERFLOW_CONTAINER_RUNTIME||"docker").toLowerCase()==="podman"?"podman":"docker") as "docker"|"podman",cmd=mode==="docker"?runtime:"latexmk",cmdArgs=mode==="docker"?dockerSandboxArgs(req):args;
    const res = childProcess.spawnSync(cmd, cmdArgs, { cwd: req.workspace, encoding: "utf8", timeout: Math.max(1000,Math.min(120000,req.timeoutMs)), maxBuffer: 20 * 1024 * 1024,env:mode==="host"?{...process.env,openout_any:"p",openin_any:"a"}:process.env });
    stdout = res.stdout || ""; stderr = res.stderr || ""; exitCode = res.status ?? undefined;
    if (res.error && String(res.error.message || res.error).includes("ETIMEDOUT")) status = "timeout";
    else status = res.status === 0 ? "success" : "failed";
  } catch (err: any) {stderr += `\n${err?.stack || String(err)}`;status = String(err?.message || err).includes("ETIMEDOUT") ? "timeout" : "failed";}
  const base = req.rootFile.replace(/\.tex$/i, ""),pdf = path.join(req.workspace, `${base}.pdf`),synctex = path.join(req.workspace, `${base}.synctex.gz`),logPath = path.join(req.workspace, `${base}.log`);
  let log = fs.existsSync(logPath) ? fs.readFileSync(logPath, "utf8") : `${stdout}\n${stderr}`;
  const maxPdfBytes=Math.max(1,Math.min(500,Number(req.maxPdfMb||process.env.EVERFLOW_COMPILE_MAX_PDF_MB||50)))*1024*1024;
  if(fs.existsSync(pdf)&&fs.statSync(pdf).size>maxPdfBytes){status="failed";log+=`\nEVERFLOW_SECURITY: PDF output exceeded ${Math.round(maxPdfBytes/1024/1024)} MB limit.`;try{fs.unlinkSync(pdf);}catch{}}
  return {jobId, projectId: req.projectId, projectRevision: req.projectRevision, status,outputs: { pdf: fs.existsSync(pdf) ? pdf : undefined, log, synctex: fs.existsSync(synctex) ? synctex : undefined },durationMs: Date.now() - started, exitCode,sandbox:{mode,network:mode==="docker"?"none":"host",image:mode==="docker"?String(req.texliveImage||process.env.EVERFLOW_TEXLIVE_IMAGE||""):undefined,runtime:mode==="docker"?(String(process.env.EVERFLOW_CONTAINER_RUNTIME||"docker").toLowerCase()==="podman"?"podman":"docker"):undefined}};
}

export class CompileCoordinator {
  private latestRequestedRevision = 0;
  request(revision: number): void { if (revision > this.latestRequestedRevision) this.latestRequestedRevision = revision; }
  accept(result: CompileResult): CompileResult {return result.projectRevision < this.latestRequestedRevision ? { ...result, status: "stale" } : result;}
}
