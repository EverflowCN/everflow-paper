import { createRepository } from "../../api/src/persistence";
import { createBullWorkers, jobDriver } from "../../../packages/job-queue/src";
import { executePersistedJob } from "./processor";
async function main(){if(jobDriver()!=="bullmq")throw new Error("STANDALONE_WORKER_REQUIRES_BULLMQ");const repo=await createRepository(process.cwd());const workers=createBullWorkers((id,owner)=>executePersistedJob(repo,id,owner));console.log(`Everflow worker online: ${workers.length} queues`);const stop=async()=>{await Promise.all(workers.map((w:any)=>w.close()));process.exit(0)};process.on("SIGTERM",stop);process.on("SIGINT",stop);}
main().catch(e=>{console.error(e);process.exitCode=1});
