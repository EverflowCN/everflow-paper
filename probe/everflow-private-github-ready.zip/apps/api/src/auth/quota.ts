import { Repository, UserRecord } from "../persistence";
import { EntitlementService } from "../membership/entitlements";
export class QuotaService{
  constructor(private readonly repo:Repository,private readonly entitlements=new EntitlementService(repo)){}
  async status(user:UserRecord){const day=new Date().toISOString().slice(0,10),usage=await this.repo.getCompileUsage(user.id,day),e=await this.entitlements.snapshot(user);const baseRemaining=Math.max(0,e.limits.dailyCompiles-usage.count);return{plan:e.plan,source:e.source,day,usage:{compiles:usage.count,totalDurationMs:usage.totalDurationMs},limits:e.limits,features:e.features,bonusCredits:e.bonusCredits,remaining:{compiles:baseRemaining+e.bonusCredits.compile,baseCompiles:baseRemaining,bonusCompiles:e.bonusCredits.compile}};}
  async assertCompileAllowed(user:UserRecord){if(user.accountStatus==="restricted")throw new Error("ACCOUNT_RESTRICTED");const s=await this.status(user);if(s.remaining.compiles<=0)throw new Error("COMPILE_QUOTA_EXCEEDED");return{...s,useBonus:s.remaining.baseCompiles<=0};}
  async recordCompile(user:UserRecord,durationMs:number,useBonus=false){if(useBonus){const used=await this.repo.consumeMembershipCredits(user.id,'compile',1,new Date().toISOString());if(used<1)throw new Error('COMPILE_CREDIT_EXHAUSTED');}return this.repo.incrementCompileUsage(user.id,new Date().toISOString().slice(0,10),durationMs);}
}
