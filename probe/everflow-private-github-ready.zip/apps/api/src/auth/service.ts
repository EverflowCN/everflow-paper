import { PlanId, Repository, SessionSurface, UserRecord } from "../persistence";
import { decryptTotpSecret, verifyTotp } from "../ops/totp";
import { sendSecurityNotice } from "../mail/provider";
const crypto=require("crypto");
function b64(b:any){return Buffer.from(b).toString("base64url");}
function hashToken(t:string){return crypto.createHash("sha256").update(t).digest("hex");}
function uuid(){return crypto.randomUUID();}
export function publicUser(u:UserRecord){return{id:u.id,email:u.email,displayName:u.displayName,role:u.role,plan:u.plan,accountStatus:u.accountStatus||"normal",disabled:u.disabled,emailVerifiedAt:u.emailVerifiedAt,createdAt:u.createdAt};}
export async function hashPassword(password:string):Promise<string>{if(password.length<8)throw new Error("PASSWORD_TOO_SHORT");const salt=crypto.randomBytes(16);const key=await new Promise<any>((resolve,reject)=>crypto.scrypt(password,salt,64,(e:any,k:any)=>e?reject(e):resolve(k)));return`scrypt$${b64(salt)}$${b64(key)}`;}
export async function verifyPassword(password:string,stored:string):Promise<boolean>{try{const [alg,salt64,key64]=stored.split("$");if(alg!=="scrypt")return false;const salt=Buffer.from(salt64,"base64url"),expected=Buffer.from(key64,"base64url");const key=await new Promise<any>((resolve,reject)=>crypto.scrypt(password,salt,expected.length,(e:any,k:any)=>e?reject(e):resolve(k)));return expected.length===key.length&&crypto.timingSafeEqual(expected,key);}catch{return false;}}
export class AuthService{
  constructor(private readonly repo:Repository,private readonly sessionDays=14){}
  async register(email:string,password:string,displayName?:string,role:"user"|"admin"="user",plan:PlanId="free"){
    email=String(email||"").trim().toLowerCase();if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email))throw new Error("EMAIL_INVALID");
    const passwordHash=await hashPassword(password);const u=await this.repo.createUser({id:uuid(),email,displayName:String(displayName||email.split("@")[0]).slice(0,60),passwordHash,role,plan,accountStatus:"normal",disabled:false});return u;
  }
  private async issueSession(u:UserRecord,surface:SessionSurface,days:number,meta:any={}){
    const token=b64(crypto.randomBytes(32)),now=new Date(),expires=new Date(now.getTime()+days*86400000);
    const ip=String(meta.ip||"").slice(0,80)||undefined,userAgent=String(meta.userAgent||"").slice(0,240)||undefined;
    const existing=surface==="app"?await this.repo.listSessionsForUser(u.id,"app"):[];
    const sameAgent=!!userAgent&&existing.some(x=>String(x.userAgent||"")===userAgent),sameIp=!!ip&&existing.some(x=>String(x.ip||"")===ip);
    const newDevice=surface==="app"&&existing.length>0&&!sameAgent;const reasons:string[]=[];let riskScore=0;
    if(newDevice){riskScore+=35;reasons.push("new_user_agent");}
    if(existing.length>0&&ip&&!sameIp){riskScore+=25;reasons.push("new_ip");}
    if(!userAgent){riskScore+=10;reasons.push("missing_user_agent");}
    riskScore=Math.min(100,riskScore);
    await this.repo.createSession({id:uuid(),userId:u.id,tokenHash:hashToken(token),surface,createdAt:now.toISOString(),expiresAt:expires.toISOString(),lastSeenAt:now.toISOString(),ip,userAgent,riskScore,riskReasons:reasons,newDevice});
    if(newDevice&&u.emailVerifiedAt){sendSecurityNotice(u.email,{ip,userAgent,riskScore,reasons}).catch(()=>{});}
    return{token,user:u,expiresAt:expires.toISOString(),security:{newDevice,riskScore,reasons}};
  }
  async loginPasskey(userId:string,meta:any={}){const u=await this.repo.getUser(userId);if(!u||u.disabled||["suspended","banned"].includes(u.accountStatus||"normal"))throw new Error("AUTH_INVALID_CREDENTIALS");return this.issueSession(u,"app",this.sessionDays,meta);}
  async login(email:string,password:string,meta:any={}){const u=await this.repo.findUserByEmail(String(email||"").trim().toLowerCase());if(!u||u.disabled||["suspended","banned"].includes(u.accountStatus||"normal")||!(await verifyPassword(password,u.passwordHash)))throw new Error("AUTH_INVALID_CREDENTIALS");return this.issueSession(u,"app",this.sessionDays,meta);}
  async loginOps(email:string,password:string,gateSecret?:string,totpCode?:string){const u=await this.repo.findUserByEmail(String(email||"").trim().toLowerCase());if(!u||u.role!=="admin"||u.disabled||["suspended","banned"].includes(u.accountStatus||"normal")||!(await verifyPassword(password,u.passwordHash)))throw new Error("AUTH_INVALID_CREDENTIALS");const required=String(process.env.EVERFLOW_ADMIN_GATE_SECRET||"");if(required&&String(gateSecret||"")!==required)throw new Error("ADMIN_STEP_UP_REQUIRED");if(u.opsMfaEnabled){if(!u.opsMfaSecretEncrypted)throw new Error("OPS_MFA_CONFIGURATION_INVALID");const secret=decryptTotpSecret(u.opsMfaSecretEncrypted);if(!verifyTotp(secret,String(totpCode||"")))throw new Error("OPS_MFA_REQUIRED");}return this.issueSession(u,"ops",Math.max(0.02,Number(process.env.EVERFLOW_ADMIN_SESSION_DAYS||0.125)));}
  async authenticate(token?:string,surface:SessionSurface="app"){if(!token)return undefined;const th=hashToken(token),s=await this.repo.getSessionByHash(th);if(!s||s.expiresAt<=new Date().toISOString()||(s.surface||"app")!==surface)return undefined;const now=new Date().toISOString();if(!s.lastSeenAt||Date.now()-new Date(s.lastSeenAt).getTime()>5*60*1000)await this.repo.touchSession(th,now);const u=await this.repo.getUser(s.userId);return u&&!u.disabled&&!["suspended","banned"].includes(u.accountStatus||"normal")?u:undefined;}
  async logout(token?:string){if(token)await this.repo.deleteSessionByHash(hashToken(token));}
}
export function tokenFromRequest(req:any):string|undefined{const auth=String(req.headers?.authorization||"");if(auth.toLowerCase().startsWith("bearer "))return auth.slice(7).trim();const cookies=String(req.headers?.cookie||"").split(/;\s*/);for(const c of cookies){const i=c.indexOf("=");if(i>0&&c.slice(0,i)==="zo_session")return decodeURIComponent(c.slice(i+1));}return undefined;}
export function opsTokenFromRequest(req:any):string|undefined{const auth=String(req.headers?.["x-everflow-ops-authorization"]||"");if(auth.toLowerCase().startsWith("bearer "))return auth.slice(7).trim();const cookies=String(req.headers?.cookie||"").split(/;\s*/);for(const c of cookies){const i=c.indexOf("=");if(i>0&&c.slice(0,i)==="ef_ops_session")return decodeURIComponent(c.slice(i+1));}return undefined;}
function secureCookie(){return process.env.NODE_ENV==="production"?"; Secure":"";}
export function sessionCookie(token:string,maxAgeSeconds:number){return`zo_session=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAgeSeconds}${secureCookie()}`;}
export function clearSessionCookie(){return`zo_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secureCookie()}`;}
export function opsSessionCookie(token:string,maxAgeSeconds:number){return`ef_ops_session=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAgeSeconds}${secureCookie()}`;}
export function clearOpsSessionCookie(){return`ef_ops_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0${secureCookie()}`;}
