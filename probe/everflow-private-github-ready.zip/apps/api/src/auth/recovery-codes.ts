const crypto=require('crypto');
const alphabet='23456789ABCDEFGHJKMNPQRSTUVWXYZ';
function pepper(){const p=String(process.env.EVERFLOW_RECOVERY_CODE_PEPPER||process.env.EVERFLOW_ACCOUNT_TOKEN_SECRET||'dev-recovery-pepper');if(process.env.NODE_ENV==='production'&&p.length<32)throw new Error('RECOVERY_CODE_PEPPER_REQUIRED');return p;}
function randomPart(n=12){let out='';const b=crypto.randomBytes(n);for(let i=0;i<n;i++)out+=alphabet[b[i]%alphabet.length];return out;}
export function normalizeRecoveryCode(v:string){return String(v||'').toUpperCase().replace(/[^A-Z0-9]/g,'');}
export function hashRecoveryCode(v:string){return crypto.createHmac('sha256',pepper()).update(normalizeRecoveryCode(v)).digest('hex');}
export function generateRecoveryCodes(count=8){const codes:string[]=[];for(let i=0;i<count;i++){const raw=randomPart();codes.push(`EFRC-${raw.slice(0,4)}-${raw.slice(4,8)}-${raw.slice(8,12)}`);}return{codes,hashes:codes.map(hashRecoveryCode)};}
export function consumeRecoveryCode(hashes:string[]|undefined,code:string){const h=hashRecoveryCode(code),list=[...(hashes||[])],idx=list.findIndex(x=>x===h);if(idx<0)return{ok:false,hashes:list};list.splice(idx,1);return{ok:true,hashes:list};}
