export type ReadinessCheck={key:string;ok:boolean;required:boolean;detail:string};
export function productionReadiness(){const prod=process.env.NODE_ENV==='production';const checks:ReadinessCheck[]=[
 {key:'database',ok:!!String(process.env.DATABASE_URL||'').trim(),required:prod,detail:String(process.env.DATABASE_URL||'').trim()?'PostgreSQL configured':'file repository / DATABASE_URL missing'},
 {key:'job_queue',ok:String(process.env.EVERFLOW_JOB_DRIVER||'memory')==='bullmq'&&!!String(process.env.REDIS_URL||'').trim(),required:prod,detail:String(process.env.EVERFLOW_JOB_DRIVER||'memory')},
 {key:'object_store',ok:['s3','minio'].includes(String(process.env.EVERFLOW_OBJECT_STORE||'local')),required:prod,detail:String(process.env.EVERFLOW_OBJECT_STORE||'local')},
 {key:'compiler_sandbox',ok:['docker','podman'].includes(String(process.env.EVERFLOW_COMPILE_SANDBOX||'')),required:prod,detail:String(process.env.EVERFLOW_COMPILE_SANDBOX||'host-dev')},
 {key:'account_token_secret',ok:String(process.env.EVERFLOW_ACCOUNT_TOKEN_SECRET||'').length>=32,required:prod,detail:String(process.env.EVERFLOW_ACCOUNT_TOKEN_SECRET||'').length>=32?'configured':'missing/short'},
 {key:'redeem_pepper',ok:String(process.env.EVERFLOW_REDEEM_PEPPER||'').length>=24,required:prod,detail:String(process.env.EVERFLOW_REDEEM_PEPPER||'').length>=24?'configured':'missing/short'},
 {key:'ops_gate',ok:!!String(process.env.EVERFLOW_ADMIN_BASE||'').trim()&&String(process.env.EVERFLOW_ADMIN_GATE_SECRET||'').length>=12,required:prod,detail:String(process.env.EVERFLOW_ADMIN_BASE||'').trim()?'configured':'missing'},
 {key:'billing',ok:String(process.env.EVERFLOW_BILLING_PROVIDER||'test')!=='test',required:false,detail:String(process.env.EVERFLOW_BILLING_PROVIDER||'test')},
 {key:'mail_provider',ok:String(process.env.EVERFLOW_MAIL_PROVIDER||'dev')!=='dev'&&!!String(process.env.EVERFLOW_PUBLIC_URL||'').trim(),required:prod,detail:`${String(process.env.EVERFLOW_MAIL_PROVIDER||'dev')} / ${String(process.env.EVERFLOW_PUBLIC_URL||'public-url-missing')}`},
 {key:'cloudflare',ok:!!String(process.env.CLOUDFLARE_TUNNEL_TOKEN||'').trim(),required:false,detail:String(process.env.CLOUDFLARE_TUNNEL_TOKEN||'').trim()?'tunnel token configured':'not configured'}
 ];
 const blocking=checks.filter(x=>x.required&&!x.ok);return{ok:blocking.length===0,mode:prod?'production':'development',blocking:blocking.map(x=>x.key),checks};
}
