import { Repository } from '../persistence';
import { queueRuntimeInfo } from '../../../../packages/job-queue/src';
import { objectStoreInfo } from '../storage/object-store';
import { billingRuntimeInfo } from '../billing/provider';
import { productionReadiness } from './readiness';
import { runtimeProbes } from './runtime-probes';
import { mailRuntimeInfo } from '../mail/provider';
export async function systemHealth(repo:Repository){const stats=await repo.stats(),jobs=await repo.listJobs(),active=jobs.filter(j=>['queued','running','retrying'].includes(j.status)),failed1h=jobs.filter(j=>j.status==='failed'&&Date.now()-new Date(j.updatedAt).getTime()<3600000),runtime=await runtimeProbes();return{ok:true,version:'1.0.0-rc.6',persistence:repo.kind,queue:queueRuntimeInfo(),objectStore:objectStoreInfo(),billing:billingRuntimeInfo(),mail:mailRuntimeInfo(),scheduler:{billingReconcile:{enabled:Number(process.env.EVERFLOW_BILLING_RECONCILE_INTERVAL_MS||0)>=60000,intervalMs:Number(process.env.EVERFLOW_BILLING_RECONCILE_INTERVAL_MS||0),coordination:'persistent-lease'}},readiness:productionReadiness(),runtime,stats,signals:{activeJobs:active.length,failedJobsLastHour:failed1h.length,queuePressure:active.length>100?'critical':active.length>30?'elevated':'normal'},time:new Date().toISOString()};}
