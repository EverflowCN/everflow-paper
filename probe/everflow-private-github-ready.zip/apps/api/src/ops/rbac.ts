import { UserRecord } from "../persistence";

export type OpsRole="support"|"moderator"|"billing"|"ops"|"security"|"superadmin";
export type OpsPermission=
  |"dashboard.read"|"users.read"|"users.write"|"sessions.revoke"
  |"billing.read"|"billing.write"|"redeem.write"
  |"risk.read"|"risk.write"|"audit.read"
  |"jobs.read"|"jobs.manage"|"flags.read"|"flags.write"
  |"security.manage"|"mfa.manage";

const ALL:OpsPermission[]=["dashboard.read","users.read","users.write","sessions.revoke","billing.read","billing.write","redeem.write","risk.read","risk.write","audit.read","jobs.read","jobs.manage","flags.read","flags.write","security.manage","mfa.manage"];
const MATRIX:Record<OpsRole,OpsPermission[]>={
 support:["dashboard.read","users.read","jobs.read"],
 moderator:["dashboard.read","users.read","risk.read","risk.write","audit.read"],
 billing:["dashboard.read","users.read","billing.read","billing.write","redeem.write","audit.read"],
 ops:["dashboard.read","jobs.read","jobs.manage","flags.read","flags.write","audit.read"],
 security:["dashboard.read","users.read","users.write","sessions.revoke","risk.read","risk.write","audit.read","security.manage","mfa.manage"],
 superadmin:ALL
};
export function effectiveOpsRole(user:UserRecord):OpsRole|undefined{
 if(user.role!=="admin")return undefined;
 return (user.opsRole||"superadmin") as OpsRole;
}
export function opsPermissions(user:UserRecord){const role=effectiveOpsRole(user);return role?[...(MATRIX[role]||[])]:[];}
export function hasOpsPermission(user:UserRecord,p:OpsPermission){return opsPermissions(user).includes(p);}
export function requireOpsPermission(user:UserRecord,p:OpsPermission){if(!hasOpsPermission(user,p))throw new Error(`OPS_PERMISSION_DENIED:${p}`);}
