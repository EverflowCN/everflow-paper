import { JobKind, JobRecord, Repository, UserRecord } from "../persistence";
import { publishJob, queueName, cancelQueuedJob } from "../../../../packages/job-queue/src";
const crypto=require("crypto");
const prefixes:Record<JobKind,string>={compile:"CMP",import:"IMP",ai:"AIJ",export:"EXP",billing:"BLJ"};
function publicId(kind:JobKind){return `${prefixes[kind]}-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;}
export class JobService{
 constructor(private readonly repo:Repository){}
 async create(user:UserRecord,kind:JobKind,payload:any,opts:any={}){const now=new Date().toISOString();const j:JobRecord={id:crypto.randomUUID(),publicId:publicId(kind),ownerId:user.id,kind,queueName:queueName(kind),status:"queued",priority:Number(opts.priority??5),progress:0,payload,attempts:0,maxAttempts:Math.max(1,Number(opts.maxAttempts||2)),projectId:opts.projectId,projectRevision:opts.projectRevision,staleKey:opts.staleKey,cancelRequested:false,createdAt:now,updatedAt:now};await this.repo.upsertJob(j);await publishJob(j);return j;}
 async cancel(user:UserRecord,id:string){const j=await this.repo.getJob(user.id,id);if(!j)throw new Error("JOB_NOT_FOUND");const out=await this.repo.requestCancelJob(user.id,id);if(out.status==="cancelled")await cancelQueuedJob(out);return out;}
}
