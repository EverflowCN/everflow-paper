export interface RateLimitResult{allowed:boolean;remaining:number;retryAfterMs:number;}
export class MemoryRateLimiter{
  private buckets=new Map<string,number[]>();
  hit(key:string,limit:number,windowMs:number,now=Date.now()):RateLimitResult{
    const cutoff=now-windowMs,arr=(this.buckets.get(key)||[]).filter(t=>t>cutoff);
    if(arr.length>=limit){this.buckets.set(key,arr);return{allowed:false,remaining:0,retryAfterMs:Math.max(1,arr[0]+windowMs-now)};}
    arr.push(now);this.buckets.set(key,arr);
    if(this.buckets.size>10000)for(const [k,v] of this.buckets)if(!v.some(t=>t>cutoff))this.buckets.delete(k);
    return{allowed:true,remaining:Math.max(0,limit-arr.length),retryAfterMs:0};
  }
  assert(key:string,limit:number,windowMs:number){const r=this.hit(key,limit,windowMs);if(!r.allowed){const e:any=new Error("RATE_LIMITED");e.retryAfterMs=r.retryAfterMs;throw e;}return r;}
}
export function requestIp(req:any){
  const cf=String(req.headers?.["cf-connecting-ip"]||"").trim();if(cf)return cf;
  if(process.env.EVERFLOW_TRUST_PROXY==="1"){const x=String(req.headers?.["x-forwarded-for"]||"").split(",")[0].trim();if(x)return x;}
  return String(req.socket?.remoteAddress||"unknown");
}
