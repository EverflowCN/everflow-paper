import { Repository, UserRecord } from "../persistence";

export interface EntitlementSnapshot {
  plan:"free"|"pro";
  source:"user"|"subscription"|"legacy-admin";
  features:{
    byokAI:boolean;
    aiDocumentImport:boolean;
    privateTemplates:boolean;
    advancedVector:boolean;
    advancedPaperInspection:boolean;
    publishSnapshots:boolean;
  };
  limits:{
    dailyCompiles:number;
    concurrentCompiles:number;
    papers:number;
    templates:number;
    storageMB:number;
    importPagesPerJob:number;
  };
  bonusCredits:{compile:number;importPages:number};
  subscription?:any;
}
const CATALOG={
  free:{features:{byokAI:false,aiDocumentImport:false,privateTemplates:true,advancedVector:false,advancedPaperInspection:false,publishSnapshots:false},limits:{dailyCompiles:30,concurrentCompiles:1,papers:20,templates:3,storageMB:1024,importPagesPerJob:40}},
  pro:{features:{byokAI:true,aiDocumentImport:true,privateTemplates:true,advancedVector:true,advancedPaperInspection:true,publishSnapshots:true},limits:{dailyCompiles:500,concurrentCompiles:3,papers:1000,templates:100,storageMB:20480,importPagesPerJob:500}}
} as const;
export class EntitlementService{
  constructor(private readonly repo:Repository){}
  async snapshot(user:UserRecord,atIso=new Date().toISOString()):Promise<EntitlementSnapshot>{
    const subs=(await this.repo.listSubscriptions(user.id)).filter(s=>["active","trialing","granted","grace_period"].includes(s.status)&&(!s.currentPeriodEnd||s.currentPeriodEnd>atIso));
    const active=subs.sort((a,b)=>(b.currentPeriodEnd||b.updatedAt||"").localeCompare(a.currentPeriodEnd||a.updatedAt||""))[0];
    const plan:"free"|"pro"=active?.plan||((user.plan==="pro"||user.plan==="admin")?"pro":"free");
    const source=active?"subscription":user.plan==="admin"?"legacy-admin":"user";
    const credits=(await this.repo.listMembershipCredits(user.id)).filter(c=>c.remaining>0&&(!c.expiresAt||c.expiresAt>atIso));
    const bonusCompile=credits.filter(c=>c.kind==='compile').reduce((n,c)=>n+c.remaining,0);
    const bonusImport=credits.filter(c=>c.kind==='import_page').reduce((n,c)=>n+c.remaining,0);
    return{plan,source,features:{...CATALOG[plan].features},limits:{...CATALOG[plan].limits},bonusCredits:{compile:bonusCompile,importPages:bonusImport},subscription:active};
  }
  async has(user:UserRecord,feature:keyof EntitlementSnapshot["features"]){return (await this.snapshot(user)).features[feature];}
}
