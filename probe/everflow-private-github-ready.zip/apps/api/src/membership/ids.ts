const crypto=require('crypto');
const ALPHABET='23456789ABCDEFGHJKMNPQRSTUVWXYZ';
function randomChars(n:number){let out='';while(out.length<n){const b=crypto.randomBytes(Math.max(16,n));for(const v of b){if(v>=248)continue;out+=ALPHABET[v%ALPHABET.length];if(out.length===n)break;}}return out;}
export function uuidv7(){const ms=BigInt(Date.now()),b=crypto.randomBytes(16);for(let i=5;i>=0;i--){b[i]=Number(ms>>BigInt((5-i)*8)&255n);}b[6]=(b[6]&0x0f)|0x70;b[8]=(b[8]&0x3f)|0x80;const h=b.toString('hex');return`${h.slice(0,8)}-${h.slice(8,12)}-${h.slice(12,16)}-${h.slice(16,20)}-${h.slice(20)}`;}
export function publicId(prefix:string,size=8){return`${String(prefix).toUpperCase()}-${randomChars(size)}`;}
function checksumBody(body:string){let acc=17;for(let i=0;i<body.length;i++){const p=ALPHABET.indexOf(body[i]);if(p>=0)acc=(acc*33+p+i)%ALPHABET.length;}return ALPHABET[acc];}
export function generateRedeemCode(prefix='EF'){const raw=randomChars(16),groups=raw.match(/.{1,4}/g)||[raw],check=checksumBody(raw);return`${prefix}-${groups.join('-')}-${check}`;}
export function normalizeRedeemCode(code:string){return String(code||'').toUpperCase().replace(/[^A-Z0-9]/g,'');}
export function verifyRedeemCode(code:string){const n=normalizeRedeemCode(code);if(!n.startsWith('EF')||n.length!==19)return false;const body=n.slice(2,-1),check=n.slice(-1);return checksumBody(body)===check;}
export function redeemCodeHash(code:string){const normalized=normalizeRedeemCode(code),pepper=String(process.env.EVERFLOW_REDEEM_PEPPER||'');return pepper?crypto.createHmac('sha256',pepper).update(normalized).digest('hex'):crypto.createHash('sha256').update(normalized).digest('hex');}
export function maskRedeemCode(last4:string){return`EF-****-****-****-${String(last4||'').slice(-4)}`;}
