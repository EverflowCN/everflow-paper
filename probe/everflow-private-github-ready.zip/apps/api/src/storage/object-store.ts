const fs=require("fs"),path=require("path"),crypto=require("crypto");
export type ObjectRef={driver:"local"|"s3";key:string;sizeBytes:number;etag:string;contentType?:string};
export interface ObjectStore{put(key:string,data:any,contentType?:string):Promise<ObjectRef>;get(key:string):Promise<any>;remove(key:string):Promise<void>;info():any;}
function safeKey(k:string){const p=String(k||"").replace(/^\/+/,"");if(!p||p.includes("..")||p.includes("\\"))throw new Error("OBJECT_KEY_INVALID");return p;}
export class LocalObjectStore implements ObjectStore{
 constructor(private root:string){fs.mkdirSync(root,{recursive:true});}
 private p(k:string){const key=safeKey(k),full=path.resolve(this.root,key),base=path.resolve(this.root);if(!full.startsWith(base+path.sep))throw new Error("OBJECT_KEY_INVALID");return full;}
 async put(key:string,data:any,contentType?:string){const b=Buffer.from(data),p=this.p(key);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,b);return{driver:"local" as const,key:safeKey(key),sizeBytes:b.length,etag:crypto.createHash("sha256").update(b).digest("hex"),contentType};}
 async get(key:string){return fs.readFileSync(this.p(key));}
 async remove(key:string){fs.rmSync(this.p(key),{force:true});}
 info(){return{driver:"local",root:this.root};}
}
export class S3ObjectStore implements ObjectStore{
 private client:any;private bucket:string;
 constructor(){let mod:any;try{mod=require("@aws-sdk/client-s3");}catch{throw new Error("S3_DRIVER_MISSING: install @aws-sdk/client-s3");}this.bucket=String(process.env.EVERFLOW_S3_BUCKET||"everflow");this.client=new mod.S3Client({region:process.env.EVERFLOW_S3_REGION||"us-east-1",endpoint:process.env.EVERFLOW_S3_ENDPOINT||undefined,forcePathStyle:String(process.env.EVERFLOW_S3_FORCE_PATH_STYLE||"1")!=="0",credentials:process.env.EVERFLOW_S3_ACCESS_KEY?{accessKeyId:process.env.EVERFLOW_S3_ACCESS_KEY,secretAccessKey:process.env.EVERFLOW_S3_SECRET_KEY||""}:undefined});this.mod=mod;}
 private mod:any;
 async put(key:string,data:any,contentType?:string){const b=Buffer.from(data),k=safeKey(key);await this.client.send(new this.mod.PutObjectCommand({Bucket:this.bucket,Key:k,Body:b,ContentType:contentType}));return{driver:"s3" as const,key:k,sizeBytes:b.length,etag:crypto.createHash("sha256").update(b).digest("hex"),contentType};}
 async get(key:string){const r=await this.client.send(new this.mod.GetObjectCommand({Bucket:this.bucket,Key:safeKey(key)}));return Buffer.from(await r.Body.transformToByteArray());}
 async remove(key:string){await this.client.send(new this.mod.DeleteObjectCommand({Bucket:this.bucket,Key:safeKey(key)}));}
 info(){return{driver:"s3",bucket:this.bucket,endpoint:process.env.EVERFLOW_S3_ENDPOINT||"aws"};}
}
let singleton:ObjectStore|undefined;
export function objectStore(){if(singleton)return singleton;const driver=String(process.env.EVERFLOW_OBJECT_STORE||"local").toLowerCase();singleton=driver==="s3"?new S3ObjectStore():new LocalObjectStore(path.join(process.cwd(),".runtime","objects"));return singleton;}
export function objectStoreInfo(){try{return objectStore().info();}catch(e:any){return{driver:String(process.env.EVERFLOW_OBJECT_STORE||"local"),error:e.message};}}
