import { DemoWorkspace } from "../demo-workspace";
import { Repository, SavedPaperRecord, SavedProjectRecord, UserRecord } from "../persistence";

function safeKey(v:string){return String(v).replace(/[^a-zA-Z0-9._-]/g,"_");}

export class WorkspaceManager{
  private map=new Map<string,DemoWorkspace>();
  constructor(private readonly repo:Repository){}

  static projectId(userId:string,paperId?:string){return paperId?`project:${userId}:paper:${paperId}`:`project:${userId}`;}
  private mapKey(userId:string,paperId?:string){return `${userId}::${paperId||"default"}`;}

  async get(user:UserRecord,paperId?:string){
    const key=this.mapKey(user.id,paperId),cached=this.map.get(key);if(cached)return cached;
    const ws=new DemoWorkspace(`user-${safeKey(user.id)}-${safeKey(paperId||"default")}`,user.id,paperId);
    if(paperId){
      const paper=await this.repo.getPaper(user.id,paperId);if(!paper)throw new Error("PAPER_NOT_FOUND");
      const ids=[...new Set<string>([...(paper.snapshot?.basket||[]),...(paper.snapshot?.items||[]).map((x:any)=>String(x.questionId||""))].filter(Boolean))];
      const questions=[] as any[];for(const id of ids){const q=await this.repo.getQuestion(user.id,id);if(q)questions.push(q);}
      const assets=await this.repo.listAssets(user.id);
      ws.hydratePaperRecord(paper,questions,assets);
    }
    const projectId=WorkspaceManager.projectId(user.id,paperId),saved=await this.repo.getProject(user.id,projectId);
    if(saved?.state)ws.hydratePersistentState(saved.state);
    this.map.set(key,ws);return ws;
  }

  async getByProject(user:UserRecord,projectId?:string){
    if(!projectId)return this.get(user);
    const saved=await this.repo.getProject(user.id,projectId);
    if(saved?.paperId)return this.get(user,saved.paperId);
    const marker=`project:${user.id}:paper:`;
    if(projectId.startsWith(marker))return this.get(user,projectId.slice(marker.length));
    return this.get(user);
  }

  async persist(user:UserRecord,ws:DemoWorkspace,paperId?:string){
    const now=new Date().toISOString(),state=ws.exportPersistentState(),resolvedPaperId=paperId||state.paper?.id,projectId=WorkspaceManager.projectId(user.id,paperId);
    const old=await this.repo.getProject(user.id,projectId);
    const project:SavedProjectRecord={id:projectId,ownerId:user.id,paperId:resolvedPaperId,revision:old?.revision||1,managementMode:state.managementMode,state,createdAt:old?.createdAt||now,updatedAt:now};
    const saved=await this.repo.upsertProject(project,old?.revision);

    if(resolvedPaperId){
      const oldPaper=await this.repo.getPaper(user.id,resolvedPaperId);
      if(oldPaper){
        const oldSnapshot=oldPaper.snapshot&&typeof oldPaper.snapshot==="object"?oldPaper.snapshot:{};
        const mergedSnapshot={...oldSnapshot,paper:{...(oldSnapshot.paper||{}),...(state.paper||{})},template:state.template,source:state.source};
        await this.repo.upsertPaper({...oldPaper,title:state.paper?.title||oldPaper.title,snapshot:mergedSnapshot,updatedAt:now},oldPaper.revision);
      }else{
        const paper:SavedPaperRecord={id:resolvedPaperId,ownerId:user.id,title:state.paper?.title||"未命名试卷",revision:1,snapshot:{paper:state.paper,source:state.source,template:state.template,sections:state.sections||[]},createdAt:now,updatedAt:now};
        await this.repo.upsertPaper(paper);
      }
    }
    return saved;
  }

  drop(userId:string,paperId?:string){
    if(paperId){this.map.delete(this.mapKey(userId,paperId));return;}
    for(const key of [...this.map.keys()])if(key.startsWith(`${userId}::`))this.map.delete(key);
  }
}
