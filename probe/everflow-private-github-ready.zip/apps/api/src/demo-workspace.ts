import { buildImportPreview, draftToRevision } from "../../../packages/question-importer/src";
import { buildDocumentAst } from "../../../packages/document-ast/src";
import { PaperSnapshot } from "../../../packages/domain/src";
import { ZeroOneAdapter } from "../../../packages/zeroone-adapter/src";
import { GenericManagedAdapter } from "../../../packages/template-sdk/src/generic-adapter";
import { compileProject } from "../../compiler-worker/src";
import { forwardSync, normalizeSyncInput, reverseSync } from "../../../packages/synctex/src";
import { GeneratedProject, SourceMapEntry, TemplateAdapter } from "../../../packages/template-sdk/src";
import { RegisteredTemplate, TemplateRegistry } from "../../../packages/template-registry/src";

const fs = require("fs");
const path = require("path");

export interface DemoWorkspaceState {
  revision: number;
  pdfRevision: number;
  source: string;
  baselineSource: string;
  sourceMaps: SourceMapEntry[];
  compileStatus: "idle" | "running" | "success" | "failed";
  compileLog: string;
  pdfPath?: string;
  synctexPath?: string;
  runtime: string;
  rootFile: string;
  compiler: "xelatex" | "pdflatex" | "lualatex";
  paper: any;
  sections: any[];
  questions: any[];
  taxonomy: any[];
  files: { path: string; kind: string; generated: boolean; editable: boolean }[];
  template: { id: string; version: string; name: string; mode: string; adapter: string; builtIn: boolean };
  managementMode: "managed" | "detached";
}

function markerSourceMaps(source: string): SourceMapEntry[] {
  const lines = source.split(/\r?\n/); const maps: SourceMapEntry[] = []; const open: { id:string; start:number; revision?:string }[] = [];
  const sectionRegex = /^\\(part|chapter|section|subsection)\{(.+)\}\s*$/;
  for (let i=0;i<lines.length;i++) {
    const lineNo=i+1,line=lines[i];
    const start=line.match(/%\s*<zeroone:question\s+id="([^"]+)"(?:\s+revision="([^"]+)")?/); if(start)open.push({id:start[1],start:lineNo,revision:start[2]});
    if(/%\s*<\/zeroone:question>/.test(line) && open.length){const info=open.pop()!;maps.push({filePath:"questions/generated-web-paper.tex",startLine:info.start,endLine:lineNo,entityType:"question",entityId:info.id,entityRevisionId:info.revision});}
    const h=line.match(sectionRegex);if(h)maps.push({filePath:"questions/generated-web-paper.tex",startLine:lineNo,endLine:lineNo,entityType:"section",entityId:`heading:${h[1]}:${h[2]}`});
  }
  return maps;
}
function safeWalk(root:string,dir:string,out:any[],depth=0){
  if(depth>5||out.length>=300)return; for(const name of fs.readdirSync(dir).sort()){if(out.length>=300)break;if([".git",".runtime",".preview-pages"].includes(name))continue;const full=path.join(dir,name);const stat=fs.statSync(full);const rel=path.relative(root,full).replace(/\\/g,"/");if(stat.isDirectory())safeWalk(root,full,out,depth+1);else if(/\.(tex|sty|cls|md|json)$/i.test(name))out.push({path:rel,kind:path.extname(name).slice(1)||"file",generated:rel.includes("generated")||rel==="web-entry.tex",editable:rel==="questions/generated-web-paper.tex"});}
}

export class DemoWorkspace {
  private state?: DemoWorkspaceState;
  private snapshot?: PaperSnapshot;
  private basePaperSnapshot?: PaperSnapshot;
  private paperQuestionViews?: any[];
  private paperTemplate?: {id:string;version:string;mode:string};
  private paperAssetFiles:{rel:string,data:any}[]=[];
  private readonly root=process.cwd();
  private readonly runtime:string;
  readonly templates:TemplateRegistry;
  constructor(private readonly workspaceKey:string="p10-demo", private readonly ownerId:string="demo-user", private readonly paperId?:string){
    const safe=workspaceKey.replace(/[^a-zA-Z0-9._-]/g,"_");
    this.runtime=path.join(this.root,`.runtime/workspaces/${safe}`);
    this.templates=new TemplateRegistry(this.root,ownerId);
  }

  private assetFileInfo(asset:any){const mime=String(asset?.mimeType||'').toLowerCase(),ext=mime==='image/png'?'.png':mime==='image/jpeg'?'.jpg':mime==='image/webp'?'.webp':mime==='application/pdf'?'.pdf':mime==='image/svg+xml'?'.svg':'.bin',safe=String(asset?.id||'asset').replace(/[^a-zA-Z0-9._-]/g,'_'),rel=`everflow-assets/${safe}${ext}`,data=asset?.payload?.dataBase64?Buffer.from(String(asset.payload.dataBase64),'base64'):undefined;return{rel,data};}
  private materializePaperAssets(){for(const f of this.paperAssetFiles){if(!f.data)continue;const dst=path.join(this.runtime,f.rel);fs.mkdirSync(path.dirname(dst),{recursive:true});fs.writeFileSync(dst,f.data);}}

  hydratePaperRecord(paperRecord:any, questionRecords:any[], assets:any[]=[]){
    const snap=paperRecord?.snapshot&&typeof paperRecord.snapshot==="object"?paperRecord.snapshot:{};
    this.paperAssetFiles=[];
    const assetMap=new Map((assets||[]).map((a:any)=>[String(a.id),a]));
    const clone=(v:any)=>JSON.parse(JSON.stringify(v));
    const enrichContent=(input:any)=>{
      const c=clone(input||{mode:"structured",stemTex:"",options:[]});
      if(Array.isArray(c.blocks))c.blocks=c.blocks.map((b:any)=>{
        if(b?.type!=="asset")return b;
        const asset:any=assetMap.get(String(b.assetId));if(!asset)return b;
        let renderTex="";
        if(asset.kind==="vector"&&asset.payload?.tikz)renderTex=String(asset.payload.tikz);
        else if(asset.kind==="formula"&&asset.payload?.tex)renderTex=`\\(${String(asset.payload.tex)}\\)`;
        else if(asset.kind==="image"&&asset.payload?.dataBase64){const f=this.assetFileInfo(asset);if(f.data&&!this.paperAssetFiles.some(x=>x.rel===f.rel))this.paperAssetFiles.push(f);const width=Number(b.widthRatio||0),ratio=Number.isFinite(width)&&width>0?Math.min(.95,Math.max(.12,width)):(b.placement==='left'||b.placement==='right'?0.34:b.placement==='option'?0.22:0.48);renderTex=`\\includegraphics[width=${ratio.toFixed(2)}\\linewidth]{${f.rel}}`;}
        else if(asset.payload?.tex)renderTex=String(asset.payload.tex);
        return {...b,assetKind:asset.kind,renderTex};
      });
      return c;
    };
    const byId=new Map((questionRecords||[]).map((q:any)=>[String(q.id),q]));
    const sourceItems=Array.isArray(snap.items)&&snap.items.length?snap.items:(Array.isArray(snap.basket)?snap.basket:[]).map((qid:any,i:number)=>({id:`${paperRecord.id}:item:${i+1}`,questionId:String(qid),order:i+1}));
    const objectiveTypes=new Set(["single_choice","multiple_choice","fill_blank","true_false"]);
    const sectionDefs=Array.isArray(snap.sections)&&snap.sections.length?clone(snap.sections):[
      {id:`${paperRecord.id}:section:objective`,paperId:paperRecord.id,type:"section",title:"单项选择题",order:1},
      {id:`${paperRecord.id}:section:application`,paperId:paperRecord.id,type:"section",title:"综合应用题",order:2}
    ];
    const sectionIds=new Set(sectionDefs.map((x:any)=>String(x.id)));
    const revisions:any={},items:any[]=[],views:any[]=[];
    for(const [idx,item0] of sourceItems.entries()){
      const item=clone(item0),qrec:any=byId.get(String(item.questionId));if(!qrec)continue;
      const payload=qrec.payload||{},hist=Array.isArray(payload.revisions)?payload.revisions:[],frozen=snap.revisionSnapshots&&item.questionRevisionId?snap.revisionSnapshots[String(item.questionRevisionId)]:undefined;
      const pinned=frozen||hist.find((r:any)=>String(r.id)===String(item.questionRevisionId||""))||hist.find((r:any)=>String(r.id)===String(payload.currentRevisionId||""))||hist[hist.length-1];
      const rid=String(item.questionRevisionId||pinned?.id||payload.currentRevisionId||`revision:${qrec.id}:1`),content=enrichContent(pinned?.content||payload.content);
      const assetIds=Array.isArray(content?.blocks)?content.blocks.filter((b:any)=>b?.type==="asset"&&b.assetId).map((b:any)=>String(b.assetId)):[];
      revisions[rid]={id:rid,questionId:qrec.id,revisionNumber:Number(pinned?.revisionNumber||payload.revision||1),contentMode:String(content?.mode||"structured"),content,assetIds,createdBy:String(pinned?.createdBy||this.ownerId),createdAt:String(pinned?.createdAt||qrec.createdAt||new Date().toISOString()),changeSummary:pinned?.changeSummary||"Pinned paper revision",checksum:require("crypto").createHash("sha256").update(JSON.stringify(content)).digest("hex")};
      let sectionId=String(item.sectionId||"");if(!sectionIds.has(sectionId))sectionId=objectiveTypes.has(String(payload.type))?`${paperRecord.id}:section:objective`:`${paperRecord.id}:section:application`;
      const finalItem={...item,id:String(item.id||`${paperRecord.id}:item:${idx+1}`),paperId:paperRecord.id,sectionId,questionId:qrec.id,questionRevisionId:rid,order:Number(item.order||idx+1),score:item.score??payload.score??payload.defaultScore,override:item.override||{}};items.push(finalItem);
      let rawTex="";if(content.mode==="raw_tex")rawTex=String(content.questionTex||"");else if(content.mode==="structured")rawTex=[String(content.stemTex||""),...(content.options||[]).map((o:any)=>`(${o.key}) ${o.tex}`),...(content.blocks||[]).map((b:any)=>b.type==="raw_tex"?b.content:b.type==="asset"?`[asset:${b.assetId} ${b.placement||"inline"}]`:b.content||"")].join("\n");else rawTex=(content.blocks||[]).map((b:any)=>b.type==="asset"?`[asset:${b.assetId} ${b.placement||"inline"}]`:b.content||"").join("\n");
      views.push({id:qrec.id,revisionId:rid,number:idx+1,sectionId,title:`第 ${idx+1} 题`,rawTex,headingContext:{section:{title:sectionDefs.find((x:any)=>String(x.id)===sectionId)?.title||"试题"}},assets:assetIds.map((id:string)=>({path:id})),type:payload.type||"custom",difficulty:Number(payload.difficulty||3),score:Number(finalItem.score||2),source:payload.source||{type:"user"},topic:payload.topic,subject:payload.subject,chapter:payload.chapter});
    }
    const tpl=snap.template||{},mode=String(snap.paper?.mode||tpl.mode||"exam");
    this.paperTemplate={id:String(tpl.id||"zeroone"),version:String(tpl.version||"31.2"),mode};
    const now=new Date().toISOString();
    this.snapshot={paper:{id:paperRecord.id,ownerId:this.ownerId,title:paperRecord.title,templateVersionId:`${this.paperTemplate.id}@${this.paperTemplate.version}`,mode,revision:Number(paperRecord.revision||1),config:clone(snap.paper?.config||{}),createdAt:paperRecord.createdAt||now,updatedAt:paperRecord.updatedAt||now},sections:sectionDefs,items,revisions};
    this.basePaperSnapshot=clone(this.snapshot);this.paperQuestionViews=views;this.state=undefined;
    return this.snapshot;
  }

  private buildSnapshot(){
    if(this.snapshot)return this.snapshot;
    const sourcePath=path.join(this.root,"examples/demo-source.tex"); const tex=fs.readFileSync(sourcePath,"utf8"); const preview=buildImportPreview("demo-source.tex",tex);
    const paperId=`paper:${this.ownerId}`;
    const revisions:any={},items:any[]=[];preview.questions.forEach((draft,i)=>{const qid=`demo-q-${i+1}`,rid=`demo-r-${i+1}`;revisions[rid]=draftToRevision(draft,qid,rid);items.push({id:`item-${i+1}`,paperId,sectionId:i<2?"s-choice":"s-app",questionId:qid,questionRevisionId:rid,order:i+1});});
    this.snapshot={paper:{id:paperId,ownerId:this.ownerId,title:"Everflow·彼时流年若水 IDE · 408 模拟卷",templateVersionId:"zeroone@31.2",mode:"exam",revision:1,config:{},createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()},sections:[{id:"s-choice",paperId,type:"section",title:"单项选择题",order:1},{id:"s-app",paperId,type:"section",title:"综合应用题",order:2}],items,revisions};
    return this.snapshot;
  }
  private getQuestions(){
    if(this.paperQuestionViews)return JSON.parse(JSON.stringify(this.paperQuestionViews));
    const tex=fs.readFileSync(path.join(this.root,"examples/demo-source.tex"),"utf8");const preview=buildImportPreview("demo-source.tex",tex);
    return preview.questions.map((draft:any,i:number)=>({id:`demo-q-${i+1}`,revisionId:`demo-r-${i+1}`,number:i+1,sectionId:i<2?"s-choice":"s-app",title:`第 ${i+1} 题`,rawTex:draft.rawTex,headingContext:draft.headingContext,assets:draft.assets,type:i<2?"single_choice":"comprehensive",difficulty:[2,3,4][i%3],score:i<2?2:10,source:{type:"import",name:"demo-source.tex",year:2026}}));
  }
  private makeAdapter(t:RegisteredTemplate,mode:string):TemplateAdapter{
    if(t.manifest.adapter==="zeroone"){
      if(!["book","exam","public"].includes(mode))throw new Error("ZEROONE_MODE_UNSUPPORTED");
      return new ZeroOneAdapter({templateRoot:t.root,mode:mode as any,includeCover:false,includeToc:false,includeFrontmatter:false});
    }
    return new GenericManagedAdapter(t.root,t.manifest,mode);
  }
  private generate(t:RegisteredTemplate,mode:string,preserveSource?:string):GeneratedProject{
    const snapshot=this.buildSnapshot(); snapshot.paper.templateVersionId=`${t.manifest.id}@${t.manifest.version}`;snapshot.paper.mode=mode;
    const adapter=this.makeAdapter(t,mode);const generated=adapter.buildProject(buildDocumentAst(snapshot));
    if(preserveSource){const q=generated.files.find(f=>f.path==="questions/generated-web-paper.tex");if(q){q.text=preserveSource;q.sha256=require("crypto").createHash("sha256").update(preserveSource).digest("hex");generated.sourceMaps=markerSourceMaps(preserveSource);}}
    adapter.materialize(generated,this.runtime);this.materializePaperAssets();return generated;
  }
  private listTemplatesPublic(){return this.templates.list().map(t=>({id:t.manifest.id,name:t.manifest.name,version:t.manifest.version,description:t.manifest.description,adapter:t.manifest.adapter,compiler:t.manifest.compiler,builtIn:t.builtIn,modes:Object.entries(t.manifest.modes).map(([id,m])=>({id,label:m.label,entrypoint:m.entrypoint}))}));}
  private refreshFiles(s:DemoWorkspaceState){const files:any[]=[];safeWalk(this.runtime,this.runtime,files);s.files=files;}

  ensure():DemoWorkspaceState{
    if(this.state)return this.state;const snapshot=this.buildSnapshot();const wanted=this.paperTemplate||{id:"zeroone",version:"31.2",mode:String(snapshot.paper.mode||"exam")};let t:RegisteredTemplate;try{t=this.templates.get(wanted.id,wanted.version);}catch{t=this.templates.get("zeroone","31.2");}const mode=t.manifest.modes[wanted.mode]?wanted.mode:(t.manifest.modes.exam?"exam":Object.keys(t.manifest.modes)[0]);const generated=this.generate(t,mode);const qfile=generated.files.find(f=>f.path==="questions/generated-web-paper.tex");const source=qfile?.text||"";const questions=this.getQuestions();
    this.state={revision:1,pdfRevision:0,source,baselineSource:source,sourceMaps:generated.sourceMaps,compileStatus:"idle",compileLog:"",runtime:this.runtime,rootFile:generated.rootFile,compiler:generated.compiler,paper:snapshot.paper,sections:snapshot.sections,questions,taxonomy:[{id:"tax-408",parentId:null,name:"408",level:0},{id:"tax-ds",parentId:"tax-408",name:"数据结构",level:1},{id:"tax-sort",parentId:"tax-ds",name:"排序",level:2,questionIds:questions.slice(0,2).map((q:any)=>q.id)},{id:"tax-quick",parentId:"tax-sort",name:"快速排序",level:3,questionIds:questions.slice(1,2).map((q:any)=>q.id)},{id:"tax-app",parentId:"tax-ds",name:"综合应用",level:2,questionIds:questions.slice(2).map((q:any)=>q.id)},{id:"tax-co",parentId:"tax-408",name:"计算机组成原理",level:1,questionIds:[]},{id:"tax-os",parentId:"tax-408",name:"操作系统",level:1,questionIds:[]},{id:"tax-cn",parentId:"tax-408",name:"计算机网络",level:1,questionIds:[]}],files:[],template:{id:t.manifest.id,version:t.manifest.version,name:t.manifest.name,mode,adapter:t.manifest.adapter,builtIn:t.builtIn},managementMode:"managed"};this.refreshFiles(this.state);return this.state;
  }
  publicState(){const s=this.ensure();return {...s,runtime:undefined,pdfPath:undefined,synctexPath:undefined,hasPdf:!!s.pdfPath,availableTemplates:this.listTemplatesPublic()};}
  runtimePath(){this.ensure();return this.runtime;}
  templateList(){return {templates:this.listTemplatesPublic(),active:this.ensure().template};}
  switchTemplate(id:string,version:string,mode:string){const s=this.ensure();const target=this.templates.get(id,version);if(!target.manifest.modes[mode])throw new Error("TEMPLATE_MODE_NOT_FOUND");const same=id===s.template.id&&version===s.template.version;const keep=same?s.source:undefined;const generated=this.generate(target,mode,keep);const qfile=generated.files.find(f=>f.path==="questions/generated-web-paper.tex");s.source=qfile?.text||"";if(!same)s.baselineSource=s.source;s.sourceMaps=generated.sourceMaps;s.rootFile=generated.rootFile;s.compiler=generated.compiler;s.template={id,version,name:target.manifest.name,mode,adapter:target.manifest.adapter,builtIn:target.builtIn};s.paper.templateVersionId=`${id}@${version}`;s.paper.mode=mode;s.revision+=1;s.pdfRevision=0;s.pdfPath=undefined;s.synctexPath=undefined;s.compileStatus="idle";s.compileLog="";this.refreshFiles(s);return this.publicState();}
  registerImportedTemplate(fileName:string,dataBase64:string){const tmpDir=path.join(this.root,".runtime/template-uploads");fs.mkdirSync(tmpDir,{recursive:true});const p=path.join(tmpDir,`upload-${Date.now()}-${path.basename(fileName).replace(/[^a-zA-Z0-9._-]/g,"_")}`);fs.writeFileSync(p,Buffer.from(dataBase64,"base64"));try{const t=this.templates.importZip(p,fileName);return {template:{...t.manifest,builtIn:false},templates:this.listTemplatesPublic()};}finally{fs.rmSync(p,{force:true});}}
  saveSource(source:string,baseRevision:number){const s=this.ensure();if(baseRevision!==s.revision)return{conflict:true,currentRevision:s.revision}as const;if(source===s.source)return{conflict:false,revision:s.revision,sourceMaps:s.sourceMaps}as const;s.source=source;s.revision+=1;s.sourceMaps=markerSourceMaps(source);fs.writeFileSync(path.join(s.runtime,"questions/generated-web-paper.tex"),source,"utf8");return{conflict:false,revision:s.revision,sourceMaps:s.sourceMaps}as const;}
  compile(){const s=this.ensure(),requestedRevision=s.revision;s.compileStatus="running";const result=compileProject({projectId:this.paperId?`project:${this.ownerId}:paper:${this.paperId}`:`project:${this.ownerId}`,projectRevision:requestedRevision,workspace:s.runtime,rootFile:s.rootFile,compiler:s.compiler,compileMode:"preview",timeoutMs:45000,texliveImage:"local-texlive"});s.compileLog=result.outputs.log;if(result.status==="success"&&result.outputs.pdf&&requestedRevision===s.revision){s.compileStatus="success";s.pdfRevision=requestedRevision;s.pdfPath=result.outputs.pdf;s.synctexPath=result.outputs.synctex;}else s.compileStatus="failed";return{...result,displayedRevision:s.pdfRevision,currentRevision:s.revision,pdfUrl:s.pdfPath?`/api/demo/pdf?revision=${s.pdfRevision}`:undefined,template:s.template};}
  pdfInfo(){const s=this.ensure();if(!s.pdfPath)throw new Error("PDF_NOT_COMPILED");const cp=require("child_process");const raw=cp.spawnSync("pdfinfo",[s.pdfPath],{encoding:"utf8"});const text=`${raw.stdout||""}\n${raw.stderr||""}`;const pages=Number((text.match(/^Pages:\s+(\d+)/m)||[])[1]||0);const defaultSize=(text.match(/^Page size:\s+([0-9.]+) x ([0-9.]+) pts/m)||[]);const pageSizes:any[]=[];for(let page=1;page<=pages;page++){const pi=cp.spawnSync("pdfinfo",["-f",String(page),"-l",String(page),s.pdfPath],{encoding:"utf8"});const tt=`${pi.stdout||""}\n${pi.stderr||""}`;const m=tt.match(new RegExp(`^Page\\s+${page}\\s+size:\\s+([0-9.]+) x ([0-9.]+) pts`,"m"))||tt.match(/^Page size:\s+([0-9.]+) x ([0-9.]+) pts/m);pageSizes.push({page,width:Number(m?.[1]||defaultSize[1]||595.28),height:Number(m?.[2]||defaultSize[2]||841.89)});}return{pages,pageSizes,revision:s.pdfRevision,mode:s.template.mode};}
  renderPdfPage(page:number,dpi=120):any{const s=this.ensure();if(!s.pdfPath)throw new Error("PDF_NOT_COMPILED");const cp=require("child_process");const cacheDir=path.join(s.runtime,".preview-pages",`r${s.pdfRevision}`);fs.mkdirSync(cacheDir,{recursive:true});const outputBase=path.join(cacheDir,`page-${page}-${dpi}`),png=`${outputBase}.png`;if(!fs.existsSync(png)){const res=cp.spawnSync("pdftoppm",["-f",String(page),"-l",String(page),"-singlefile","-png","-r",String(dpi),s.pdfPath,outputBase],{encoding:"utf8",timeout:20000});if(res.status!==0||!fs.existsSync(png))throw new Error(`PDF_PAGE_RENDER_FAILED: ${res.stderr||res.stdout||res.status}`);}return fs.readFileSync(png);}
  readPdf():any|undefined{const s=this.ensure();return s.pdfPath&&fs.existsSync(s.pdfPath)?fs.readFileSync(s.pdfPath):undefined;}
  readFile(relPath:string){const s=this.ensure(),normalized=relPath.replace(/^\/+/,"").replace(/\\/g,"/"),abs=path.resolve(s.runtime,normalized);if(!abs.startsWith(path.resolve(s.runtime)+path.sep)&&abs!==path.resolve(s.runtime))return undefined;if(!fs.existsSync(abs)||!fs.statSync(abs).isFile()||fs.statSync(abs).size>1024*1024)return undefined;return{path:normalized,text:fs.readFileSync(abs,"utf8"),editable:normalized==="questions/generated-web-paper.tex"};}
  forward(input:string,line:number,column=0,pageHint=0){const s=this.ensure();if(!s.pdfPath)throw new Error("PDF_NOT_COMPILED");const records=forwardSync({workspace:s.runtime,pdf:path.basename(s.pdfPath),input,line,column,pageHint});return records[0]||null;}
  reverse(page:number,x:number,y:number){const s=this.ensure();if(!s.pdfPath)throw new Error("PDF_NOT_COMPILED");const records=reverseSync({workspace:s.runtime,pdf:path.basename(s.pdfPath),page,x,y});const hit=records[0];if(!hit)return null;const file=normalizeSyncInput(s.runtime,hit.input);const map=s.sourceMaps.find(m=>m.filePath===file&&m.startLine<=hit.line&&m.endLine>=hit.line)||s.sourceMaps.find(m=>m.entityType==="question"&&m.startLine<=hit.line&&m.endLine>=hit.line);return{...hit,input:file,entity:map||null};}

  exportPersistentState(){const s=this.ensure();return{revision:s.revision,source:s.source,baselineSource:s.baselineSource,template:s.template,managementMode:s.managementMode,paper:s.paper,sections:s.sections,questions:s.questions,compileArtifact:{pdfRevision:s.pdfRevision,compileStatus:s.compileStatus,compileLog:s.compileLog,pdfPath:s.pdfPath,synctexPath:s.synctexPath}};}
  hydratePersistentState(saved:any){if(!saved)return this.publicState();let s=this.ensure();const t=saved.template;if(t&&(t.id!==s.template.id||t.version!==s.template.version||t.mode!==s.template.mode)){try{this.switchTemplate(t.id,t.version,t.mode);s=this.ensure();}catch{/* missing user template: keep built-in default */}}if(typeof saved.source==="string"){s.source=saved.source;s.baselineSource=typeof saved.baselineSource==="string"?saved.baselineSource:saved.source;s.revision=Math.max(1,Number(saved.revision||1));s.sourceMaps=markerSourceMaps(s.source);fs.mkdirSync(path.join(s.runtime,"questions"),{recursive:true});fs.writeFileSync(path.join(s.runtime,"questions/generated-web-paper.tex"),s.source,"utf8");}if(saved.managementMode==="detached"||saved.managementMode==="managed")s.managementMode=saved.managementMode;const a=saved.compileArtifact||{};s.pdfRevision=Math.max(0,Number(a.pdfRevision||0));s.pdfPath=a.pdfPath&&fs.existsSync(a.pdfPath)?a.pdfPath:undefined;s.synctexPath=a.synctexPath&&fs.existsSync(a.synctexPath)?a.synctexPath:undefined;s.compileStatus=s.pdfPath&&a.compileStatus==="success"?"success":"idle";s.compileLog=String(a.compileLog||"");this.refreshFiles(s);return this.publicState();}
  reset(){this.state=undefined;if(this.basePaperSnapshot)this.snapshot=JSON.parse(JSON.stringify(this.basePaperSnapshot));else this.snapshot=undefined;fs.rmSync(this.runtime,{recursive:true,force:true});return this.publicState();}
}
export const demoWorkspace=new DemoWorkspace();
