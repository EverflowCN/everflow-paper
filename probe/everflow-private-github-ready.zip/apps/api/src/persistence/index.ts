import { Repository } from "./repository";
import { FileRepository } from "./file-repository";
export * from "./repository";
export async function createRepository(root:string):Promise<Repository>{
  let repo:Repository;
  if(process.env.DATABASE_URL){
    const {PostgresRepository}=require("./postgres-repository");repo=new PostgresRepository(process.env.DATABASE_URL);
  }else{
    const fs=require("fs"),path=require("path"),dir=path.join(root,".runtime/persistence"),modern=path.join(dir,"everflow-db.json"),legacy=path.join(dir,"zeroone-db.json");
    fs.mkdirSync(dir,{recursive:true});
    if(!fs.existsSync(modern)&&fs.existsSync(legacy))fs.renameSync(legacy,modern);
    repo=new FileRepository(modern);
  }
  await repo.init();return repo;
}
