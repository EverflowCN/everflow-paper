export type UserRole = "user" | "admin";
export type PlanId = "free" | "pro" | "admin"; // admin kept only for legacy migration compatibility
export type AccountStatus = "normal" | "watch" | "restricted" | "suspended" | "banned";
export type SessionSurface = "app" | "ops";
export type OpsRole = "support"|"moderator"|"billing"|"ops"|"security"|"superadmin";

export interface UserRecord {
  id: string;
  email: string;
  displayName: string;
  passwordHash: string;
  role: UserRole;
  plan: PlanId;
  accountStatus: AccountStatus;
  disabled: boolean;
  opsRole?: OpsRole;
  opsMfaEnabled?: boolean;
  opsMfaSecretEncrypted?: string;
  emailVerifiedAt?: string;
  emailDeliveryStatus?: "ok"|"bounced"|"complained";
  emailDeliveryStatusAt?: string;
  recoveryCodeHashes?: string[];
  passkeys?: Array<{id:string;credentialId:string;publicKey:string;counter:number;transports?:string[];deviceType?:string;backedUp?:boolean;createdAt:string;lastUsedAt?:string}>;
  createdAt: string;
  updatedAt: string;
}
export interface SessionRecord { id: string; userId: string; tokenHash: string; surface?:SessionSurface; createdAt: string; expiresAt: string; lastSeenAt?: string; ip?: string; userAgent?: string; riskScore?: number; riskReasons?: string[]; newDevice?: boolean; }
export interface BankRecord { id: string; ownerId: string; name: string; description?: string; schemaVersion: number; createdAt: string; updatedAt: string; }
export interface QuestionRecord { id:string; ownerId:string; bankId:string; payload:any; createdAt:string; updatedAt:string; }
export interface AssetRecord { id:string; ownerId:string; kind:"vector"|"formula"|"image"|"document"|"other"; name:string; mimeType?:string; payload:any; createdAt:string; updatedAt:string; }
export interface ImportJobRecord { id:string; ownerId:string; fileName:string; kind:string; status:"uploaded"|"parsing"|"reviewing"|"committing"|"completed"|"failed"; progress:number; sourcePath?:string; preview?:any; error?:string; createdAt:string; updatedAt:string; }
export interface SavedPaperRecord { id: string; ownerId: string; title: string; revision: number; snapshot: any; createdAt: string; updatedAt: string; }
export interface SavedProjectRecord { id: string; ownerId: string; paperId?: string; revision: number; managementMode: "managed"|"detached"; state: any; createdAt: string; updatedAt: string; }
export interface UserTemplateRecord { key: string; ownerId: string; templateId: string; version: string; name: string; root: string; manifest: any; createdAt: string; }
export interface CompileUsageRecord { id: string; userId: string; day: string; count: number; totalDurationMs: number; updatedAt: string; }
export interface AICredentialRecord { id:string; userId:string; provider:string; label:string; baseUrl?:string; model?:string; encryptedKey:string; keyLast4:string; capabilities?:any; createdAt:string; updatedAt:string; }
export interface AISettingsRecord { userId:string; taskRouting:Record<string,string>; updatedAt:string; }

export interface BillingOrderRecord { id:string; publicId:string; userId:string; provider:"test"|"wechat"|"alipay"|"stripe"; providerOrderId?:string; plan:"pro"; period:"month"|"year"; amountCents:number; currency:string; status:"created"|"pending"|"paid"|"failed"|"cancelled"|"refunded"; checkoutUrl?:string; metadata?:any; createdAt:string; updatedAt:string; paidAt?:string; }
export interface SubscriptionRecord { id:string; userId:string; plan:"free"|"pro"; status:"active"|"trialing"|"grace_period"|"past_due"|"cancelled"|"expired"|"refunded"|"granted"; source:"system"|"admin"|"payment"|"migration"|"redeem"; currentPeriodStart?:string; currentPeriodEnd?:string; cancelAtPeriodEnd?:boolean; metadata?:any; createdAt:string; updatedAt:string; }

export interface RedeemCampaignRecord { id:string; publicId:string; name:string; reward:any; status:"active"|"paused"|"ended"; validFrom?:string; expiresAt?:string; perUserLimit:number; createdBy:string; createdAt:string; updatedAt:string; }
export interface RedeemCodeRecord { id:string; publicId:string; campaignId:string; codeHash:string; codeLast4:string; status:"active"|"disabled"|"exhausted"; maxUses:number; usedCount:number; validFrom?:string; expiresAt?:string; createdAt:string; updatedAt:string; }
export interface RedemptionRecord { id:string; publicId:string; userId:string; codeId:string; campaignId:string; status:"claimed"|"applied"|"failed"; reward:any; claimedAt:string; rewardAppliedAt?:string; error?:string; metadata?:any; createdAt:string; updatedAt:string; }
export interface MembershipCreditRecord { id:string; userId:string; kind:"compile"|"import_page"; granted:number; remaining:number; expiresAt?:string; source:"redeem"|"admin"|"system"; sourceId?:string; metadata?:any; createdAt:string; updatedAt:string; }
export interface FeatureFlagRecord { key:string; enabled:boolean; description?:string; rolloutPercentage:number; plans:string[]; userIds:string[]; config?:any; updatedBy?:string; updatedAt:string; }
export interface RiskCaseRecord { id:string; userId?:string; type:string; severity:"low"|"medium"|"high"|"critical"; status:"open"|"reviewing"|"resolved"|"dismissed"; source:"automatic"|"report"|"admin"|"system"; evidence?:any; decision?:any; assignedTo?:string; createdBy?:string; createdAt:string; updatedAt:string; }

export type JobKind = "compile"|"import"|"ai"|"export"|"billing";
export type JobStatus = "queued"|"running"|"retrying"|"success"|"failed"|"cancelled"|"stale";
export interface JobRecord {
  id:string; publicId:string; ownerId:string; kind:JobKind; queueName:string; status:JobStatus;
  priority:number; progress:number; payload:any; result?:any; error?:string; attempts:number; maxAttempts:number;
  projectId?:string; projectRevision?:number; staleKey?:string; cancelRequested?:boolean;
  createdAt:string; updatedAt:string; startedAt?:string; finishedAt?:string;
}

export interface SchedulerLeaseRecord { key:string; holder:string; expiresAt:string; updatedAt:string; }
export interface AuditRecord { id: string; actorUserId?: string; action: string; targetType?: string; targetId?: string; metadata?: any; createdAt: string; }
export interface PersistedState {
  schemaVersion: 11;
  users: UserRecord[];
  sessions: SessionRecord[];
  banks: BankRecord[];
  questions: QuestionRecord[];
  assets: AssetRecord[];
  imports: ImportJobRecord[];
  papers: SavedPaperRecord[];
  projects: SavedProjectRecord[];
  userTemplates: UserTemplateRecord[];
  compileUsage: CompileUsageRecord[];
  aiCredentials: AICredentialRecord[];
  aiSettings: AISettingsRecord[];
  subscriptions: SubscriptionRecord[];
  billingOrders: BillingOrderRecord[];
  redeemCampaigns: RedeemCampaignRecord[];
  redeemCodes: RedeemCodeRecord[];
  redemptions: RedemptionRecord[];
  membershipCredits: MembershipCreditRecord[];
  featureFlags: FeatureFlagRecord[];
  riskCases: RiskCaseRecord[];
  jobs: JobRecord[];
  schedulerLeases: SchedulerLeaseRecord[];
  audit: AuditRecord[];
}

export interface Repository {
  kind: "file" | "postgres";
  init(): Promise<void>;
  createUser(input: Omit<UserRecord,"createdAt"|"updatedAt">): Promise<UserRecord>;
  findUserByEmail(email:string): Promise<UserRecord|undefined>;
  getUser(id:string): Promise<UserRecord|undefined>;
  listUsers(): Promise<UserRecord[]>;
  updateUser(id:string, patch:Partial<Pick<UserRecord,"displayName"|"role"|"plan"|"accountStatus"|"disabled"|"passwordHash"|"opsRole"|"opsMfaEnabled"|"opsMfaSecretEncrypted"|"emailVerifiedAt"|"emailDeliveryStatus"|"emailDeliveryStatusAt"|"recoveryCodeHashes"|"passkeys">>): Promise<UserRecord>;
  createSession(session:SessionRecord): Promise<void>;
  getSessionByHash(tokenHash:string): Promise<SessionRecord|undefined>;
  deleteSessionByHash(tokenHash:string): Promise<void>;
  deleteSessionsForUser(userId:string,surface?:SessionSurface):Promise<number>;
  listSessionsForUser(userId:string,surface?:SessionSurface):Promise<SessionRecord[]>;
  deleteSessionById(userId:string,id:string,surface?:SessionSurface):Promise<boolean>;
  touchSession(tokenHash:string,lastSeenAt:string):Promise<void>;
  deleteExpiredSessions(nowIso:string): Promise<number>;
  listBanks(ownerId:string): Promise<BankRecord[]>;
  createBank(bank:BankRecord): Promise<BankRecord>;
  listQuestions(ownerId:string,bankId?:string): Promise<QuestionRecord[]>;
  getQuestion(ownerId:string,id:string): Promise<QuestionRecord|undefined>;
  upsertQuestion(question:QuestionRecord): Promise<QuestionRecord>;
  listAssets(ownerId:string): Promise<AssetRecord[]>;
  getAsset(ownerId:string,id:string): Promise<AssetRecord|undefined>;
  upsertAsset(asset:AssetRecord): Promise<AssetRecord>;
  listImportJobs(ownerId:string): Promise<ImportJobRecord[]>;
  getImportJob(ownerId:string,id:string): Promise<ImportJobRecord|undefined>;
  upsertImportJob(job:ImportJobRecord): Promise<ImportJobRecord>;
  listPapers(ownerId:string): Promise<SavedPaperRecord[]>;
  getPaper(ownerId:string,id:string): Promise<SavedPaperRecord|undefined>;
  upsertPaper(paper:SavedPaperRecord, baseRevision?:number): Promise<SavedPaperRecord>;
  listProjects(ownerId:string): Promise<SavedProjectRecord[]>;
  getProject(ownerId:string,id:string): Promise<SavedProjectRecord|undefined>;
  upsertProject(project:SavedProjectRecord, baseRevision?:number): Promise<SavedProjectRecord>;
  listUserTemplates(ownerId:string): Promise<UserTemplateRecord[]>;
  saveUserTemplate(rec:UserTemplateRecord): Promise<UserTemplateRecord>;
  removeUserTemplate(ownerId:string,key:string): Promise<void>;
  listAICredentials(userId:string): Promise<AICredentialRecord[]>;
  getAICredential(userId:string,id:string): Promise<AICredentialRecord|undefined>;
  upsertAICredential(rec:AICredentialRecord): Promise<AICredentialRecord>;
  removeAICredential(userId:string,id:string): Promise<void>;
  getAISettings(userId:string): Promise<AISettingsRecord>;
  upsertAISettings(rec:AISettingsRecord): Promise<AISettingsRecord>;
  listSubscriptions(userId?:string):Promise<SubscriptionRecord[]>;
  upsertSubscription(rec:SubscriptionRecord):Promise<SubscriptionRecord>;
  listBillingOrders(userId?:string):Promise<BillingOrderRecord[]>;
  getBillingOrder(userId:string,id:string):Promise<BillingOrderRecord|undefined>;
  upsertBillingOrder(rec:BillingOrderRecord):Promise<BillingOrderRecord>;
  listRedeemCampaigns():Promise<RedeemCampaignRecord[]>;
  upsertRedeemCampaign(rec:RedeemCampaignRecord):Promise<RedeemCampaignRecord>;
  listRedeemCodes(campaignId?:string):Promise<RedeemCodeRecord[]>;
  createRedeemCode(rec:RedeemCodeRecord):Promise<RedeemCodeRecord>;
  claimRedeemCode(codeHash:string,userId:string,redemption:RedemptionRecord,nowIso:string):Promise<{code:RedeemCodeRecord;campaign:RedeemCampaignRecord;redemption:RedemptionRecord}|undefined>;
  listRedemptions(userId?:string):Promise<RedemptionRecord[]>;
  upsertRedemption(rec:RedemptionRecord):Promise<RedemptionRecord>;
  listMembershipCredits(userId:string,kind?:MembershipCreditRecord["kind"]):Promise<MembershipCreditRecord[]>;
  upsertMembershipCredit(rec:MembershipCreditRecord):Promise<MembershipCreditRecord>;
  consumeMembershipCredits(userId:string,kind:MembershipCreditRecord["kind"],amount:number,nowIso:string):Promise<number>;
  listFeatureFlags():Promise<FeatureFlagRecord[]>;
  upsertFeatureFlag(rec:FeatureFlagRecord):Promise<FeatureFlagRecord>;
  listRiskCases(userId?:string):Promise<RiskCaseRecord[]>;
  listJobs(ownerId?:string,kind?:JobKind):Promise<JobRecord[]>;
  getJob(ownerId:string,id:string):Promise<JobRecord|undefined>;
  upsertJob(rec:JobRecord):Promise<JobRecord>;
  requestCancelJob(ownerId:string,id:string):Promise<JobRecord>;
  upsertRiskCase(rec:RiskCaseRecord):Promise<RiskCaseRecord>;
  getCompileUsage(userId:string,day:string): Promise<CompileUsageRecord>;
  incrementCompileUsage(userId:string,day:string,durationMs:number): Promise<CompileUsageRecord>;
  tryAcquireLease(key:string,holder:string,ttlMs:number,nowIso?:string):Promise<boolean>;
  appendAudit(rec:AuditRecord): Promise<void>;
  listAudit(limit:number): Promise<AuditRecord[]>;
  stats(): Promise<{users:number;proUsers:number;banks:number;papers:number;projects:number;templates:number;compilesToday:number;openCases:number;activeJobs:number}>;
}
