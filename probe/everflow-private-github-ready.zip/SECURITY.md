# Security Policy

This is a private proprietary repository.

- Never commit `.env`, runtime databases, user uploads, API keys, payment secrets, AI BYOK credentials, certificates, private keys, or production backups.
- Production compilation must use the sandboxed compiler mode.
- Production deployment must pass `npm run production:check` before receiving public traffic.
- Report suspected credential exposure by revoking the credential first, then rotating affected secrets and auditing logs.
